"""
Blender-side helpers shared by Script1 (tile / child actor build) and Script2 (general blueprint build).
All transform maths lives in dbd_core; this module only creates / places Blender objects.

Custom properties written on created objects
    dbd_owner         class name of the blueprint build that created the object (e.g. 'BP_TL_Fr_HD231_C')
    dbd_blueprint     on a blueprint's main empty: its class name (used to find it as a child-actor template)
    dbd_cac           on a ChildActorComponent empty: the component's name
    dbd_child_class   on a ChildActorComponent empty: class of the actor it spawns
    dbd_instance      on the root of an instanced copy of a child blueprint
    ue_hidden_in_game component was flagged hidden in game (bHiddenInGame / bVisible=False)
    dbd_group         on a placed mesh: its Outliner group (see dbd_core.mesh_group)
    dbd_atlas_cell    on a placed mesh: its CustomPrimitiveData poster cell plus 1, which the Material Maker's atlas shader reads (0 = none)
    dbd_template      on a blueprint's main empty once copies of it replace it: organize_build files it away
    dbd_instance_source  on an instancer: the hidden object it places a copy of on every point
    dbd_instance_count   on an instancer: how many instances it places
    dbd_source_key    on an instancer's source: mesh file, override materials and poster cell, so sources are shared
Collections
    dbd_build         on a build's collection: the owner of that build
    dbd_group         on a collection inside it: the group it holds
"""
import collections
import hashlib
import json
import math
import os
import re
import sys
import zlib

import bpy
import mathutils
import numpy as np

from . import dbd_core
from . import dbd_map
from . import dbd_procgen
from . import dbd_umap
from . import psk_reader
from . import uemodel_reader
MESH_CACHE_COLLECTION = "DbD_MeshCache"
TEMPLATE_COLLECTION = "DbD_Templates"
SOURCE_COLLECTION = "DbD_InstanceSources"     # the meshes instancers place (unticked: only their copies show)
INSTANCER_GROUP = "DbD Instancer"             # the Geometry Nodes group every instancer shares
INSTANCER_VERSION = 1
TRANSFORM_ATTRIBUTE = "dbd_transform"         # each point's full 4x4 transform


# --------------------------------------------------------------------------------------------
# Reporting
# --------------------------------------------------------------------------------------------

class Report(object):
    def __init__(self):
        self.built = collections.Counter()
        self.missing_meshes = collections.OrderedDict()   # mesh path -> expected file
        self.missing_child = collections.Counter()        # child class -> times needed
        self.child_notes = {}                             # child class -> why it is missing
        self.missing_child_json = set()                   # child classes whose JSON couldn't be located
        self.skipped_engine_shapes = 0
        self.skipped_by_name = 0
        self.missing_instance_data = []                   # (component, expected count)
        self.warnings = []

    def print_summary(self, title):
        print("\n=== %s ===" % title)
        for k, v in sorted(self.built.items()):
            print("  built %-22s %d" % (k, v))
        if self.skipped_by_name:
            print("  skipped %d components matching the skip list (e.g. detect zones)" % self.skipped_by_name)
        if self.skipped_engine_shapes:
            print("  skipped %d engine primitive shapes (Cube/Plane/...: blockers / collision)" % self.skipped_engine_shapes)
        if self.missing_meshes:
            print("\n  Missing meshes (%d):" % len(self.missing_meshes))
            for name, where in self.missing_meshes.items():
                print("   - %s   (looked for %s)" % (name, where))
        if self.missing_child:
            print("\n  Child blueprints not found in the scene (build them with 'Run General Blueprint' first):")
            for cls, n in sorted(self.missing_child.items()):
                note = self.child_notes.get(cls.split(" (")[0])
                print("   - %s  x%d%s" % (cls, n, ("   [%s]" % note) if note else ""))
        if self.missing_instance_data:
            print("\n  Instanced components whose instance list is not in the JSON (cannot be rebuilt):")
            for name, n in self.missing_instance_data:
                print("   - %s  (%s)" % (name, ("%d instances in game" % n) if n else "instance count not exported"))
        if self.warnings:
            print("\n  Warnings:")
            for w in self.warnings:
                print("   - %s" % w)
        print("=" * (8 + len(title)) + "\n")


# --------------------------------------------------------------------------------------------
# Scene helpers
# --------------------------------------------------------------------------------------------

def _find_layer_collection(layer_coll, coll):
    if layer_coll.collection == coll:
        return layer_coll
    for child in layer_coll.children:
        found = _find_layer_collection(child, coll)
        if found:
            return found
    return None


def _cache_collection():
    return _excluded_collection(MESH_CACHE_COLLECTION)


def _source_collection():
    return _excluded_collection(SOURCE_COLLECTION)


def _excluded_collection(name):
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(coll)
    try:
        lc = _find_layer_collection(bpy.context.view_layer.layer_collection, coll)
        if lc is not None:
            lc.exclude = True
    except Exception:
        pass
    return coll


def _link(obj, collection=None):
    (collection or bpy.context.collection).objects.link(obj)


def _set_matrix(obj, rows):
    obj.matrix_basis = mathutils.Matrix(rows)


def _hide(obj):
    try:
        obj.hide_set(True)
    except Exception:
        pass
    if getattr(obj, "type", "") == "LIGHT":
        obj.hide_render = True              # a hidden template light at the world origin must not light the scene


def _remove_objects(doomed):
    """Delete objects in one go: one at a time, Blender rescans the file for each, and a rebuild of Wales spent 75 s removing its 9,000 objects."""
    doomed = [o for o in doomed if o is not None]
    if not doomed:
        return
    try:
        bpy.data.batch_remove(ids=doomed)
    except Exception:
        for o in doomed:
            try:
                bpy.data.objects.remove(o, do_unlink=True)
            except Exception:
                pass


def remove_object_tree(obj):
    _remove_objects([obj] + list(obj.children_recursive))


def remove_previous_build(class_name):
    """Delete objects created by an earlier run for this blueprint so a rebuild doesn't stack duplicates."""
    doomed = [o for o in bpy.data.objects if o.get("dbd_owner") == class_name]
    _remove_objects(doomed)
    return len(doomed)


def make_empty(name, collection=None, display="PLAIN_AXES", size=0.25):
    obj = bpy.data.objects.new(name, None)
    obj.empty_display_type = display
    obj.empty_display_size = size
    _link(obj, collection)
    return obj


def make_main_empty(class_name, stamp=""):
    main = make_empty(class_name, display="PLAIN_AXES", size=1.0)
    main["dbd_blueprint"] = class_name
    main["dbd_owner"] = class_name
    main["dbd_build_stamp"] = stamp
    return main


def _code_fingerprint():
    """Short hash of the add-on's building code: a blueprint built by other code is stale.  Every module a build reads files or picks objects with
    is in it: the UEFormat reader was not, so blueprints built while a tester's .uemodel files failed kept being reused, empty, after the fix."""
    h = hashlib.sha1()
    for mod in (dbd_core, psk_reader, uemodel_reader, dbd_procgen, dbd_map, dbd_umap, sys.modules[__name__]):
        try:
            with open(mod.__file__, "rb") as f:
                h.update(f.read())
        except Exception:
            h.update(repr(mod).encode("utf-8"))
    return h.hexdigest()[:12]


CODE_FINGERPRINT = _code_fingerprint()


def current_root(class_name, ctx):
    """
    Main empty of an already-built blueprint, but only when it was built by this code with these settings (its dbd_build_stamp matches).  A
    stale one - built before an update, or with other options (lights, gameplay objects, seed ...) - counts as not built, so it is rebuilt
    instead of silently reused with its old contents.
    """
    root = find_blueprint_root(class_name)
    if root is not None and root.get("dbd_build_stamp") != ctx.stamp:
        return None
    return root


def find_blueprint_root(class_name):
    """Main empty of an already-built blueprint (not one of its instanced copies)."""
    if not class_name:
        return None
    for o in bpy.data.objects:
        if (o.get("dbd_blueprint") == class_name or o.get("dbd_alias") == class_name) and not o.get("dbd_instance"):
            return o
    # Blueprints built by older versions of the addon: an empty named '<BP>_C' (maybe with .001 suffix)
    for o in bpy.data.objects:
        if o.type == "EMPTY" and (o.name == class_name or o.name.startswith(class_name + ".")):
            return o
    return None


# --------------------------------------------------------------------------------------------
# Mesh import (one .pskx import per unique mesh, everything else is a linked copy)
# --------------------------------------------------------------------------------------------

MESH_EXTENSIONS = (".pskx", ".psk", ".uemodel")      # the order they are preferred in when a mesh exists more than once


def read_mesh_file(path):
    """A .pskx, .psk or .uemodel as a PskMesh."""
    return uemodel_reader.read_uemodel(path) if path.lower().endswith(".uemodel") else psk_reader.read_psk(path)


def build_mesh_from_psk(psk, name):
    """PskMesh (numpy arrays) -> bpy.types.Mesh without operators or selection (foreach_set, linked data)."""
    nv, nf = psk.vertex_count, psk.face_count
    mesh = bpy.data.meshes.new(name)
    try:
        mesh.vertices.add(nv)
        mesh.vertices.foreach_set("co", psk.positions.reshape(-1))
        mesh.loops.add(nf * 3)
        mesh.loops.foreach_set("vertex_index", psk.faces.reshape(-1))
        mesh.polygons.add(nf)
        mesh.polygons.foreach_set("loop_start", np.arange(0, nf * 3, 3, dtype=np.int32))
        mesh.update(calc_edges=True)
    except Exception:
        # Blender API differences: the slower, version-proof path
        bpy.data.meshes.remove(mesh)
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(psk.positions.tolist(), [], psk.faces.tolist())

    for mat_name in psk.materials:
        mat = bpy.data.materials.get(mat_name) or bpy.data.materials.new(mat_name)
        mesh.materials.append(mat)
    if nf:
        mesh.polygons.foreach_set("material_index", np.clip(psk.material_index, 0, max(len(psk.materials) - 1, 0)).astype(np.int32))

    uv = mesh.uv_layers.new(name="UV_SINGLE")
    uv.data.foreach_set("uv", psk.uvs.reshape(-1))
    for i, extra in enumerate(psk.extra_uvs):
        if len(mesh.uv_layers) >= 8:
            break
        layer = mesh.uv_layers.new(name="EXTRAUVS%d" % i)
        layer.data.foreach_set("uv", extra.reshape(-1))

    if psk.normals is not None:
        try:
            mesh.polygons.foreach_set("use_smooth", np.ones(nf, dtype=np.bool_))
            mesh.normals_split_custom_set_from_vertices(psk.normals.tolist())
        except Exception as exc:
            print("Custom normals skipped for %s: %s" % (name, exc))

    if psk.vertex_colors is not None:
        try:
            layer = mesh.color_attributes.new("PSKVTXCOL_0", "BYTE_COLOR", "CORNER")
            layer.data.foreach_set("color", psk.vertex_colors.reshape(-1))
        except Exception as exc:
            print("Vertex colours skipped for %s: %s" % (name, exc))
    mesh.update()
    return mesh


class MeshLibrary(object):
    def __init__(self, base_path, report):
        self.base = bpy.path.abspath(base_path) if base_path else ""
        self.report = report
        self.masters = {}      # file key -> [master objects]; pre-filled from DbD_MeshCache (survives between runs)
        self._index = None
        self._cache_loaded = False
        self._failed = set()

    # ---- locating the file ----------------------------------------------------------------
    def _candidates(self, object_path, mesh_name=None):
        """
        Where the export may hold the mesh.  A package whose mesh object has another name (SM_MTR_Hook_REF holding SM_MTR_Hook_REF_SM_Mtr_Hook_012) is
        written either as one file named after the package, or as a folder of that name with the object's file inside: both are tried.
        """
        rels = dbd_core.export_path_candidates(object_path)
        if mesh_name:
            rels = rels + [rel + "/" + mesh_name for rel in rels if rel.rsplit("/", 1)[-1].lower() != mesh_name.lower()]
        out = []
        for ext in MESH_EXTENSIONS:
            for rel in rels:
                out.append(os.path.join(self.base, rel.replace("/", os.sep) + ext))
        return out

    def _build_index(self):
        self._index = collections.defaultdict(list)
        for dirpath, _dirs, files in os.walk(self.base):
            for f in files:
                low = f.lower()
                if low.endswith(MESH_EXTENSIONS):
                    self._index[os.path.splitext(low)[0]].append(os.path.join(dirpath, f))

    def resolve_file(self, object_path, mesh_name):
        if not object_path and not mesh_name:
            return None, ""
        rel = (object_path or "").split(".")[0].lstrip("/")
        tried = ""
        if rel:
            for cand in self._candidates(object_path, mesh_name):
                tried = tried or cand
                if os.path.isfile(cand):
                    return cand, tried
        # Fallback: the folder layout differs between exports / eras - match on the file name,
        # preferring the candidate whose path shares the longest tail with the Unreal path.
        if self.base and os.path.isdir(self.base):
            if self._index is None:
                self._build_index()
            hits = []
            for stem in (os.path.basename(rel), mesh_name):           # the package's name, then the mesh object's
                if stem and not hits:
                    hits = self._index.get(stem.lower(), [])
            if hits:
                tail = rel.lower().replace("/", os.sep)

                def score(p):
                    pl = os.path.splitext(p)[0].lower()
                    n = 0
                    for a, b in zip(reversed(pl.split(os.sep)), reversed(tail.split(os.sep))):
                        if a != b:
                            break
                        n += 1
                    return n
                return max(hits, key=score), tried
        return None, tried

    # ---- importing ------------------------------------------------------------------------
    @staticmethod
    def _key(filepath):
        return os.path.normcase(os.path.abspath(filepath))

    def _load_cache(self):
        """Meshes imported by earlier runs sit in DbD_MeshCache tagged with their file - reuse, don't re-import."""
        self._cache_loaded = True
        coll = bpy.data.collections.get(MESH_CACHE_COLLECTION)
        if coll is None:
            return
        for o in list(coll.objects):
            key = o.get("dbd_psk")
            if key:
                self.masters.setdefault(key, []).append(o)

    def _master_alive(self, key):
        try:
            objs = self.masters.get(key)
            return bool(objs) and all(bpy.data.objects.get(o.name) == o for o in objs)
        except ReferenceError:
            return False

    def _import_master(self, filepath, key):
        stem = os.path.splitext(os.path.basename(filepath))[0]
        obj = bpy.data.objects.new(stem, build_mesh_from_psk(read_mesh_file(filepath), stem))
        _cache_collection().objects.link(obj)
        obj["dbd_psk"] = key
        return [obj]

    def instance(self, object_path, mesh_name, instance_name):
        """Return a list of new objects (usually one) for this mesh, or [] if it can't be found."""
        filepath, tried = self.resolve_file(object_path, mesh_name)
        if not filepath:
            self.report.missing_meshes.setdefault(mesh_name or object_path, tried)
            return []
        if not self._cache_loaded:
            self._load_cache()
        key = self._key(filepath)
        if key in self._failed:
            return []
        if not self._master_alive(key):
            try:
                self.masters[key] = self._import_master(filepath, key)
            except Exception as exc:
                print("Error importing %s: %s" % (filepath, exc))
                self.report.warnings.append("could not import %s: %s" % (os.path.basename(filepath), exc))
                self.masters[key] = []
                self._failed.add(key)
                return []
        out = []
        for master in self.masters[key]:
            obj = master.copy()      # shares mesh data
            obj.name = instance_name
            obj.hide_viewport = False
            if "dbd_psk" in obj:
                del obj["dbd_psk"]
            obj["dbd_group"] = dbd_core.mesh_group(filepath)
            _link(obj)
            out.append(obj)
        return out

    def source(self, object_path, mesh_name, material_names=(), atlas_cell=0.0):
        """
        The hidden objects an instancer places copies of (usually one): the mesh with this component's override materials and poster cell, which the
        instances carry with them.  Components that would give the same source share it, in this build and the ones after it.
        """
        filepath, _tried = self.resolve_file(object_path, mesh_name)
        if not filepath:
            return self.instance(object_path, mesh_name, mesh_name or "missing")          # records it as missing; returns []
        key = "%s|%s|%g" % (self._key(filepath), ",".join(n or "" for n in (material_names or ())), atlas_cell or 0.0)
        found = [o for o in _source_collection().objects if o.get("dbd_source_key") == key]
        if found:
            return found
        stem = os.path.splitext(os.path.basename(filepath))[0]
        out = []
        for i, obj in enumerate(self.instance(object_path, mesh_name, "%s_Source" % stem)):
            for coll in list(obj.users_collection):
                coll.objects.unlink(obj)
            _source_collection().objects.link(obj)
            obj.matrix_basis = mathutils.Matrix.Identity(4)
            obj["dbd_source_key"] = key
            if atlas_cell:
                obj["dbd_atlas_cell"] = atlas_cell
            apply_override_materials(obj, material_names, self.report)
            out.append(obj)
        return out


def apply_override_materials(obj, material_names, report):
    """
    OverrideMaterials[i] replaces material slot i - done per object so linked mesh data stays shared.  A material that is not in the file yet gets an empty one of
    that name: the Material Maker builds what the slots name, so this keeps a ground tile from staying on the mesh's own WorldGridMaterial.
    """
    if obj.type != "MESH" or not material_names:
        return
    for i, name in enumerate(material_names):
        if not name or i >= len(obj.material_slots):
            continue
        mat = bpy.data.materials.get(name)
        if mat is None:
            mat = next((m for m in bpy.data.materials if m.name.startswith(name + ".")), None)
        if mat is None:
            mat = bpy.data.materials.new(name)
        slot = obj.material_slots[i]
        slot.link = "OBJECT"
        slot.material = mat


# --------------------------------------------------------------------------------------------
# Child blueprint instancing
# --------------------------------------------------------------------------------------------

def instantiate_blueprint(template_root, parent, owner_class, name):
    """
    Copy a built blueprint's whole hierarchy (mesh data stays linked) and parent the copy to `parent`
    (a ChildActorComponent empty) with an identity local transform.
    """
    originals = [template_root] + list(template_root.children_recursive)
    mapping = {}
    for o in originals:
        c = o.copy()
        if getattr(o, "type", "") == "LIGHT":
            c.hide_render = bool(o.get("dbd_ue_off"))   # the template of a built blueprint is render-hidden (see _hide); its copies are not
        c["dbd_owner"] = owner_class
        for key in ("dbd_blueprint", "dbd_alias", "dbd_template"):
            if key in c:
                del c[key]
        _link(c)                # the active collection, like the rest of the build: organize_build files it.  (users_collection searches every collection.)
        mapping[o] = c
    for o in originals:
        c = mapping[o]
        if o is template_root:
            c.parent = parent
            c.matrix_parent_inverse = mathutils.Matrix.Identity(4)
            c.matrix_basis = mathutils.Matrix.Identity(4)
            c.name = name
            c["dbd_instance"] = True
            c["dbd_instance_of"] = template_root.get("dbd_blueprint") or template_root.name
        else:
            c.parent = mapping.get(o.parent, parent)
    if _ACTIVE_CTX is not None:
        for c in mapping.values():
            if "dbd_mesh_choices" in c:
                _pick_script_mesh(c, _ACTIVE_CTX)
    return mapping[template_root]


def child_class_candidates(p):
    """
    Class names a ChildActorComponent may spawn, best first.  Normally ChildActorClass / the template's
    type gives it exactly.  Some exports carry neither (the class lives on an unexported parent template);
    DbD names those components after their class plus a counter ('BP_Brl_CandleFire3' -> BP_Brl_CandleFire_C).
    """
    if p.type in dbd_core.SPAWNING_TYPES:
        el = p.spawn_target()
        return ([el[0]] if el else []), True
    known = p.child_actor_class()
    if known:
        return [known], True
    names = []
    for raw in (p.var, dbd_core.strip_gen_variable(p.item.get("Name") or "")):
        if not raw:
            continue
        for n in (raw, re.sub(r"[_ ]?\d+$", "", raw)):
            n = n.strip()
            if n and n not in names:
                names.append(n)
    out = []
    for n in names:
        c = n if n.endswith("_C") else n + "_C"
        if c not in out:
            out.append(c)
    return out, False


def pick_child_template(p):
    cands, _exact = child_class_candidates(p)
    for c in cands:
        t = find_blueprint_root(c)
        if t is not None:
            return c, t
    return (cands[0] if cands else None), None


# Always skipped, whatever the panel says: invisible gameplay blockers that keep the Entity out of a spot
# (SM_Entity_Pallet, SM_Entity_Pallet_Pulldown, SM_TotemBlocker_Entity_Perk ...).  "a&b" means both words must appear.
# The visible corruption art (SM_LM_Entity_Patch_*, SM_COM_Entity_Blob_*, claws ...) is not touched.
# Also never built: the state variants stacked under a gameplay object - the broken / destroyed pallet and totem (their hidden-in-game flag
# is not set in every version, so they are matched by name) and the generator's selection outline and low-poly clone.
BUILTIN_SKIP_PATTERNS = ["blocker&entity", "entity_pallet",
                         "pallet_scraps", "palletbroken", "pallet_broken", "brokenpallet", "pallet_destroy", "destroyvat",
                         "totem01_broken", "totem_broken", "boontotemglow", "boontotemzone",
                         "generatorclone", "generatoroutline", "generator_outline", "entityspikes_chest"]


def child_slots(bp, seed=1, spawn_scene=True, gameplay=(), edges=True, fixed_hooks=False):
    """
    ChildActorComponents plus (optionally) the scene blueprints its ActorSpawners spawn and the chosen gameplay
    actors (lockers / vaults / generators, one per candidate spawn point).  `fixed_hooks`: the basement's own hook too when the
    game's rules place the other hooks (they never place that one: the basement always has it).
    """
    slots = list(bp.child_actor_placements()) + bp.variation_placements()
    if spawn_scene:
        slots += bp.scene_spawn_placements(seed, include_edges=edges)
    if gameplay:
        slots += bp.gameplay_spawn_placements(set(gameplay))
    if fixed_hooks and "hooks" not in set(gameplay or ()):
        slots += bp.fixed_hook_placements()
    return slots


def wants_fixed_hooks(ctx):
    """A map the game's rules populate, with hooks asked for in the panel: the basement hook is built with its basement."""
    return ctx.game_categories is not None and "hooks" in ctx.game_categories


def options_from_props(props):
    """BuildContext keyword options from the addon's scene properties."""
    gameplay = set()
    for flag, name in (("build_lockers", "lockers"), ("build_vaults", "vaults"), ("build_generators", "generators"),
                       ("build_pallets", "pallets"), ("build_totems", "totems"), ("build_hooks", "hooks"),
                       ("build_chests", "chests"), ("build_hatch", "hatch")):
        if getattr(props, flag, False):
            gameplay.add(name)
    patterns = [t.strip().lower() for t in (getattr(props, "skip_name_patterns", "") or "").split(",") if t.strip()]
    patterns += [t for t in BUILTIN_SKIP_PATTERNS if t not in patterns]
    return dict(seed=props.map_seed, spawn_scene=props.spawn_scene_blueprints, gameplay=gameplay, skip_patterns=patterns,
                spawn_counts=dict(generators=getattr(props, "count_generators", 0), totems=getattr(props, "count_totems", 0),
                                  pallets=getattr(props, "count_pallets", 0), lockers=getattr(props, "count_lockers", 0),
                                  chests=getattr(props, "count_chests", 0)),
                lights=bool(getattr(props, "build_lights", True)), light_strength=float(getattr(props, "light_strength", 1.0)),
                lights_off=bool(getattr(props, "build_lights_off", True)),
                light_min_radius=float(getattr(props, "light_min_radius", dbd_core.MIN_SOURCE_RADIUS_M)),
                light_discs=bool(getattr(props, "light_round_as_disc", False)),
                light_spot_size=float(getattr(props, "light_spot_size", 0.0)),
                light_static_no_volume=bool(getattr(props, "light_static_no_volume", True)),
                light_no_volume_names=[t.strip().lower() for t in str(getattr(props, "light_no_volume_names", "fill") or "").split(",") if t.strip()],
                generator_lights=bool(getattr(props, "build_generator_lights", False)),
                instancing=bool(getattr(props, "use_instancing", True)),
                sky=bool(getattr(props, "build_sky", False)))


def populate_child_actors(bp, main, report, collection=None, seed=1, spawn_scene=True, gameplay=(), edges=True, fixed_hooks=False):
    """
    Make sure every ChildActorComponent of `bp` - and every scene blueprint its ActorSpawners spawn - has an empty
    under `main` at its resolved transform and holds a fresh instanced copy of the child blueprint (if that
    blueprint has been built).
    """
    existing = {o.get("dbd_cac"): o for o in main.children if o.get("dbd_cac")}
    used_templates = []
    for p in child_slots(bp, seed, spawn_scene, gameplay, edges, fixed_hooks):
        cands, exact = child_class_candidates(p)
        cls, template = pick_child_template(p)
        slot_name = p.name + ("_spawn" if p.type in dbd_core.SPAWNING_TYPES else "")
        empty = existing.get(slot_name)
        if empty is None:
            empty = make_empty(slot_name, collection, display="PLAIN_AXES", size=0.3)
            empty.parent = main
            empty["dbd_cac"] = slot_name
            empty["dbd_owner"] = bp.class_name
            report.built["child actor slots"] += 1
        empty["dbd_child_class"] = cls or ""
        category = p.gameplay_category()
        if category:
            empty["dbd_gameplay"] = category    # the map build chooses which of these stay (see choose_gameplay)
        if (p.props.get("Type") or "").replace("EGameplayElementType::", "") in dbd_core.BASEMENT_SPAWN_TYPES:
            empty["dbd_generated"] = True       # the game picks one basement: place_gameplay replaces these
        tag = p.direction_tag()
        if tag:
            empty["dbd_dir"] = tag          # optional fence spoke / edge pillar: pruned per placement by build_map
        empty["ue_hidden_in_game"] = p.hidden_in_game
        _set_matrix(empty, p.blender_matrix())

        for child in [c for c in empty.children if c.get("dbd_instance")]:
            remove_object_tree(child)

        if template is None:
            if cls:
                report.missing_child[cls if exact else "%s (class not in JSON, guessed from name)" % cls] += 1
            continue
        instantiate_blueprint(template, empty, bp.class_name, "%s_inst" % slot_name)
        report.built["spawned blueprints placed" if p.type in dbd_core.SPAWNING_TYPES else "child actors placed"] += 1
        if template not in used_templates:
            used_templates.append(template)

    # The originals sit at the world origin; once copies exist they only get in the way.
    for template in used_templates:
        if template.get("dbd_blueprint") != bp.class_name:
            _retire(template)


# --------------------------------------------------------------------------------------------
# Locating / auto-building missing child blueprints
# --------------------------------------------------------------------------------------------

class BlueprintLocator(object):
    """Finds the exported JSON of a blueprint class (e.g. 'BP_GLO_FrozenCorpse_04_C') under a folder."""

    def __init__(self, *base_dirs):
        self.bases = []
        for b in base_dirs:
            b = bpy.path.abspath(b) if b else ""
            if b and os.path.isdir(b) and b not in self.bases:
                self.bases.append(b)
        self._index = None

    def _build_index(self):
        self._index = collections.defaultdict(list)
        for base in self.bases:
            for dirpath, _dirs, files in os.walk(base):
                for f in files:
                    if f.lower().endswith(".json"):
                        self._index[os.path.splitext(f)[0].lower()].append(os.path.join(dirpath, f))

    def find(self, class_name, object_path=None):
        if not class_name or not self.bases:
            return None
        bp_name = class_name[:-2] if class_name.endswith("_C") else class_name
        rel = (object_path or "").split(".")[0].lstrip("/").replace("/", os.sep)
        direct = []
        for base in self.bases:
            for t in dbd_core.export_path_candidates(object_path):
                cand = os.path.join(base, t.replace("/", os.sep) + ".json")
                if os.path.isfile(cand):
                    direct.append(cand)
        if direct:
            return dbd_core.choose_export(direct)                  # the better export when the asset exists twice
        if self._index is None:
            self._build_index()
        hits = self._index.get(bp_name.lower(), [])
        if not hits:
            return None
        if len(hits) > 1 and rel:
            want = rel.lower().split(os.sep)
            score = lambda h: sum(1 for a, b in zip(reversed(os.path.splitext(h)[0].lower().split(os.sep)), reversed(want)) if a == b)
            top = max(score(h) for h in hits)
            hits = [h for h in hits if score(h) == top]
        return dbd_core.choose_export(hits) or hits[0]


_ACTIVE_CTX = None      # the build running now: copies of a blueprint pick their script-chosen meshes with its seed and mesh library


class BuildContext(object):
    """State shared by a build and the child blueprints it builds on demand."""

    def __init__(self, model_base_path, report, hide_hidden_in_game=True, locator=None, seed=1, spawn_scene=True,
                 gameplay=(), skip_patterns=(), lights=True, light_strength=1.0, lights_off=True,
                 light_min_radius=dbd_core.MIN_SOURCE_RADIUS_M, light_discs=False, light_spot_size=0.0,
                 light_static_no_volume=True, light_no_volume_names=(), spawn_counts=None, generator_lights=False, instancing=True, sky=False):
        global _ACTIVE_CTX
        _ACTIVE_CTX = self
        self.report = report
        self.lights = lights
        self.light_discs = light_discs                # round point lights as two back-to-back disc area lights
        self.light_spot_size = light_spot_size        # size (m) of every spot light's source: 0 = none (the cone's blend softens it)
        self.light_static_no_volume = light_static_no_volume    # lights Unreal marks Static do not scatter in fog
        self.generator_lights = generator_lights      # the spot lights just above every generator (its flood light): off unless asked for
        self.instancing = instancing                  # an instanced component becomes one Geometry Nodes instancer, not one object per instance
        self.sky = sky                                # light the World with the map's own sky light (apply_game_sky)
        self._sky_images = None
        self._sky_lighting = None
        self.light_no_volume_names = [str(t).lower() for t in light_no_volume_names]    # ... nor do lights whose name contains one of these
        self.light_min_radius = light_min_radius      # smallest light size (m): the size sets how soft the shadows are
        self.light_strength = light_strength
        self.lights_off = lights_off          # also build the lights that are off in the export, disabled and tagged
        self.seed = seed
        self.spawn_scene = spawn_scene
        self.gameplay = set(gameplay)
        self.game_categories = None                        # set by a map build the game's rules populate: what the panel asks for
        self.spawn_counts = dict(spawn_counts or {})       # applied to the placed copies only, so not part of the stamp
        self.skip_patterns = [s.lower() for s in skip_patterns]
        self.hide_hidden_in_game = hide_hidden_in_game
        self.meshes = MeshLibrary(model_base_path, report)
        self.locator = locator
        self.model_base_path = model_base_path
        self.stamp = "|".join(str(x) for x in (
            CODE_FINGERPRINT, model_base_path, seed, spawn_scene, sorted(gameplay), sorted(self.skip_patterns), hide_hidden_in_game,
            lights, light_strength, lights_off, light_min_radius, light_discs, light_spot_size,
            light_static_no_volume, sorted(self.light_no_volume_names), generator_lights, instancing))
        self._parent_locator = None
        self.in_progress = set()
        self.auto_built = []
        self.edges_by_game = False        # a full map picks its edge objects by the game's rules: its tiles leave their EdgeObjects spawners out
        self._edge_shapes = {}
        self._themes = {}                 # realm folder -> its Substitutions (or None)
        dbd_core.SUBSTITUTION_SOURCE = self.substitutions_for

    def substitutions_for(self, json_path):
        """
        The substitutions of the realm a blueprint belongs to (its own hook, pallet, lockers), from the theme whose TilePath holds the blueprint, in the
        export's LevelGen_ThemePropertiesDB.  None when no theme claims it or the export has no theme table.
        """
        folder = os.path.dirname(os.path.abspath(json_path))
        if folder not in self._themes:
            row = None
            if self.model_base_path and os.path.isdir(bpy.path.abspath(self.model_base_path)):
                tables = dbd_procgen.scan(bpy.path.abspath(self.model_base_path))[1]
                if tables.get("LevelGen_ThemePropertiesDB"):
                    row = dbd_procgen.theme_for_package(tables, dbd_procgen.package_path(dbd_procgen.asset_key(json_path)))
            self._themes[folder] = (dbd_core.Substitutions(row, self.seed, exists=lambda cls, path: bool(self.blueprint_finder()(cls, path.rsplit(".", 1)[0] + ".0")))
                                    if row else None)
        return self._themes[folder]

    def blueprint_finder(self):
        """find(class_name, object_path) for parent classes: the auto-build locator, or one over the Model Base Path."""
        if self.locator is not None:
            return self.locator.find
        if self._parent_locator is None:
            self._parent_locator = BlueprintLocator(self.model_base_path)
        return self._parent_locator.find


def ensure_child_blueprints(bp, ctx):
    """Build (recursively) every child blueprint class this blueprint needs that isn't in the scene yet."""
    for p in child_slots(bp, ctx.seed, ctx.spawn_scene, ctx.gameplay, not ctx.edges_by_game, wants_fixed_hooks(ctx)):
        if ctx.locator is None:
            cands, _ = child_class_candidates(p)
            for c in cands[:1]:
                ctx.report.child_notes.setdefault(c, "auto-build is off")
            continue
        cands, exact = child_class_candidates(p)
        if not cands or any(c in ctx.in_progress or current_root(c, ctx) is not None for c in cands):
            continue
        path_hint = p.class_path_hint()
        cls = json_path = None
        for c in cands:
            json_path = ctx.locator.find(c, path_hint)
            if json_path:
                cls = c
                break
        if not json_path:
            ctx.report.child_notes[cands[0]] = "no JSON file named %s.json under the Model Base Path" % cands[0][:-2]
            ctx.report.missing_child_json.add(cands[0] if exact else "%s (class not in JSON, guessed from name)" % cands[0])
            continue
        try:
            child = dbd_core.load_blueprint(json_path, find=ctx.blueprint_finder())
        except Exception as exc:
            ctx.report.warnings.append("%s: could not read %s (%s)" % (cls, json_path, exc))
            continue
        print("Auto-building child blueprint %s  <- %s" % (cls, json_path))
        built = build_blueprint(child, ctx=ctx)
        ctx.auto_built.append(cls)
        if built.get("dbd_blueprint") != cls:
            # the JSON defines a differently named class than the one requested - still serve it for this name
            ctx.report.warnings.append("%s.json defines class %s, not %s - using it for %s" % (
                os.path.basename(json_path)[:-5], built.get("dbd_blueprint"), cls, cls))
            built["dbd_alias"] = cls


# --------------------------------------------------------------------------------------------
# Whole-blueprint build
# --------------------------------------------------------------------------------------------

def build_blueprint(bp, model_base_path=None, report=None, hide_hidden_in_game=True, ctx=None, locator=None):
    """
    Build every component of the blueprint (meshes, instanced meshes, markers, child actors).
    With a locator, child blueprints missing from the scene are built first (recursively).
    """
    if ctx is None:
        ctx = BuildContext(model_base_path, report or Report(), hide_hidden_in_game, locator)
    report, meshes = ctx.report, ctx.meshes

    ctx.in_progress.add(bp.class_name)
    try:
        ensure_child_blueprints(bp, ctx)

        removed = remove_previous_build(bp.class_name)
        if removed:
            print("Removed %d objects from a previous build of %s" % (removed, bp.class_name))

        main = make_main_empty(bp.class_name, ctx.stamp)
        if bp.transforms_missing:
            print("!!! %s: mesh transforms are missing from this JSON export - positions will be wrong !!!" % bp.class_name)
        for w in bp.warnings:
            report.warnings.append("%s: %s" % (bp.class_name, w))

        choices = script_mesh_choices(bp)
        for p in bp.placements:
            try:
                options = choices.get(p.var) if p.is_mesh else None
                if options and not p.mesh()[0]:
                    path, name = options[0]
                    p.item.setdefault("Properties", {})["StaticMesh"] = {"ObjectName": "StaticMesh'%s'" % name, "ObjectPath": path}
                if (p.is_mesh or p.is_instanced) and _skipped_by_name(p, ctx):
                    report.skipped_by_name += 1
                elif p.is_mesh:
                    for obj in _build_mesh(p, main, meshes, report, ctx.hide_hidden_in_game) or ():
                        if options and len(options) > 1:
                            obj["dbd_mesh_choices"] = json.dumps(options)
                elif p.is_instanced:
                    _build_instanced(p, main, meshes, report, ctx.hide_hidden_in_game, bp.scatter_count, ctx.instancing)
                elif p.is_light:
                    if ctx.lights and not ctx.generator_lights and GENERATOR_CLASS.match(bp.class_name or ""):
                        report.built["generator lights (off in Lights)"] += 1
                    elif ctx.lights:
                        _build_light(p, main, bp.class_name, report, ctx.light_strength, ctx.lights_off, ctx.light_min_radius, ctx.light_discs,
                         ctx.light_spot_size, ctx.light_static_no_volume, ctx.light_no_volume_names)
                elif p.type in dbd_core.AMBIENT_LIGHT_TYPES:
                    report.built["sky lights (ambient, not built)"] += 1
                elif p.type == "BoxComponent" and p.name == "Collision" and bp.class_name.startswith("Window"):
                    _build_vault_marker(p, main, bp.class_name, report)
                elif p.is_marker:
                    marker = make_empty(p.name, display="PLAIN_AXES", size=0.15)
                    marker.parent = main
                    marker["dbd_owner"] = bp.class_name
                    marker["ue_component_type"] = p.type
                    _set_matrix(marker, p.blender_matrix())
                    marker.hide_viewport = True
                    marker.hide_render = True
                    report.built["marker empties"] += 1
            except Exception as exc:
                report.warnings.append("%s (%s): %s" % (p.name, p.type, exc))
                print("Error building %s: %s" % (p.name, exc))

        populate_child_actors(bp, main, report, seed=ctx.seed, spawn_scene=ctx.spawn_scene, gameplay=ctx.gameplay, edges=not ctx.edges_by_game,
                              fixed_hooks=wants_fixed_hooks(ctx))
    finally:
        ctx.in_progress.discard(bp.class_name)
    return main


def script_mesh_choices(bp):
    """The meshes the blueprint's construction script picks from at random (dbd_core.script_mesh_choices), from its parent class if it has no script."""
    seen = set()
    while bp is not None and id(bp) not in seen:
        seen.add(id(bp))
        found = dbd_core.script_mesh_choices(bp.items)
        if found:
            return found
        bp = bp.parent_blueprint()
    return {}


def _copy_key(obj):
    """Where a copy sits (its parents' transforms, read without a scene update): different spots give different keys."""
    parts = []
    while obj is not None:
        parts.append(tuple(round(v, 2) for v in obj.matrix_basis.translation))
        parts.append(round(obj.matrix_basis.to_euler().z, 2))
        obj = obj.parent
    return repr(parts)


def _pick_script_mesh(obj, ctx):
    """Give a copy of a randomly-meshed component (a poster) its own pick from the script's list, the same for the same seed and spot."""
    try:
        options = json.loads(obj["dbd_mesh_choices"])
    except Exception:
        return
    index = zlib.crc32(("%s|%s|%s" % (ctx.seed, obj.get("dbd_owner", ""), _copy_key(obj))).encode()) % len(options)
    path, name = options[index]
    cache = ctx.__dict__.setdefault("_script_meshes", {})
    if (path, name) not in cache:
        made = ctx.meshes.instance(path, name, "dbd_pick")
        cache[(path, name)] = made[0].data if len(made) == 1 and made[0].type == "MESH" else None
        for o in made:
            bpy.data.objects.remove(o)
    data = cache[(path, name)]
    if data is not None and obj.type == "MESH":
        obj.data = data


def _skipped_by_name(p, ctx):
    """Components the user asked to leave out (default: detect zones), matched on component and mesh name."""
    if not ctx.skip_patterns:
        return False
    hay = ((p.name or "") + " " + (p.mesh()[0] or "")).lower()
    return any(all(part in hay for part in pat.split("&")) for pat in ctx.skip_patterns)


def _unscaled(rows):
    """The matrix without its scale (a light's size comes from its own values; a scaled parent must not stretch it)."""
    cols = []
    for c in range(3):
        v = [rows[r][c] for r in range(3)]
        n = math.sqrt(sum(x * x for x in v)) or 1.0
        cols.append([x / n for x in v])
    return tuple(tuple(cols[c][r] for c in range(3)) + (rows[r][3],) for r in range(3)) + (tuple(rows[3]),)


def _build_light(p, main, class_name, report, strength=1.0, include_off=True, min_radius=dbd_core.MIN_SOURCE_RADIUS_M, discs=True,
                 spot_size=0.0, static_no_volume=True, no_volume_names=()):
    """
    A Blender light for an Unreal point / spot / rect / directional light with its exported values: colour (temperature applied), intensity
    (converted to Blender watts, times `strength`), attenuation radius, source size, cone angles.  A point / spot light with a SourceLength
    is a tube light and becomes a rectangular area light of that length (along Unreal's Z axis, the capsule axis) and twice the source radius
    thick.  A round point light becomes (with `discs`) two flat disc area lights back to back, as wide as the light's size: a disc cannot poke
    through the surface the lamp sits on the way a sphere does, its width still sets how soft the shadows are, and the point light's direction
    is meaningless (58% have no rotation), so both faces are built and the one against a wall is simply blocked.  The original Unreal
    intensity and units stay on the object (dbd_ue_*).  Lights that are off in the export (hidden, not affecting the world, zero intensity)
    are built disabled and tagged with the reason, or not at all without `include_off`.
    """
    info = p.light_info()
    if info["switched_off"]:
        if not include_off:
            report.built["lights switched off (not built)"] += 1
            return
        report.built["lights off in the export (built disabled)"] += 1
    btype = info["blender_type"]
    scatter = info["volume_factor"]
    static_off = bool(static_no_volume and info["is_static"])
    named_off = next((t for t in no_volume_names if t and t in (p.name or "").lower()), None)
    class_off = NO_FOG_CLASS.match(class_name or "")
    if class_off and not named_off:
        named_off = "class " + class_name
    if static_off or named_off:
        scatter = 0.0              # Unreal's volumetric fog does not pick up static (baked) lights; named lights are skipped by choice
    disc_pair = discs and btype == "POINT"
    base = dbd_core.mat_mul(_unscaled(p.blender_matrix()), dbd_core.LIGHT_FRAME_FIX)
    forward = 0.0
    if btype == "SPOT":
        # A spot light usually sits against a ceiling or wall and shines away from it; a round source (spot_size > 0) would sink half into that
        # surface and be blocked by it.  Sliding the light forward by its radius puts the source in front.  With the default size 0 there is
        # no source sphere (the sharp-tipped cone only; the blend softens the beam) and nothing to move.
        forward = min(max(spot_size, 0.0), dbd_core.MAX_SOURCE_RADIUS_M)
        base = dbd_core.mat_mul(base, ((1.0, 0.0, 0.0, 0.0), (0.0, 1.0, 0.0, 0.0), (0.0, 0.0, 1.0, -forward), (0.0, 0.0, 0.0, 1.0)))
    if disc_pair:
        # A point light shines every way and its rotation means nothing (58% have none, which aimed the discs sideways: a ceiling lamp lit the
        # walls and only grazed the floor).  The pair faces down and up instead, wherever the light sits.
        base = ((1.0, 0.0, 0.0, base[0][3]), (0.0, 1.0, 0.0, base[1][3]), (0.0, 0.0, 1.0, base[2][3]), (0.0, 0.0, 0.0, 1.0))
    sides = [(p.name, base, 1.0)]
    if disc_pair:
        # the second disc faces the other way: a half turn about the light's local y
        sides.append((p.name + "_back", dbd_core.mat_mul(base, ((-1.0, 0.0, 0.0, 0.0), (0.0, 1.0, 0.0, 0.0), (0.0, 0.0, -1.0, 0.0), (0.0, 0.0, 0.0, 1.0))), 1.0))
    for name, matrix, _share in sides:
        data = bpy.data.lights.new(name=name, type="AREA" if disc_pair else btype)
        data.color = info["color"]
        data.energy = info["watts"] * strength / (2.0 if disc_pair else 1.0)          # the two discs share the point light's power
        data.use_shadow = info["cast_shadows"]
        data.specular_factor = info["specular_scale"]
        try:
            data.volume_factor = scatter                   # EEVEE: how strongly the light scatters in volumes (Unreal VolumetricScatteringIntensity)
        except AttributeError:
            pass
        if btype == "SUN":
            data.angle = math.radians(min(max(info["source_angle_degrees"], SUN_MIN_ANGLE_DEG), 180.0))
        else:
            data.use_custom_distance = True
            data.cutoff_distance = max(info["radius_m"], 0.01)
        if disc_pair:
            data.shape = "DISK"
            data.size = 2.0 * dbd_core.soft_radius(info["source_radius_ue_m"], min_radius)
        elif btype == "AREA":
            data.shape = "RECTANGLE"
            if info["kind"] == "AREA":
                data.size = max(info["height_m"], 0.01)       # the light's local x is Unreal's z (see dbd_core.LIGHT_FRAME_FIX)
                data.size_y = max(info["width_m"], 0.01)
            else:                                             # tube: its axis is Unreal's z, i.e. the light's local x
                data.size = info["tube_length_m"]
                data.size_y = max(info["thickness_m"], 2.0 * dbd_core.soft_radius(info["source_radius_ue_m"], min_radius))
                if info["kind"] == "SPOT":
                    data.spread = math.radians(min(max(2.0 * info["outer_degrees"], 1.0), 180.0))
        elif btype == "SPOT":
            data.shadow_soft_size = forward
        elif btype == "POINT":
            data.shadow_soft_size = dbd_core.soft_radius(info["source_radius_ue_m"], min_radius)
        if btype == "SPOT":
            outer = min(max(info["outer_degrees"], 1.0), 89.0)
            data.spot_size = math.radians(2.0 * outer)
            data.spot_blend = min(max(1.0 - min(info["inner_degrees"], outer) / outer, 0.0), 1.0)
        obj = bpy.data.objects.new(name, data)
        obj.visible_camera = False          # Unreal never draws a light; here the source would show as a glowing shape poking out of meshes
        try:
            obj.visible_volume_scatter = scatter > 0.0      # Cycles has no per-light volume power: only whether it scatters at all
        except AttributeError:
            pass
        _link(obj)
        obj.parent = main
        obj["dbd_owner"] = class_name
        obj["ue_component_type"] = p.type
        obj["dbd_ue_intensity"] = info["ue_intensity"]
        obj["dbd_ue_source_radius_m"] = info["source_radius_ue_m"]        # Blender's size is clamped, see dbd_core.soft_radius
        obj["dbd_ue_units"] = info["ue_units"] + (" (assumed)" if info["units_guessed"] else "")
        obj["dbd_ue_candela"] = info["candela"]
        obj["dbd_ue_volume_scatter"] = info["volume_factor"]
        obj["dbd_ue_mobility"] = info["mobility"]
        if static_off or named_off:
            obj["dbd_ue_volume_scatter_off"] = "static light" if static_off else (named_off if named_off.startswith("class ") else "name contains '%s'" % named_off)
        obj["dbd_ue_specular_scale"] = info["specular_scale"]
        if info["unmapped"]:
            obj["dbd_ue_unmapped"] = ", ".join(info["unmapped"])
        if disc_pair:
            obj["dbd_ue_disc_pair"] = sides[1][0] if name == sides[0][0] else sides[0][0]
        if info["temperature"] is not None:
            obj["dbd_ue_temperature"] = info["temperature"]
        if info["tube_length_m"]:
            obj["dbd_ue_tube_length_m"] = info["tube_length_m"]
        if forward:
            obj["dbd_ue_offset_forward_m"] = forward                      # moved this far along its aim, see above
        if info["switched_off"]:
            obj["dbd_ue_off"] = info["off_reason"]
            obj.hide_render = True
            obj.hide_viewport = True
        _set_matrix(obj, matrix)
    report.built["lights"] += 1
    if static_off:
        report.built["static lights (volume scatter off)"] += 1
    elif named_off:
        report.built["lights %s (volume scatter off)" % (named_off if named_off.startswith("class ") else "named '%s'" % named_off)] += 1
    for what in info["unmapped"]:
        report.built["lights: %s (not reproduced in Blender)" % what] += 1
    if disc_pair:
        report.built["disc lights (second, back-facing half)"] += 1


def _build_vault_marker(p, main, class_name, report):
    """The vault blueprint has no mesh of its own (the window frame is tile art): show its blocking box."""
    half = (0.65, 0.15, 0.5)                      # metres, centred on the Collision box origin
    scale = ((half[0], 0, 0, 0), (0, half[1], 0, 0), (0, 0, half[2], 0), (0, 0, 0, 1))
    marker = make_empty("vault_zone", display="CUBE", size=1.0)
    marker.parent = main
    marker["dbd_owner"] = class_name
    marker["ue_component_type"] = "VaultCollision"
    _set_matrix(marker, dbd_core.mat_mul(p.blender_matrix(), scale))
    marker.hide_render = True
    report.built["vault markers"] += 1


def _atlas_cell(p):
    """The component's CustomPrimitiveData poster cell plus 1, or 0 (see dbd_atlas_cell)."""
    custom = p.props.get("CustomPrimitiveData")
    data = custom.get("Data") if isinstance(custom, dict) else None
    if data and isinstance(data[0], (int, float)) and 0 <= data[0] < 256 and data[0] == int(data[0]):      # some hold garbage: -1.8e38 on a Liminal ceiling
        return float(data[0]) + 1.0
    return 0.0


def _finish_instance(obj, p, main, class_name, matrix_rows, hide_hidden_in_game):
    obj.parent = main
    obj["dbd_owner"] = class_name
    _set_matrix(obj, matrix_rows)
    cell = _atlas_cell(p)
    if cell:
        obj["dbd_atlas_cell"] = cell
    if p.hidden_in_game:
        obj["ue_hidden_in_game"] = True
        if hide_hidden_in_game:
            obj.hide_render = True
            obj.hide_viewport = True                 # unlike the temporary hide, this carries over to the copies placed on a map
            _hide(obj)


def _build_mesh(p, main, meshes, report, hide_hidden_in_game):
    mesh_name, mesh_path = p.mesh()
    if not mesh_name:
        return
    if p.is_engine_shape():
        report.skipped_engine_shapes += 1
        return
    objs = meshes.instance(mesh_path, mesh_name, p.name)
    for obj in objs:
        _finish_instance(obj, p, main, main["dbd_owner"], p.blender_matrix(), hide_hidden_in_game)
        apply_override_materials(obj, p.override_materials(), report)
        report.built["meshes"] += 1
    return objs


def instancer_group():
    """The Geometry Nodes group every instancer uses: a copy of its Source object on each point, moved by the point's dbd_transform."""
    ng = bpy.data.node_groups.get(INSTANCER_GROUP)
    if ng is not None and ng.get("dbd_version") == INSTANCER_VERSION:
        return ng
    if ng is not None:
        ng.name = INSTANCER_GROUP + " (old)"
    ng = bpy.data.node_groups.new(INSTANCER_GROUP, "GeometryNodeTree")
    ng["dbd_version"] = INSTANCER_VERSION
    ng.is_modifier = True
    ng.interface.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    ng.interface.new_socket("Source", in_out="INPUT", socket_type="NodeSocketObject")
    ng.interface.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
    nodes, links = ng.nodes, ng.links
    group_in, group_out = nodes.new("NodeGroupInput"), nodes.new("NodeGroupOutput")
    info = nodes.new("GeometryNodeObjectInfo")
    info.transform_space = "ORIGINAL"
    info.inputs["As Instance"].default_value = True
    on_points = nodes.new("GeometryNodeInstanceOnPoints")
    transform = nodes.new("GeometryNodeInputNamedAttribute")
    transform.data_type = "FLOAT4X4"
    transform.inputs["Name"].default_value = TRANSFORM_ATTRIBUTE
    place = nodes.new("GeometryNodeSetInstanceTransform")
    links.new(group_in.outputs[0], on_points.inputs["Points"])
    links.new(group_in.outputs[1], info.inputs["Object"])
    links.new(info.outputs["Geometry"], on_points.inputs["Instance"])
    links.new(on_points.outputs["Instances"], place.inputs["Instances"])
    links.new(transform.outputs["Attribute"], place.inputs["Transform"])
    links.new(place.outputs["Instances"], group_out.inputs[0])
    for x, node in enumerate((group_in, info, on_points, place, group_out)):
        node.location = (x * 220, 0)
    transform.location = (2 * 220, -220)
    return ng


def make_instancer(name, source, matrices_rows):
    """
    One object placing a copy of `source` at every Blender-space 4x4 in `matrices_rows`: a point per instance (at its position, so selecting and
    framing work) holding the full transform in dbd_transform, and the shared instancer group as a modifier.
    """
    rows = np.asarray(matrices_rows, dtype=np.float32).reshape(-1, 4, 4)
    points = bpy.data.meshes.new(name)
    points.vertices.add(len(rows))
    points.vertices.foreach_set("co", rows[:, :3, 3].ravel())
    attribute = points.attributes.new(TRANSFORM_ATTRIBUTE, "FLOAT4X4", "POINT")
    attribute.data.foreach_set("value", rows.transpose(0, 2, 1).ravel())         # Blender stores the matrix column by column
    obj = bpy.data.objects.new(name, points)
    group = instancer_group()
    modifier = obj.modifiers.new("DbD Instances", "NODES")
    modifier.node_group = group
    modifier[group.interface.items_tree["Source"].identifier] = source
    obj["dbd_instance_source"] = source
    obj["dbd_instance_count"] = len(rows)
    obj["dbd_group"] = source.get("dbd_group") or "Other"
    _link(obj)
    return obj


def _build_instanced(p, main, meshes, report, hide_hidden_in_game, limit=None, instancing=True):
    mesh_name, mesh_path = p.mesh()
    if not mesh_name or p.is_engine_shape():
        if p.is_engine_shape():
            report.skipped_engine_shapes += 1
        return
    matrices = p.instances()
    if not matrices:
        report.missing_instance_data.append((p.name, p.expected_instance_count()))
        return
    if limit and len(matrices) > limit:
        # a scatter blueprint: as many as it places, spread over the editor's leftovers (the game picks its own spots from a seed the export cannot reproduce)
        step = len(matrices) / float(limit)
        matrices = [matrices[int(i * step)] for i in range(limit)]
        report.built["scatter blueprints cut to their count"] += 1
    if instancing and len(matrices) > 1:
        rows = [dbd_core.ue_to_blender(world) for world in matrices]
        for source in meshes.source(mesh_path, mesh_name, p.override_materials(), _atlas_cell(p)):
            obj = make_instancer(p.name, source, rows)
            _finish_instance(obj, p, main, main["dbd_owner"], mathutils.Matrix.Identity(4), hide_hidden_in_game)
            report.built["instanced meshes"] += len(rows)
            report.built["instancers (one object per instanced component)"] += 1
        return
    for i, world in enumerate(matrices):
        for obj in meshes.instance(mesh_path, mesh_name, "%s_Instance_%d" % (p.name, i)):
            _finish_instance(obj, p, main, main["dbd_owner"], dbd_core.ue_to_blender(world), hide_hidden_in_game)
            apply_override_materials(obj, p.override_materials(), report)
            report.built["instanced meshes"] += 1


# --------------------------------------------------------------------------------------------
# Whole-map build (Script 4)
# --------------------------------------------------------------------------------------------

def ensure_tile_built(tile, ctx):
    """Build a tile blueprint (and its children) if it isn't in the scene yet (or was built by other code / with other settings)."""
    if current_root(tile.class_name, ctx) is not None:
        return True
    try:
        bp = dbd_core.load_blueprint(tile.json_path, find=ctx.blueprint_finder())
    except Exception as exc:
        ctx.report.warnings.append("%s: could not read %s (%s)" % (tile.name, tile.json_path, exc))
        return False
    print("Building tile %s" % tile.name)
    build_blueprint(bp, ctx=ctx)
    ctx.auto_built.append(tile.class_name)
    return True


def _prune_directional_spawns(instance_root, pl, border_cells, report):
    """
    Keep a placed border tile's optional fence spokes / edge pillars only where the fence line continues: toward a neighbouring
    border tile.  (The tile blueprint builds all four spokes; which ones the generator switches on depends on the map.)
    """
    own = set(pl.cells())
    doomed = []
    for obj in list(instance_root.children_recursive):         # collect first: removing a slot also removes its children
        tag = obj.get("dbd_dir")
        if not tag:
            continue
        dx, dy = dbd_core.rotate_direction(tag, pl.yaw)
        if not any((c + dx, r + dy) in border_cells for (c, r) in own if (c + dx, r + dy) not in own):
            doomed.append(obj)
    removed = 0
    for obj in doomed:
        try:
            remove_object_tree(obj)
            removed += 1
        except ReferenceError:                                   # already gone with an earlier tree
            pass
    if removed:
        report.built["fence spokes/pillars pruned"] += removed


def apply_variations(instance, plan, index, tile, owner, ctx):
    """Swap the objects the map's colour tag on this tile's cell changes.  Returns the templates it used, to hide."""
    if not getattr(plan, "game", None):
        return []
    tag = dbd_procgen.cell_tag(plan, index)
    if not tag:
        return []
    try:
        bp = dbd_core.load_blueprint(tile.json_path, find=ctx.blueprint_finder())
    except Exception as exc:
        ctx.report.warnings.append("%s: could not read it for its variations (%s)" % (tile.name, exc))
        return []
    slots = {o.get("dbd_cac"): o for o in instance.children_recursive if o.get("dbd_cac")}
    templates = []
    for name, path in dbd_procgen.tile_variations(bp, tag).items():
        slot = slots.get(name + "_spawn")
        if slot is None:
            continue
        template = ensure_class_built(path.rsplit(".", 1)[-1], path, ctx)
        if template is None:
            continue
        for child in [c for c in slot.children if c.get("dbd_instance")]:
            remove_object_tree(child)
        instantiate_blueprint(template, slot, owner, "%s_variation" % name)
        ctx.report.built["objects swapped by map tags"] += 1
        if template not in templates:
            templates.append(template)
    return templates


# Meshes that stand in for no collision, and the tree meshes whose trunk stands in for theirs: the game tests edge objects against collision, which is not in
# what the add-on reads.  Tree collision is the trunk, and leaves, grass and the like have none.
NO_COLLISION_MESH = re.compile(r"leaves|leaf|grass|fern|bush|foliage|flower|weed|ivy|vine|moss|decal|petal|clover|reed|bulrush", re.I)
TREE_MESH = re.compile(r"tree|fir|larch|pine|birch|oak|spruce|cedar|trunk|palm|willow|maple|elm", re.I)
TRUNK_HEIGHT = 600.0         # cm above the mesh's base whose width stands in for the tree's collision.  Calibrated on FModel's Ind_CoalTower export, which
                             # holds the edge objects the game keeps: 9 of 231.  At 6 m this keeps 7, all right; at 1.5 m it kept 21, 13 of them wrong.


def edge_shapes(ctx):
    """shapes(object_path, mesh_name) for dbd_procgen.build_edges: the mesh's boxes in its own Unreal space (cm), from the meshes the build imports."""
    def shapes(object_path, mesh_name):
        if not mesh_name or mesh_name in dbd_core.ENGINE_SHAPES or NO_COLLISION_MESH.search(mesh_name):
            return []
        filepath, _tried = ctx.meshes.resolve_file(object_path, mesh_name)
        if not filepath:
            return []
        key = ctx.meshes._key(filepath)
        if key in ctx._edge_shapes:
            return ctx._edge_shapes[key]
        boxes = []
        try:
            if not ctx.meshes._cache_loaded:
                ctx.meshes._load_cache()
            if not ctx.meshes._master_alive(key):
                ctx.meshes.masters[key] = ctx.meshes._import_master(filepath, key)
            for master in ctx.meshes.masters[key]:
                me = master.data
                co = np.empty(len(me.vertices) * 3, dtype=np.float32)
                me.vertices.foreach_get("co", co)
                co = co.reshape(-1, 3) * np.array((100.0, -100.0, 100.0), dtype=np.float32)       # back to Unreal: cm, Y the other way
                if not len(co):
                    continue
                if TREE_MESH.search(mesh_name):
                    base = co[:, 2].min()
                    low = co[co[:, 2] <= base + TRUNK_HEIGHT]
                    lo, hi = low.min(axis=0), low.max(axis=0)
                    boxes.append(((float(lo[0]), float(lo[1]), float(base)), (float(hi[0]), float(hi[1]), float(co[:, 2].max()))))
                else:
                    lo, hi = co.min(axis=0), co.max(axis=0)
                    boxes.append((tuple(float(v) for v in lo), tuple(float(v) for v in hi)))
        except Exception as exc:
            ctx.report.warnings.append("edge objects: could not measure %s (%s)" % (mesh_name, exc))
        ctx._edge_shapes[key] = boxes
        return boxes
    return shapes


def place_gameplay(main, plan, owner, ctx):
    """Hooks, pallets, totems, chests, generators, hatch, basement and the randomizer groups, from the game's rules.  Returns the templates used, to hide."""
    finder = ctx.blueprint_finder()

    def find(class_name, object_path=None):
        hint = (object_path or "").rsplit(".", 1)[0] + ".0" if object_path else None
        return finder(class_name, hint)

    actors, removed = dbd_procgen.plan_gameplay(plan, find, edge_shapes(ctx) if ctx.edges_by_game else None)
    bpy.context.view_layer.update()
    spawned = [o for o in main.children_recursive if str(o.get("dbd_cac") or "").endswith("_spawn")]
    for o in [o for o in spawned if o.get("dbd_generated")]:
        try:
            remove_object_tree(o)
        except ReferenceError:
            pass
    if removed:
        slots = {}
        for o in main.children_recursive:
            if str(o.get("dbd_cac") or "").endswith("_spawn"):
                t = o.matrix_world.translation
                slots.setdefault((round(t.x, 1), round(t.y, 1)), []).append(o)
        for matrix in removed:
            m = dbd_core.ue_to_blender(matrix)
            for o in slots.get((round(m[0][3], 1), round(m[1][3], 1)), []):
                try:
                    remove_object_tree(o)
                except ReferenceError:
                    pass
    templates = []
    wanted = ctx.game_categories if ctx.game_categories is not None else ctx.gameplay
    for name, cls, path, matrix in actors:
        category = dbd_core.gameplay_class_category(cls)
        if category and category not in wanted:
            continue
        if not category and not ctx.spawn_scene:
            continue
        template = ensure_class_built(cls, path, ctx)
        if template is None:
            ctx.report.missing_child[cls] += 1
            continue
        slot = make_empty("Game_%s" % cls[:-2], size=0.3)
        slot.parent = main
        slot["dbd_owner"] = owner
        if category:
            slot["dbd_gameplay"] = category
        _set_matrix(slot, dbd_core.ue_to_blender(matrix))
        instantiate_blueprint(template, slot, owner, "%s_inst" % cls[:-2])
        ctx.report.built["%s from the game's rules" % (category or "scenery")] += 1
        if template not in templates:
            templates.append(template)
    return templates


def choose_gameplay(main, plan, ctx):
    """Keep only the seeded choice of generators / pallets / totems / lockers on the placed copies (the built tile blueprints keep every spawn point)."""
    if not any(ctx.spawn_counts.values()):
        return
    bpy.context.view_layer.update()
    candidates = [(o.get("dbd_gameplay"), o.name, tuple(o.matrix_world.translation)) for o in main.children_recursive
                  if o.get("dbd_gameplay") and o.children]          # an empty slot (its blueprint is missing) is not a candidate
    doomed, stats = dbd_map.choose_spawns(candidates, ctx.spawn_counts, ctx.seed, plan.tilemap.name)
    for name in doomed:
        if name in bpy.data.objects:                                # may have gone with an earlier tree
            remove_object_tree(bpy.data.objects[name])
    for cat in sorted(stats):
        kept, offered = stats[cat]
        ctx.report.built["%s kept by the seed (of %d spots)" % (cat, offered)] += kept
        if kept < ctx.spawn_counts[cat]:
            ctx.report.warnings.append("map: only %d %s spots for the %d asked for" % (offered, cat, ctx.spawn_counts[cat]))


def ensure_class_built(cls, object_path, ctx):
    """The built template of blueprint class `cls`, building it (and its children) from its JSON when needed; None when it cannot be found."""
    template = current_root(cls, ctx)
    if template is not None:
        return template
    if ctx.locator is None:
        ctx.report.child_notes.setdefault(cls, "auto-build is off")
        return None
    hint = (object_path or "").rsplit(".", 1)[0] + ".0" if object_path else None
    json_path = ctx.locator.find(cls, hint)
    if not json_path:
        ctx.report.child_notes[cls] = "no JSON file named %s.json under the Model Base Path" % cls[:-2]
        ctx.report.missing_child_json.add(cls)
        return None
    try:
        child = dbd_core.load_blueprint(json_path, find=ctx.blueprint_finder())
    except Exception as exc:
        ctx.report.warnings.append("%s: could not read %s (%s)" % (cls, json_path, exc))
        return None
    print("Auto-building room blueprint %s  <- %s" % (cls, json_path))
    build_blueprint(child, ctx=ctx)
    ctx.auto_built.append(cls)
    return current_root(cls, ctx) or find_blueprint_root(cls)


def _room_pool(ctx, realm_tag):
    """[(class, object path)] of the room blueprints (InterTile quads) of the realm a 'QCT_<Realm>' tag names, found by their '<NN>-<Realm>_Quads' folder."""
    word = (realm_tag or "")[4:].lower()
    if not word or ctx.locator is None:
        return []
    if ctx.locator._index is None:
        ctx.locator._build_index()
    out = []
    for hits in ctx.locator._index.values():
        for h in hits:
            folder = os.path.basename(os.path.dirname(h))
            if folder.lower().endswith("_quads") and word in folder.lower() and os.path.basename(h).startswith("BP_"):
                stem = os.path.splitext(os.path.basename(h))[0]
                out.append((stem + "_C", "/Game/Blueprints/Tiles/InterTile/%s/%s.%s_C" % (folder, stem, stem)))
    return sorted(set(out))


def _square_room_for(ctx, cls, object_path, rng):
    """A square room of the same family and realm as the Rect room `cls` (a Rect room needs a free neighbouring vertex; a square one does not)."""
    if ctx.locator is None:
        return None
    hint = (object_path or "").rsplit(".", 1)[0] + ".0"
    json_path = ctx.locator.find(cls, hint)
    if not json_path:
        return None
    folder = os.path.dirname(json_path)
    fam = re.search(r"_rect?_([A-Za-z]+)_", cls, re.I)
    fam = fam.group(1).lower() if fam else ""
    names = sorted(os.path.splitext(f)[0] for f in os.listdir(folder)
                   if f.lower().endswith(".json") and re.search(r"_(square|sqr)_", f, re.I))
    pref = [n for n in names if fam and ("_%s_" % fam) in n.lower()] or names
    if not pref:
        return None
    n = rng.choice(pref)
    return n + "_C", (object_path or "").rsplit("/", 1)[0] + "/%s.%s_C" % (n, n)


def build_quadrants(plan, ctx, main, owner, row_sign=1.0):
    """
    Place the map's rooms (see dbd_map.plan_quadrants): one InterTile blueprint on every grid vertex where the tiles around it all have a room slot.
    These are the rooms between the corridors (Qatar, Hospital): tiles themselves only carry empty slots for them.
    """
    blueprints = {}

    def slots_of(tile):
        if tile.name not in blueprints:
            try:
                blueprints[tile.name] = dbd_core.load_blueprint(tile.json_path, find=ctx.blueprint_finder())
            except Exception:
                blueprints[tile.name] = None
        bp = blueprints[tile.name]
        if bp is None:
            return []
        return [(q.quadrant()[0], q.quadrant()[1], q.world, q.quadrant_realm()) for q in bp.quadrant_placements()]

    def blueprint_of(tile):
        slots_of(tile)
        return blueprints[tile.name]

    rooms = None
    if getattr(plan, "game", None):
        try:
            rooms = dbd_procgen.plan_rooms(plan, blueprint_of)
        except dbd_procgen.Unavailable as exc:
            print("The game's room rules can't run on this export (%s): using the add-on's own." % exc)
    if rooms is None:
        rooms = dbd_map.plan_quadrants(plan, slots_of, seed=ctx.seed, row_sign=row_sign,
                                       square_for=lambda cls, path, rng: _square_room_for(ctx, cls, path, rng),
                                       pool_for=lambda realm: _room_pool(ctx, realm))
    templates = []
    for i, (cls, path, m_ue) in enumerate(rooms):
        template = ensure_class_built(cls, path, ctx)
        if template is None:
            ctx.report.missing_child[cls] += 1
            continue
        slot = make_empty("Room_%s_%d" % (cls[:-2], i), size=0.5)
        slot.parent = main
        slot["dbd_owner"] = owner
        slot["dbd_room"] = cls
        _set_matrix(slot, dbd_core.ue_to_blender(m_ue))
        instantiate_blueprint(template, slot, owner, "%s_inst" % cls[:-2])
        ctx.report.built["rooms placed"] += 1
        if template not in templates:
            templates.append(template)
    return templates


GAME_EXPOSURE = 1.0


GENERATOR_CLASS = re.compile(r"^Generator", re.I)       # GeneratorStandard_C, GeneratorShort_C, GeneratorIndoor_C, GeneratorNoPole_C ...
# Lights that never light the fog, whatever their mobility: the ones above every generator and the ones in front of the dungeon portals
# (BP_PassageInteractableEntranceBase: a point and a spot light).
NO_FOG_CLASS = re.compile(r"^(Generator|BP_PassageInteractable)", re.I)


SKY_WORLD = "DbD Sky"
SKY_HORIZON_DROP_DEG = 10.0   # the sky dome is lowered this far, so its bottom edge sits under the map's far edge, not at eye level
SUN_MIN_ANGLE_DEG = 10.0      # a sun lamp's angle never goes below this: the game's 0.5 degrees gave razor-sharp moonlight shadows
SKY_PARTS_REACH_M = 800.0     # sky meshes further out than this (the moon, 3.7 km in the game) are drawn in, past Blender's 1 km view distance
SKY_PARTS_MARGIN = 1.15       # ... to this much further out than the furthest object they must stay behind
SKY_PARTS_MIN_M = 150.0       # ... and never nearer than this
SKY_IMAGE_EXTENSIONS = (".hdr", ".exr", ".png", ".tga", ".jpg")


def _theme_tables(ctx):
    base = bpy.path.abspath(ctx.model_base_path) if ctx.model_base_path else ""
    return dbd_procgen.scan(base)[1] if base and os.path.isdir(base) else {}


def game_sky_light(ctx, theme):
    """
    The sky light of a theme, from the data alone: its LevelGen_LightDataDB row names the lighting (an ambiance asset or a lighting blueprint), whose
    SkyLightComponent holds the sky's HDRI, intensity and colour.  Returns (properties, lighting file name) or (None, why there is none).
    """
    row = dbd_procgen.light_row(_theme_tables(ctx), theme)
    if row is None:
        return None, "the theme has no row in LevelGen_LightDataDB"
    asset = dbd_procgen.light_asset(row)
    if not asset:
        return None, "its LevelGen_LightDataDB row names no lighting"
    name = asset.rsplit(".", 1)[-1]
    json_path = ctx.blueprint_finder()(name, asset.split(".")[0] + ".0")
    if not json_path:
        return None, "%s is not in the export" % name
    items = dbd_procgen.read_json(json_path)
    skies = [i for i in items if isinstance(i, dict) and i.get("Type") == "SkyLightComponent"]
    if not skies:
        return None, "%s has no sky light" % name
    props = {}
    for item in skies:                                   # the template, then what the placed copy overrides
        props.update(item.get("Properties") or {})
    ctx._sky_lighting = (json_path, items, name.removesuffix("_C"))
    return props, name.removesuffix("_C")


def build_game_sky_parts(scene, ctx, origin_uu=None):
    """
    What else the lighting file the sky came from holds: its directional lights (the moon's light) as Sun lamps, converted like every other light, and
    its meshes (the moon itself, a sky sphere or dome) through the normal mesh builder, so the data's own visibility flags apply.  Lights that are off
    in the export (not affecting the world, no intensity: the god-ray helper lights) are left out.  Everything goes under one "DbD Sky" empty and
    replaces the parts of an earlier build.  Returns (lamps, meshes).
    """
    json_path, items, source = getattr(ctx, "_sky_lighting", None) or (None, None, None)
    _remove_objects([o for o in bpy.data.objects if o.get("dbd_sky_part")])
    if not json_path:
        return 0, 0
    if any(isinstance(i, dict) and i.get("Type") == "BlueprintGeneratedClass" for i in items):
        placements = dbd_core.load_blueprint(json_path, find=ctx.blueprint_finder()).placements
    else:                                                 # an ambiance data asset: each component carries its own transform
        placements = [dbd_core.Placement(i.get("Name") or "Part", None, i, dbd_core.local_matrix_ue(i.get("Properties")), "loose", None)
                      for i in items if isinstance(i, dict) and "Type" in i]
    lights = [pl for pl in placements if pl.type == "DirectionalLightComponent"]
    # The meshes (Meteor's road running off the map, the floating earth around it, the moon) are laid out around the game's world origin, which the
    # game puts at the centre of the map's first cell.  Without a map that place is unknown, and the scenery would land on the tile: left out.
    meshes = [pl for pl in placements if pl.is_mesh] if origin_uu is not None else []
    if not lights and not meshes:
        return 0, 0
    holder = make_empty("DbD Sky", size=1.0)
    holder["dbd_owner"] = source
    holder["dbd_sky_part"] = source
    if origin_uu is not None:
        _set_matrix(holder, dbd_core.ue_to_blender(dbd_core.compose_trs((origin_uu[0], origin_uu[1], 0.0), dbd_core.rotator_matrix(0.0, 0.0, 0.0), (1.0, 1.0, 1.0))))
    before = set(bpy.data.objects)
    for pl in lights:
        _build_light(pl, holder, source, ctx.report, ctx.light_strength, include_off=False, min_radius=ctx.light_min_radius, discs=False,
                     static_no_volume=ctx.light_static_no_volume, no_volume_names=ctx.light_no_volume_names)
    lamps = sum(1 for o in bpy.data.objects if o not in before and o.type == "LIGHT")
    for pl in meshes:
        _build_mesh(pl, holder, ctx.meshes, ctx.report, ctx.hide_hidden_in_game)
    made = [o for o in holder.children_recursive if o not in before]    # not the mesh library's hidden copy of the moon, imported on the way
    for o in made:
        o["dbd_sky_part"] = source
    built = sum(1 for o in made if o.type == "MESH")
    if not made:
        _remove_objects([holder])
        return lamps, built
    # Only what lies past the view distance (Clip End) is drawn in toward the map's centre - the moon, 3.7 km out - each by its own factor, so it keeps
    # its direction and apparent size.  Everything nearer stays where the game puts it: Meteor's lighting blueprint also holds the earth chunks
    # floating in the void around the map, and drawing the whole group in by the moon's factor dropped them onto the map.
    bpy.context.view_layer.update()
    def reach_of(o):
        return max((o.matrix_world @ mathutils.Vector(corner)).length for corner in o.bound_box)
    far = {o: reach_of(o) for o in made if o.type == "MESH"}
    far = {o: r for o, r in far.items() if r > SKY_PARTS_REACH_M}
    # As close as possible while still behind everything else: just past the furthest of the map and the nearer sky scenery.
    nearest = 0.0
    for o in bpy.data.objects:
        if o.type == "MESH" and o not in far and o.visible_get():
            nearest = max(nearest, o.matrix_world.translation.length + max(o.dimensions) * 0.5)
    target = min(SKY_PARTS_REACH_M, max(nearest * SKY_PARTS_MARGIN, SKY_PARTS_MIN_M))
    for o, reach in far.items():
        factor = target / reach
        o.matrix_world = mathutils.Matrix.Scale(factor, 4) @ o.matrix_world
        o["dbd_sky_scale"] = factor                      # 1 / this is the game's own distance
        print("Sky mesh %s drawn in from %.0f m to %.0f m (scale %.4f): same direction and apparent size" % (o.name, reach, target, factor))
    return lamps, built


def find_sky_image(ctx, object_path):
    """The exported image of a texture asset: where its game path puts it under the Exports Folder, else any file of that name under it."""
    base = bpy.path.abspath(ctx.model_base_path) if ctx.model_base_path else ""
    if not base or not os.path.isdir(base):
        return None
    for rel in dbd_core.export_path_candidates(object_path):
        for ext in SKY_IMAGE_EXTENSIONS:
            cand = os.path.join(base, rel.replace("/", os.sep) + ext)
            if os.path.isfile(cand):
                return cand
    if ctx._sky_images is None:
        ctx._sky_images = {}
        for dirpath, _dirs, files in os.walk(base):
            for f in files:
                stem, ext = os.path.splitext(f)
                if ext.lower() in SKY_IMAGE_EXTENSIONS:
                    ctx._sky_images.setdefault(stem.lower(), os.path.join(dirpath, f))
    stem = (object_path or "").split(".")[0].rsplit("/", 1)[-1].lower()
    return ctx._sky_images.get(stem)


def _sky_colour(value, default):
    """A light colour as linear RGB: FColor bytes (LightColor) or a FLinearColor (LowerHemisphereColor)."""
    if not isinstance(value, dict):
        return default
    rgb = [value.get(k) for k in ("R", "G", "B")]
    if any(v is None for v in rgb):
        return default
    if all(isinstance(v, int) for v in rgb) and max(rgb) > 1:
        return tuple(dbd_core.srgb_to_linear(v) for v in rgb)
    return tuple(float(v) for v in rgb)


def apply_game_sky(scene, ctx, theme=None, map_package=None, json_path=None, origin_uu=None):
    """
    Light the World with the map's own sky light (the "Sky lighting from the game" option): its HDRI as the environment, tinted by its LightColor, at
    Intensity x Light Strength / 683 (the conversion the lamps use, so the two stay in balance), black or its LowerHemisphereColor below the horizon.
    The theme comes from the map (map_package) or the blueprint's tile folder (json_path).  origin_uu: where the game's world origin lies in the
    build (Unreal units), on a full map; the lighting blueprint sits there, and its meshes (vista scenery, the moon) are only built when it is known.
    """
    if not ctx.sky:
        return
    warn = ctx.report.warnings.append
    try:
        tables = _theme_tables(ctx)
        if theme is None and map_package:
            try:
                theme = dbd_procgen.resolve_theme(tables, map_package)
            except dbd_procgen.Unavailable:
                theme = None
        if theme is None and json_path:
            theme = dbd_procgen.theme_for_package(tables, dbd_procgen.package_path(dbd_procgen.asset_key(json_path)))
        if theme is None:
            warn("sky: no theme in LevelGen_ThemePropertiesDB claims this map or blueprint, so its sky is unknown")
            return
        props, source = game_sky_light(ctx, theme)
        if props is None:
            warn("sky: %s" % source)
            return
        if "Captured" in str(props.get("SourceType", "SLS_CapturedScene")):
            warn("sky: %s's sky light captures the scene itself rather than an HDRI: nothing to load" % source)
            return
        cube = (props.get("Cubemap") or {}).get("ObjectPath") or ""
        image_path = find_sky_image(ctx, cube) if cube else None
        if not image_path:
            warn("sky: %s's HDRI %s is not in the export (export its texture folder as textures)" % (source, cube.split(".")[0] or "(none named)"))
            return
        image = bpy.data.images.load(image_path, check_existing=True)
        width, height = image.size
        if not height or abs(width / float(height) - 2.0) > 0.05:
            warn("sky: %s is %dx%d, not a 2:1 panorama: not used" % (os.path.basename(image_path), width, height))
            return
        intensity = dbd_core.safe_float(props.get("Intensity"), 1.0)
        colour = _sky_colour(props.get("LightColor"), (1.0, 1.0, 1.0))
        lower = _sky_colour(props.get("LowerHemisphereColor"), (0.0, 0.0, 0.0)) if props.get("bLowerHemisphereIsBlack", True) is not False else None
        angle = dbd_core.safe_float(props.get("SourceCubemapAngle"), 0.0)
        strength = intensity * ctx.light_strength / dbd_core.BLENDER_LUMINOUS_EFFICACY

        world = bpy.data.worlds.get(SKY_WORLD) or bpy.data.worlds.new(SKY_WORLD)
        world.use_nodes = True
        nodes, links = world.node_tree.nodes, world.node_tree.links
        nodes.clear()
        coords = nodes.new("ShaderNodeTexCoord")
        mapping = nodes.new("ShaderNodeMapping")
        mapping.inputs["Rotation"].default_value[2] = -math.radians(angle)       # Unreal turns the cubemap the other way round its up axis
        env = nodes.new("ShaderNodeTexEnvironment")
        env.image = image
        tint = nodes.new("ShaderNodeMixRGB")
        tint.blend_type = "MULTIPLY"
        tint.inputs[0].default_value = 1.0
        tint.inputs[2].default_value = colour + (1.0,)
        background = nodes.new("ShaderNodeBackground")
        background.inputs["Strength"].default_value = strength
        out = nodes.new("ShaderNodeOutputWorld")
        links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
        # The sky HDRIs are half-domes whose empty lower half showed as a black band above the map's far edge.  The whole dome is lowered by
        # SKY_HORIZON_DROP_DEG so its edge sits under the map; nothing is stretched, and below the lowered edge is black.  No camera-only trick:
        # EEVEE counts its world-lighting capture as camera rays, which lit the scene from the stretched sky.
        lift = nodes.new("ShaderNodeVectorMath")
        lift.operation = "ADD"
        lift.inputs[1].default_value = (0.0, 0.0, math.sin(math.radians(SKY_HORIZON_DROP_DEG)))
        lowered = nodes.new("ShaderNodeVectorMath")
        lowered.operation = "NORMALIZE"
        links.new(mapping.outputs["Vector"], lift.inputs[0])
        links.new(lift.outputs["Vector"], lowered.inputs[0])
        links.new(lowered.outputs["Vector"], env.inputs["Vector"])
        links.new(env.outputs["Color"], tint.inputs[1])
        sky = tint.outputs[0]
        if lower is not None:                                                     # Unreal's 'Lower Hemisphere Is Black': its colour below the horizon
            split = nodes.new("ShaderNodeSeparateXYZ")
            above = nodes.new("ShaderNodeMath")
            above.operation = "GREATER_THAN"
            above.inputs[1].default_value = 0.0
            ground = nodes.new("ShaderNodeMixRGB")
            ground.inputs[1].default_value = lower + (1.0,)
            links.new(lowered.outputs["Vector"], split.inputs[0])             # below the lowered horizon
            links.new(split.outputs["Z"], above.inputs[0])
            links.new(above.outputs[0], ground.inputs[0])
            links.new(sky, ground.inputs[2])
            sky = ground.outputs[0]
        links.new(sky, background.inputs["Color"])
        links.new(background.outputs["Background"], out.inputs["Surface"])
        for x, node in enumerate(n for n in nodes if n.bl_idname != "ShaderNodeOutputWorld"):
            node.location = (x * 220, 0)
        out.location = (len(nodes) * 220, 0)
        world["dbd_sky_source"] = source
        world["dbd_sky_image"] = os.path.basename(image_path)
        world["dbd_ue_sky_intensity"] = intensity
        scene.world = world
        ctx.report.built["sky light"] += 1
        lamps, parts = build_game_sky_parts(scene, ctx, origin_uu)
        if lamps:
            ctx.report.built["moon light (sun lamps from %s)" % source] += lamps
        if parts:
            ctx.report.built["sky meshes (moon, sky sphere ... from %s)" % source] += parts
        print("Sky: %s from %s (intensity %g, colour %s, World strength %.3f)" % (os.path.basename(image_path), source, intensity,
                                                                               ", ".join("%.3f" % c for c in colour), strength))
    except Exception as exc:
        warn("sky: could not be set up (%s)" % exc)


def match_game_exposure(scene, ctx):
    """
    With lights built at the default Light Strength (615), the scene needs Blender's Exposure at 1 to look as the game does: every map pins its camera
    exposure at brightness 0.1.  Set only when the Exposure is still Blender's 0, so a value the user chose stays.
    """
    if not (ctx.lights and ctx.report.built.get("lights")) and not ctx.report.built.get("sky light"):
        return
    vs = scene.view_settings
    if abs(vs.exposure) < 1e-6:
        vs.exposure = GAME_EXPOSURE
        print("Exposure set to %g (Render > Color Management), the match for Light Strength %g" % (GAME_EXPOSURE, ctx.light_strength))


def build_map(plan, ctx, row_sign=1.0):
    """Instance every planned tile at its grid position (tiles are built first if missing)."""
    owner = "map:%s" % plan.tilemap.name
    removed = remove_previous_build(owner)
    if removed:
        print("Removed %d objects from a previous build of %s" % (removed, owner))
    main = make_empty("%s_Map" % plan.tilemap.name, size=2.0)
    main["dbd_owner"] = owner

    needed = []
    for pl in plan.placements:
        if pl.tile not in needed:
            needed.append(pl.tile)
    for tile in needed:
        ensure_tile_built(tile, ctx)

    border_cells = {cell for p in plan.placements if p.tile.type == "Blocker" for cell in p.cells()}
    used_templates = {}
    variation_templates = []
    for index, pl in enumerate(plan.placements):
        template = find_blueprint_root(pl.tile.class_name)
        if template is None:
            ctx.report.missing_child[pl.tile.class_name] += 1
            continue
        x, y = plan.world_position_uu(pl, row_sign)
        m_ue = dbd_core.compose_trs((x, y, 0.0), dbd_core.rotator_matrix(0.0, pl.yaw, 0.0), (1.0, 1.0, 1.0))
        slot = make_empty("%s_%d_%d" % (pl.tile.name, pl.col, pl.row), size=0.5)
        slot.parent = main
        slot["dbd_owner"] = owner
        slot["dbd_cell"] = "%d,%d" % (pl.col, pl.row)
        slot["dbd_tile_role"] = pl.role
        _set_matrix(slot, dbd_core.ue_to_blender(m_ue))
        inst = instantiate_blueprint(template, slot, owner, "%s_inst" % pl.tile.name)
        _prune_directional_spawns(inst, pl, border_cells, ctx.report)
        variation_templates += [t for t in apply_variations(inst, plan, index, pl.tile, owner, ctx) if t not in variation_templates]
        ctx.report.built["map tiles placed"] += 1
        used_templates[template.name] = template
    room_templates = []
    if ctx.spawn_scene:
        try:
            room_templates = build_quadrants(plan, ctx, main, owner, row_sign)
        except Exception as exc:                  # the rooms are an addition: a failure must not cost the tiles
            ctx.report.warnings.append("rooms: %s: %s" % (type(exc).__name__, exc))
    game_templates = []
    if ctx.game_categories is not None:
        game_templates = place_gameplay(main, plan, owner, ctx)
    else:
        choose_gameplay(main, plan, ctx)
    # the originals sit at the world origin; the placed copies replace them
    for template in room_templates + variation_templates + game_templates + list(used_templates.values()):
        _retire(template)
    return main


# --------------------------------------------------------------------------------------------
# Whole-level build (Script 3)
# --------------------------------------------------------------------------------------------

# Actors that only exist to run the game: nothing to see, and no export to report as missing.
LEVEL_SKIPPED_CLASSES = re.compile(r"^Audio|^GMAdaptiveShadowMap|Manager_C$")
# What a level can change on a component a blueprint placed.  Anything else leaves the built copy as it is.
OVERRIDE_PROPS = {"RelativeLocation", "RelativeRotation", "RelativeScale3D", "bVisible", "bHiddenInGame", "StaticMesh", "SkeletalMesh", "SkinnedAsset", "OverrideMaterials",
                  "bAffectsWorld", "Intensity", "LightColor", "AttenuationRadius", "Temperature", "bUseTemperature"}


def _place_component(p, main, owner, ctx):
    """Build one component with the blueprint builder's own code."""
    report = ctx.report
    if (p.is_mesh or p.is_instanced) and _skipped_by_name(p, ctx):
        report.skipped_by_name += 1
    elif p.is_mesh:
        _build_mesh(p, main, ctx.meshes, report, ctx.hide_hidden_in_game)
    elif p.is_instanced:
        _build_instanced(p, main, ctx.meshes, report, ctx.hide_hidden_in_game, instancing=ctx.instancing)
    elif p.is_light:
        if ctx.lights:
            _build_light(p, main, owner, report, ctx.light_strength, ctx.lights_off, ctx.light_min_radius, ctx.light_discs, ctx.light_spot_size,
                         ctx.light_static_no_volume, ctx.light_no_volume_names)
    elif p.type in dbd_core.AMBIENT_LIGHT_TYPES:
        report.built["sky lights (ambient, not built)"] += 1
    elif p.type == "DecalComponent":
        report.built["decals (not built)"] += 1
    elif p.type in ("NiagaraComponent", "ParticleSystemComponent"):
        report.built["particle effects (not built)"] += 1


def _class_placements(cls, path, ctx, cache):
    """{component name: Placement} of a blueprint class, to know what a level's component started as."""
    if cls not in cache:
        cache[cls] = {}
        hint = path.rsplit(".", 1)[0] + ".0" if path else None
        found = ctx.locator.find(cls, hint) if ctx.locator is not None else None
        if found:
            try:
                bp = dbd_core.load_blueprint(found, find=ctx.blueprint_finder())
            except Exception as exc:
                ctx.report.warnings.append("%s: could not read %s (%s)" % (cls, found, exc))
            else:
                for p in bp.placements:
                    cache[cls][dbd_core.strip_gen_variable(p.var or p.name)] = p
                    cache[cls].setdefault(p.name, p)
    return cache[cls]


def _override_component(level, comp, p, root, instance, owner, ctx):
    """Rebuild one component of a placed copy from the blueprint's values with the level's on top, which covers a moved, swapped or hidden part alike."""
    merged = dict(p.item, Properties=level.merged(comp))
    changed = dbd_core.Placement(p.name, p.var, merged, level.actor_space(comp, root), "level", p.parent)
    copies = [o for o in instance.children if o.name.split(".")[0] in (p.name, p.name + "_back")]
    if p.is_child_actor:
        for o in instance.children:
            if o.get("dbd_cac") in (p.name, p.name + "_spawn"):
                _set_matrix(o, changed.blender_matrix())
                if changed.hidden_in_game and ctx.hide_hidden_in_game:
                    _hide_tree(o)
        return
    for o in copies:
        bpy.data.objects.remove(o, do_unlink=True)
    _place_component(changed, instance, owner, ctx)
    ctx.report.built["components the level changed"] += 1


def _hide_tree(obj):
    for o in [obj] + list(obj.children_recursive):
        o.hide_render = True
        o.hide_viewport = True


def _place_blueprint_actor(level, actor, transform, main, owner, ctx, placements):
    """A blueprint the level places: a copy of the built blueprint, then what the level changed.  Parts only the level has, such as what a construction script made, are added."""
    cls, comps = actor.get("Type"), level.components(actor)
    root = level.root(actor)
    template = ensure_class_built(cls, dbd_umap.class_path(actor), ctx)
    slot = make_empty(actor.get("Name") or cls, size=0.3)
    slot.parent = main
    slot["dbd_owner"] = owner
    slot["dbd_child_class"] = cls
    world = level.world(root) if root is not None else dbd_umap.IDENTITY
    _set_matrix(slot, dbd_core.ue_to_blender(dbd_core.mat_mul(transform, world)))
    instance = None
    if template is None:
        ctx.report.missing_child[cls] += 1
    else:
        instance = instantiate_blueprint(template, slot, owner, "%s_inst" % cls[:-2])
        ctx.report.built["blueprints placed"] += 1
    for comp in comps:
        name = dbd_core.strip_gen_variable(comp.get("Name") or "")
        p = placements.get(name)
        if p is None:
            if comp is not root:
                _place_component(dbd_core.Placement(name, None, comp, level.actor_space(comp, root), "level", None), instance or slot, owner, ctx)
        elif instance is not None and OVERRIDE_PROPS & set(level.props(comp)):
            _override_component(level, comp, p, root, instance, owner, ctx)
    if level.props(actor).get("bHidden") and ctx.hide_hidden_in_game:
        _hide_tree(slot)
    return template


def _place_actor(level, actor, transform, main, owner, ctx):
    """Anything else: its components, each where the level says."""
    hidden = level.props(actor).get("bHidden")
    root = level.root(actor)
    for comp in level.components(actor):
        item = dict(comp, Properties=dict(level.props(comp), bHiddenInGame=True)) if hidden else comp
        world = dbd_core.mat_mul(transform, level.world(comp))
        p = dbd_core.Placement(comp.get("Name") or actor.get("Name"), None, item, world, "level", None)
        if comp is root:                    # "SM_COM_BookPile_Rich_01_24", not "StaticMeshComponent0"
            p.name = actor.get("Name") or p.name
        if p.is_instanced:
            p.name = p.mesh()[0] or p.name
        _place_component(p, main, owner, ctx)


def build_level(json_path, ctx, sublevels=True):
    """Build a .umap export and the levels it streams in.  Returns (main empty, owner, name) for organize_build."""
    levels, notes = dbd_umap.load_levels(json_path, sublevels)
    name = levels[0][0].name
    owner = "umap:%s" % name
    removed = remove_previous_build(owner)
    if removed:
        print("Removed %d objects from a previous build of %s" % (removed, owner))
    main = make_empty("%s_uMap" % name, size=2.0)
    main["dbd_owner"] = owner
    ctx.report.warnings.extend(notes)
    cache, templates = {}, []
    for level, transform in levels:
        actors = level.actors()
        print("Level %s: %d actors" % (level.name, len(actors)))
        blueprints = {}
        for actor in actors:
            cls = str(actor.get("Type") or "")
            if not cls.endswith("_C") or cls == level.name + "_C":
                continue
            if LEVEL_SKIPPED_CLASSES.search(cls):
                ctx.report.built["game logic actors (nothing to build)"] += 1
                continue
            blueprints[id(actor)] = placements = _class_placements(cls, dbd_umap.class_path(actor), ctx, cache)
            for comp in level.components(actor):              # first, for every actor: one may be attached to another
                p = placements.get(dbd_core.strip_gen_variable(comp.get("Name") or ""))
                if p is not None:
                    level.set_defaults(comp, p.props)
        for actor in actors:
            cls = str(actor.get("Type") or "")
            try:
                if id(actor) in blueprints:
                    template = _place_blueprint_actor(level, actor, transform, main, owner, ctx, blueprints[id(actor)])
                    if template is not None and template not in templates:
                        templates.append(template)
                elif not cls.endswith("_C"):
                    _place_actor(level, actor, transform, main, owner, ctx)
            except Exception as exc:
                ctx.report.warnings.append("%s (%s): %s" % (actor.get("Name"), cls, exc))
                print("Error building %s: %s" % (actor.get("Name"), exc))
    for template in templates:
        _retire(template)
    return main, owner, name


# --------------------------------------------------------------------------------------------
# Outliner groups
# --------------------------------------------------------------------------------------------

BUILD_GROUPS = ("Structures", "Props", "Trees and Plants", "Blockers", "Ground", "Decals", "Gameplay", "Lights", "Sky", "Helpers", "Other")


def _retire(template):
    """
    Copies of this blueprint are placed: the original, at the world origin, is done with.  organize_build files it in an unticked collection, which hides it; hiding
    each object as well cost 5 s on Wales.  Its lights still stop rendering, in case it is never filed.
    """
    for o in [template] + list(template.children_recursive):
        if o.type == "LIGHT":
            o.hide_render = True
    template["dbd_template"] = True


def _build_collection(owner, title):
    """This build's collection: the one an earlier build left, with the groups ticked as they were, or a new one."""
    scene = bpy.context.scene
    coll = next((c for c in bpy.data.collections if c.get("dbd_build") == owner), None)
    if coll is None:
        coll = bpy.data.collections.new(title)
        coll["dbd_build"] = owner
    if coll not in scene.collection.children_recursive:
        scene.collection.children.link(coll)
    return coll


def _group_collection(parent, group):
    coll = next((c for c in parent.children if c.get("dbd_group") == group), None)
    if coll is None:
        coll = bpy.data.collections.new(group)
        coll["dbd_group"] = group
        parent.children.link(coll)
    return coll


def _collection_homes():
    """{object: the collections holding it}, read once.  Object.users_collection searches every collection on each read: 35 s of a Wales build."""
    homes = collections.defaultdict(list)
    for coll in [bpy.context.scene.collection] + list(bpy.data.collections):
        for o in coll.objects:
            homes[o].append(coll)
    return homes


def _move_to_collection(obj, target, homes):
    held = homes.get(obj, [])
    if target not in held:
        target.objects.link(obj)
    for coll in held:
        if coll != target:
            coll.objects.unlink(obj)
    homes[obj] = [target]


def _gameplay_groups(objects):
    """{object: its gameplay category}, from its own tag or the nearest parent's: everything inside a generator goes with the generator."""
    found = {}

    def category(o):
        if o not in found:
            own = o.get("dbd_gameplay") or dbd_core.gameplay_class_category(o.get("dbd_child_class") or "")
            found[o] = own or (category(o.parent) if o.parent else None)
        return found[o]

    for o in objects:
        category(o)
    return found


def _drop_empty_groups():
    """Groups left with nothing in them: a build that no longer has lights, or one whose blueprint became a template."""
    while True:
        empty = [c for c in bpy.data.collections if (c.get("dbd_group") or c.get("dbd_build")) and not c.objects and not c.children]
        if not empty:
            return
        for coll in empty:
            bpy.data.collections.remove(coll)


def _drop_unused_sources():
    """Instancer sources no instancer points at any more (its build was rebuilt or deleted)."""
    coll = bpy.data.collections.get(SOURCE_COLLECTION)
    if coll is None:
        return
    used = set()
    for o in bpy.data.objects:
        source = o.get("dbd_instance_source")
        if source is not None:
            used.add(source.name)
    _remove_objects([o for o in coll.objects if o.name not in used])


def file_sky_parts(owner, title):
    """The sky's moon lamps and meshes (and the DbD Sky empty holding them) into the build's own "Sky" group, beside Lights and the rest."""
    parts = [o for o in bpy.data.objects if o.get("dbd_sky_part")]
    if not parts:
        return
    target = _group_collection(_build_collection(owner, title), "Sky")
    homes = _collection_homes()
    for o in parts:
        _move_to_collection(o, target, homes)


def organize_build(main, owner, title):
    """
    Sort a finished build into one collection per kind of object, so a kind can be unticked in the Outliner.  Parents are untouched: an object still
    follows its tile from another collection.  The temporary hide does not survive a move, or a collection being unticked, so what was hidden that
    way stays hidden with hide_viewport.  Originals that copies have replaced go to an unticked collection of their own.
    """
    if "dbd_template" in main:
        del main["dbd_template"]
    objects = [main] + list(main.children_recursive)
    gameplay = _gameplay_groups(objects)
    sorted_objects = collections.defaultdict(list)
    for o in objects:
        if gameplay.get(o):
            sorted_objects["Gameplay", gameplay[o].replace("_", " ").title()].append(o)
        elif o.type == "LIGHT":
            sorted_objects["Lights", None].append(o)
        elif o.type == "MESH":
            sorted_objects[o.get("dbd_group") or "Other", None].append(o)
        else:
            sorted_objects["Helpers", None].append(o)

    build = _build_collection(owner, title)
    homes = _collection_homes()
    for key in sorted(sorted_objects, key=lambda k: (BUILD_GROUPS.index(k[0]), k[1] or "")):
        group, inner = key
        target = _group_collection(build, group)
        if inner:
            target = _group_collection(target, inner)
        for o in sorted_objects[key]:
            if o.hide_get():
                o.hide_viewport = True
            _move_to_collection(o, target, homes)

    templates = _excluded_collection(TEMPLATE_COLLECTION)
    for root in [o for o in bpy.data.objects if o.get("dbd_template")]:
        if templates not in homes.get(root, []):
            for o in [root] + list(root.children_recursive):
                _move_to_collection(o, templates, homes)
    _drop_empty_groups()
    _drop_unused_sources()
