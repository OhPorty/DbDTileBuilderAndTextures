bl_info = {
    "name": "OhPorty's DbD Material Maker",
    "author": "OhPorty",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "3D Viewport > Sidebar (N) > Porty's Mats",
    "description": "Builds Dead by Daylight materials (layers, tiling, normals, alpha) from fModel material exports.",
    "category": "Object",
}

import importlib
import os
import textwrap
import traceback

import bpy

REPORT_NAME = "DbD Material Report"
DEFAULTS = {"paint_mode": "MASK", "detail": 0.5, "height_sharp": 4.0, "stain": 0.8, "grime_scale": 1.0, "leaves": 0.6, "moss_on": False, "moss": 0.6,
            "transition": 1.0, "edge_point": 0.5, "emissive": 0.9}


class JSONImporterGUIProperties3(bpy.types.PropertyGroup):
    # the class and property-group names are kept so .blend files that already hold the base path keep working
    base_path: bpy.props.StringProperty(
        name="Export Folder",
        description=("The folder you exported from fModel. Material (.json) and texture (.png) files are found anywhere underneath it, "
                     "whatever its folder layout"),
        default="",
        maxlen=1024,
        subtype='DIR_PATH',
    )
    last_result: bpy.props.StringProperty(default="")
    last_looks: bpy.props.StringProperty(default="")

    paint_mode: bpy.props.EnumProperty(
        name="Blend Texture + Vertex Colours",
        description=("How layers are blended when a material has BOTH a painted blend texture and vertex colours "
                     "(about 90 materials: some wall and brick materials). It needs vertex colours on the mesh to show"),
        items=[("MASK", "Blend texture only (recommended)", "Ignore the vertex colours when there is a blend texture"),
               ("ADD", "Add", "Vertex colours add to the blend texture"),
               ("MULTIPLY", "Multiply", "A layer shows only where both are set"),
               ("MAX", "Maximum", "Whichever is stronger")],
        default="MASK",
    )
    detail: bpy.props.FloatProperty(
        name="Wear Detail", description=("How strongly the grunge relief of the grime layers shows (0.5 = as authored). "
                                         "Only materials that have a grime layer: about 60"),
        default=0.5, min=0.0, max=1.0, subtype='FACTOR')
    height_sharp: bpy.props.FloatProperty(
        name="Height Blend Sharpness", description=("How hard a height blend separates two layers (about 190 layered materials "
                                                    "that turn height blending on)"),
        default=4.0, min=1.0, max=12.0)
    stain: bpy.props.FloatProperty(
        name="Grime", description="Strength of the dark soot / dirt patches (0 turns them off)",
        default=0.8, min=0.0, max=1.0, subtype='FACTOR')
    emissive: bpy.props.FloatProperty(
        name="Emissive Strength",
        description=("Multiplier on how strongly glowing materials emit light (screens, lamps, signs). 0.9 matches the game with Blender's "
                     "Exposure at 1 and the Tile Builder's Light Strength at 615; halve it for each stop of Exposure you add. 0 = no glow"),
        default=0.9, min=0.0)
    transition: bpy.props.FloatProperty(
        name="Layer Edge Sharpness",
        description=("How abrupt the change from one layer to the next is, e.g. plaster to brick. 1 = as the blend mask gives it, higher = starker "
                     "(applies to every layered material: wall plaster, blend-map and structure materials, bottom/top layers)"),
        default=1.0, min=1.0, max=20.0)
    edge_point: bpy.props.FloatProperty(
        name="Layer Edge Position",
        description=("Where the edge sits in the blend mask when Layer Edge Sharpness is above 1. Lower = the upper layer (plaster) covers more, "
                     "higher = less. Most masks are dark, so try 0.2 to 0.4"),
        default=0.5, min=0.05, max=0.95, subtype='FACTOR')
    leaves: bpy.props.FloatProperty(
        name="Leaves on Top", description="Strength of the leaf layer on top of the ~30 materials that have one (0 turns it off)",
        default=0.6, min=0.0, max=1.0, subtype='FACTOR')
    moss_on: bpy.props.BoolProperty(
        name="Crawling Moss", description=("Add the moss layer that many structure materials switch on. Where it grows is an approximation, "
                                            "so it is off by default"), default=False)
    moss: bpy.props.FloatProperty(
        name="Moss Strength", description="Strength of the crawling moss", default=0.6, min=0.0, max=1.0, subtype='FACTOR')
    grime_scale: bpy.props.FloatProperty(
        name="Grime Pattern Size (m)", description="Size in metres of one tile of the grime pattern: bigger gives larger, longer streaks",
        default=1.0, min=0.1, max=20.0)


# ---------------------------------------------------------------------------------------------------------------------------------
# Running the builder
# ---------------------------------------------------------------------------------------------------------------------------------

def valid_base_path(props):
    raw = props.base_path
    path = os.path.normpath(bpy.path.abspath(raw)) if raw else ""
    return path if path and os.path.isdir(path) else None


def write_report(lines):
    """The per-material decisions and the run summary go to a Text Editor datablock (works on every platform, no console needed)."""
    text = bpy.data.texts.get(REPORT_NAME) or bpy.data.texts.new(REPORT_NAME)
    text.clear()
    text.write("\n".join(lines) + "\n")
    return text


class OBJECT_OT_RunMatBuild(bpy.types.Operator):
    bl_idname = "object.run_matbuild"
    bl_label = "Build Materials"
    bl_description = "Build the materials of the selected objects from their fModel material files"
    bl_options = {'UNDO'}

    def execute(self, context):
        props = context.scene.json_importer_gui_props3
        base_path = valid_base_path(props)
        if not base_path:
            self.report({'ERROR'}, "Set the Export Folder first (the folder has to exist)")
            return {'CANCELLED'}
        if not any(o.type == 'MESH' for o in context.selected_objects):
            self.report({'ERROR'}, "Select the mesh objects whose materials you want to build")
            return {'CANCELLED'}

        try:
            helpers = importlib.reload(importlib.import_module(".dbd_matio", __package__))    # reloaded each run so updated files take effect
            module = importlib.reload(importlib.import_module(".dbd_matbuild", __package__))
        except ModuleNotFoundError as exc:
            self.report({'ERROR'}, "%s.py is missing from the add-on folder" % (exc.name or "a helper file"))
            return {'CANCELLED'}
        except Exception as exc:
            traceback.print_exc()
            self.report({'ERROR'}, "The builder could not be loaded: %s: %s" % (type(exc).__name__, exc))
            return {'CANCELLED'}

        module.OPTIONS.update({"paint_mode": props.paint_mode, "detail": props.detail, "height_sharp": props.height_sharp,
                               "stain": props.stain, "grime_scale": props.grime_scale, "leaves": props.leaves,
                               "moss_on": props.moss_on, "moss": props.moss,
                               "transition": props.transition, "edge_point": props.edge_point,
                               "emissive": props.emissive})
        try:
            result = module.main(context, base_path)
        except Exception as exc:
            traceback.print_exc()
            self.report({'ERROR'}, "Building failed: %s: %s (see the system console for details)" % (type(exc).__name__, exc))
            return {'CANCELLED'}

        if isinstance(result, dict):
            write_report(result.get("report") or [])
            props.last_result = "%d built, %d failed, %d without a material file, %d textures not found" % (
                result.get("built", 0), result.get("failed", 0), result.get("no_json", 0), result.get("missing_textures", 0))
            used = result.get("applied") or {}
            props.last_looks = ("Look settings used on: " + ", ".join("%s %d" % (k, v) for k, v in sorted(used.items()))) if used else \
                "Look settings: none of these materials use them"
            self.report({'WARNING'} if (result.get("failed") or result.get("no_json")) else {'INFO'}, props.last_result)
        return {'FINISHED'}


class OBJECT_OT_OpenMatReport(bpy.types.Operator):
    bl_idname = "object.open_matreport"
    bl_label = "Show Report"
    bl_description = "Open the report of the last build in a Text Editor (what was decided for each material, and anything missing)"

    @classmethod
    def poll(cls, context):
        return REPORT_NAME in bpy.data.texts

    def execute(self, context):
        text = bpy.data.texts[REPORT_NAME]
        for window in context.window_manager.windows:                # show it in a Text Editor if one is open, else in a new window
            for area in window.screen.areas:
                if area.type == 'TEXT_EDITOR':
                    area.spaces.active.text = text
                    return {'FINISHED'}
        bpy.ops.wm.window_new()
        area = context.window_manager.windows[-1].screen.areas[0]
        area.type = 'TEXT_EDITOR'
        area.spaces.active.text = text
        return {'FINISHED'}


class OBJECT_OT_TexscriRefreshIndex(bpy.types.Operator):
    bl_idname = "object.texscri_refresh_index"
    bl_label = "Rescan Export Folder"
    bl_description = ("The add-on remembers which files exist in the export folder for the whole Blender session. "
                      "Use this after exporting new materials or textures")

    def execute(self, context):
        try:
            importlib.reload(importlib.import_module(".dbd_matio", __package__)).refresh_indexes()
        except ModuleNotFoundError:
            self.report({'ERROR'}, "dbd_matio.py is missing from the add-on folder")
            return {'CANCELLED'}
        self.report({'INFO'}, "The export folder will be rescanned on the next build")
        return {'FINISHED'}


class OBJECT_OT_ResetMatSettings(bpy.types.Operator):
    bl_idname = "object.reset_matsettings"
    bl_label = "Reset to Defaults"
    bl_description = "Put the look settings back to their recommended values"

    def execute(self, context):
        props = context.scene.json_importer_gui_props3
        for key, value in DEFAULTS.items():
            setattr(props, key, value)
        return {'FINISHED'}


# ---------------------------------------------------------------------------------------------------------------------------------
# Panels
# ---------------------------------------------------------------------------------------------------------------------------------

class OBJECT_PT_JSONImporterGUIPanel3(bpy.types.Panel):
    bl_label = "Porty's Material Maker"
    bl_idname = "OBJECT_PT_json_importer_gui_panel3"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Porty's Mats"

    def draw(self, context):
        layout = self.layout
        props = context.scene.json_importer_gui_props3

        layout.label(text="Export Folder")
        layout.prop(props, "base_path", text="")
        if not props.base_path:
            layout.label(text="Choose your fModel export folder", icon='INFO')
        elif not valid_base_path(props):
            layout.label(text="That folder does not exist", icon='ERROR')

        selected = [o for o in context.selected_objects if o.type == 'MESH']
        row = layout.row()
        row.scale_y = 1.6
        row.enabled = bool(valid_base_path(props)) and bool(selected)
        row.operator("object.run_matbuild", icon='MATERIAL')
        if valid_base_path(props) and not selected:
            layout.label(text="Select the objects to build first", icon='INFO')
        else:
            layout.label(text="%d object%s selected" % (len(selected), "" if len(selected) == 1 else "s"))

        if props.last_result:
            box = layout.box()
            box.label(text="Last build:", icon='CHECKMARK')
            box.label(text=props.last_result)
            if props.last_looks:
                box.label(text=props.last_looks)
            box.operator("object.open_matreport", icon='TEXT')


class OBJECT_PT_MatLook(bpy.types.Panel):
    bl_label = "Look Settings"
    bl_idname = "OBJECT_PT_matmaker_look"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Porty's Mats"
    bl_parent_id = "OBJECT_PT_json_importer_gui_panel3"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.json_importer_gui_props3
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(props, "paint_mode", text="Vertex Colours")
        layout.prop(props, "detail")
        layout.prop(props, "emissive", text="Emissive Strength")
        layout.prop(props, "transition", text="Edge Sharpness")
        layout.prop(props, "edge_point", text="Edge Position")
        layout.prop(props, "height_sharp", text="Height Blend")
        layout.prop(props, "stain")
        layout.prop(props, "grime_scale", text="Grime Size")
        layout.prop(props, "leaves")
        layout.prop(props, "moss_on")
        sub = layout.row()
        sub.enabled = props.moss_on
        sub.prop(props, "moss")
        layout.operator("object.reset_matsettings", icon='LOOP_BACK')
        layout.label(text="Applied the next time you build.")


HELP = (
    ("1. Export", (
        "In FModel, export the meshes as Models (right-click a folder, Export Folder, Models).",
        "Their materials and textures are exported with them.",
    )),
    ("2. Build", (
        "Export Folder: pick FModel's Output Directory.",
        "Select the objects and press Build Materials.",
    )),
    ("Something looks wrong", (
        "Tools > Show Report lists anything that was not found.",
        "Export the meshes that use it again, press Tools > Rescan Export Folder, then Build Materials.",
    )),
)


def draw_help(layout, context, sections):
    """One collapsible section per topic, closed to begin with, with text that wraps to the sidebar's width."""
    width = max(context.region.width - 40, 100) / (6.5 * context.preferences.system.ui_scale)
    for number, (heading, lines) in enumerate(sections):
        header, body = layout.panel("dbd_help_%d" % number, default_closed=True)
        header.label(text=heading)
        if body is None:
            continue
        col = body.box().column(align=True)
        col.scale_y = 0.8
        for index, line in enumerate(lines):
            if index:
                col.separator(factor=0.8)
            for part in textwrap.wrap(line.replace("/", "/ "), max(int(width), 16), break_long_words=False):
                col.label(text=part)


class OBJECT_PT_MatHelp(bpy.types.Panel):
    bl_label = "Help"
    bl_idname = "OBJECT_PT_matmaker_help"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Porty's Mats"
    bl_parent_id = "OBJECT_PT_json_importer_gui_panel3"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        draw_help(self.layout, context, HELP)


class OBJECT_PT_MatTools(bpy.types.Panel):
    bl_label = "Tools"
    bl_idname = "OBJECT_PT_matmaker_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Porty's Mats"
    bl_parent_id = "OBJECT_PT_json_importer_gui_panel3"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        self.layout.operator("object.texscri_refresh_index", icon='FILE_REFRESH')
        self.layout.operator("object.open_matreport", icon='TEXT')


CLASSES = (JSONImporterGUIProperties3, OBJECT_OT_RunMatBuild, OBJECT_OT_OpenMatReport, OBJECT_OT_TexscriRefreshIndex,
           OBJECT_OT_ResetMatSettings, OBJECT_PT_JSONImporterGUIPanel3, OBJECT_PT_MatLook, OBJECT_PT_MatTools, OBJECT_PT_MatHelp)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.json_importer_gui_props3 = bpy.props.PointerProperty(type=JSONImporterGUIProperties3)


def unregister():
    del bpy.types.Scene.json_importer_gui_props3
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
