"""
dbd_matbuild.py - the material builder behind the "Build Materials" button.

It builds from what the exports and the master materials say, not from texture names:

* The material export lists every parameter of its master material, live or not.  In the masters nearly every "Use ..." switch defaults to False,
  so a slot counts only when the instance switches it on; otherwise the flat colour / scalar is used.
* Master materials (read from the export's Masters folder when present, only used for their name here) are one of a few families:
    - M_Simple (+ _InteractableObject, _SpiderWeb ...): one material, optional "Material Bottom" (suffix ' ..') / "Material Top" (' ...') layers
      blended by their opacity masks, a winter-snow overlay (suffix '     .'), and a surface-opacity group.
    - M_BlendMapRgb: four material layers (suffixes '', ' .', '  .', '   .': MF_Material_1..4) blended by the R / G / B channels of
      "Blend Map RGB" (or vertex paint).
    - everything else (older structure / foliage / glass / decal masters, the PM_* slot generation): a generic role-based path.
* Texture conventions checked against the pixels of the exported textures:  HRM\\ORM Map / Main_ORM / PM_SpecularMasks = ORM (R = AO,
  G = roughness, B = metallic); normal maps carry no Z (blue is always 1.0), so Z is rebuilt from X and Y; Unreal's green channel points down, so
  it is flipped; only some base-colour textures carry real alpha, so alpha is wired by rule (blend mode + switches), never by default.

Everything that has no Blender equivalent, or that this version only approximates, is written to the per-material decision log
(`LOG`) so a wrong rule is easy to find.
"""
import math
import os
import re
import traceback

from . import dbd_matio

# A texture that is only the master's placeholder for "nothing set".
PLACEHOLDER = re.compile(r"(/defaults/|_default\b|/default|^default|/white\b|/black\b|_linear\b|flatnormal|checker_grid|^/engine/|defaulttexture)", re.I)

FLAT_NORMAL = (0.5, 0.5, 1.0, 1.0)
LOG = []                        # decision log of the current material (lines)


def log(msg):
    LOG.append(msg)


# ---------------------------------------------------------------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------------------------------------------------------------

def _norm(key):
    return re.sub(r"^[|\s]+", "", str(key))


class Params(object):
    """The parameters of one material, looked up by name + layer suffix ('' / ' .' / ' ..' ...), ignoring the leading '|' group marker."""

    def __init__(self, legacy, raw):
        self.raw = raw if isinstance(raw, dict) else {}
        self.t = {_norm(k): v for k, v in legacy["Textures"].items()}
        self.s = {_norm(k): v for k, v in legacy["Scalars"].items()}
        self.c = {_norm(k): v for k, v in legacy["Colors"].items()}
        self.w = {_norm(k): v for k, v in legacy["Switches"].items()}
        self.blend_mode = legacy["BlendMode"]
        self.two_sided = legacy["TwoSided"]
        self.translucent = legacy["IsTranslucent"]
        props = self.raw.get("Properties") if isinstance(self.raw.get("Properties"), dict) else {}
        bpo = props.get("BasePropertyOverrides") if isinstance(props.get("BasePropertyOverrides"), dict) else {}
        # an unlit material shows its colour as it is, whatever lights the scene: billboard trees and houses, light shafts, effects, some screens
        self.unlit = "Unlit" in str(bpo.get("ShadingModel", ""))
        try:
            self.clip = float(bpo.get("OpacityMaskClipValue", 0.3333))
        except (TypeError, ValueError):
            self.clip = 0.3333
        self.master = None
        self.streamed = {}          # texture name -> the UV set the cooked material samples it with (see streamed_uvs)
        self.own_colours = None     # the colours the material sets itself, when it inherits the rest from a parent (None: all are its own)
        parent = props.get("Parent")
        self.parent = re.sub(r".*'(.+)'.*", r"\1", parent.get("ObjectName", "")) if isinstance(parent, dict) and parent.get("ObjectName") else None
        for c in props.get("BHVRVariantConfigurators") or []:
            vg = (c or {}).get("VariantGenerator") or {}
            name = vg.get("ObjectName") if isinstance(vg, dict) else None
            if name:
                self.master = re.sub(r".*'(.+)'.*", r"\1", name)
                break

    def tex(self, name, sfx=""):
        """Asset path of a texture slot, or None when unset / only the master's placeholder."""
        ref = self.t.get(name + sfx)
        if (not ref or PLACEHOLDER.search(ref.lower())) and sfx.endswith("."):
            ref = self.t.get(name + sfx[:-1] + " ")          # some layers' slots are stored without the final dot
        if not ref or PLACEHOLDER.search(ref.lower()):
            return None
        return ref

    def has_slot(self, name, sfx=""):
        return (name + sfx) in self.t

    def num(self, name, sfx="", default=0.0):
        v = self.s.get(name + sfx)
        return default if v is None else v

    def col(self, name, sfx="", default=None):
        return self.c.get(name + sfx, default)

    def sw(self, name, sfx="", default=False):
        v = self.w.get(name + sfx)
        return default if v is None else bool(v)

    def use(self, name, sfx=""):
        """A 'Use <map>' switch.  Materials of a recorded master list all their switches; one without a master lists none, and there a texture
        that is really set counts as on."""
        v = self.w.get(name + sfx)
        if v is not None:
            return bool(v)
        return self.master is None


# ---------------------------------------------------------------------------------------------------------------------------------
# Node helpers
# ---------------------------------------------------------------------------------------------------------------------------------

class Graph(object):
    def __init__(self, tree, base_path, bpy_module, uv_names):
        self.tree, self.nodes, self.links = tree, tree.nodes, tree.links
        self.base, self.bpy, self.uv_names = base_path, bpy_module, uv_names
        self.section = "Shader"          # which labelled band of the graph the nodes being created belong to
        self.created = []                # (node, section) in creation order, for arrange()
        self._uv = {}
        self.atlas_cells = None          # (columns, rows) when this material's cell comes from the object: see atlas_uv
        self._img = {}

    # -- plumbing -------------------------------------------------------------------------------------------------------------
    def new(self, kind, label=None, **props):
        n = self.nodes.new(kind)
        if label:
            n.label = label
        for k, v in props.items():
            setattr(n, k, v)
        self.created.append((n, self.section))
        return n

    def put(self, sock, value):
        """Set a socket to a number / colour, or link a socket into it."""
        if hasattr(value, "node"):
            self.links.new(value, sock)
        else:
            sock.default_value = value

    def math(self, op, a, b=None, c=None, clamp=False, label=None):
        n = self.new("ShaderNodeMath", label=label, operation=op)
        n.use_clamp = clamp
        for i, v in enumerate((a, b, c)):
            if v is not None:
                self.put(n.inputs[i], v)
        return n.outputs[0]

    def mix_float(self, a, b, fac, label=None):
        n = self.new("ShaderNodeMix", label=label, data_type="FLOAT")
        self.put(n.inputs[0], fac)
        self.put(n.inputs[2], a)
        self.put(n.inputs[3], b)
        return n.outputs[0]

    def mix_color(self, a, b, fac, blend="MIX", label=None):
        n = self.new("ShaderNodeMixRGB", label=label, blend_type=blend)
        self.put(n.inputs[0], fac)
        self.put(n.inputs[1], a)
        self.put(n.inputs[2], b)
        return n.outputs[0]

    def separate(self, color, label=None):
        n = self.new("ShaderNodeSeparateColor", label=label)
        self.put(n.inputs[0], color)
        return n.outputs[0], n.outputs[1], n.outputs[2]

    def combine(self, r, g, b):
        n = self.new("ShaderNodeCombineColor")
        self.put(n.inputs[0], r)
        self.put(n.inputs[1], g)
        self.put(n.inputs[2], b)
        return n.outputs[0]

    def bw(self, color, label=None):
        n = self.new("ShaderNodeRGBToBW", label=label)
        self.put(n.inputs[0], color)
        return n.outputs[0]

    # -- UV + image -----------------------------------------------------------------------------------------------------------
    def atlas_uv(self, vec):
        """
        UVs for a sheet of images whose cell each object picks: the Tile Builder keeps the placement's CustomPrimitiveData, plus 1, on the object.  Without it the UVs
        stay: the Creepy posters point at their own cell, only frames and master posters span the sheet.  Cell 0 is the top left, counting along the rows.
        """
        columns, rows = self.atlas_cells
        attr = self.new("ShaderNodeAttribute", label="Poster cell")
        attr.attribute_type = "OBJECT"
        attr.attribute_name = "dbd_atlas_cell"
        fac = attr.outputs["Fac"]
        split = self.new("ShaderNodeSeparateXYZ", label="Sheet UV")
        self.links.new(vec, split.inputs[0])
        cell = self.math("SUBTRACT", fac, 1.0)
        column = self.math("MODULO", cell, columns, label="poster column")
        row = self.math("FLOOR", self.math("DIVIDE", cell, columns), 0.0, label="poster row")
        has_cell = self.math("GREATER_THAN", fac, 0.5, label="object picks a cell")
        u = self.math("DIVIDE", self.math("ADD", split.outputs["X"], column), columns)
        v = self.math("DIVIDE", self.math("ADD", split.outputs["Y"], self.math("SUBTRACT", rows - 1.0, row)), rows)
        join = self.new("ShaderNodeCombineXYZ", label="Poster UV")
        self.links.new(self.mix_float(split.outputs["X"], u, has_cell), join.inputs[0])
        self.links.new(self.mix_float(split.outputs["Y"], v, has_cell), join.inputs[1])
        return join.outputs[0]

    def uv(self, channel, scale=(1.0, 1.0), offset=(0.0, 0.0), rotation=0.0):
        """UV coordinates of UV set `channel`, scaled / offset / rotated like the master's MF_UVTiling."""
        idx = int(round(channel))
        sec = self.section
        key = (sec, idx, round(scale[0], 5), round(scale[1], 5), round(offset[0], 5), round(offset[1], 5), round(rotation, 5))
        if key in self._uv:
            return self._uv[key]
        base_key = (sec, idx)
        if base_key not in self._uv and idx == WORLD_UV:
            geo = self.new("ShaderNodeNewGeometry", label="World position")
            mp = self.new("ShaderNodeMapping", label="World projection, %.3g m per repeat" % WORLD_PROJECTION_METRES)
            mp.vector_type = "POINT"
            self.links.new(geo.outputs["Position"], mp.inputs[0])
            mp.inputs[3].default_value = (1.0 / WORLD_PROJECTION_METRES, 1.0 / WORLD_PROJECTION_METRES, 0.0)
            self._uv[base_key] = mp.outputs[0]
            log("world projection: %.3g m per repeat at tiling 1, from above" % WORLD_PROJECTION_METRES)
        if base_key not in self._uv:
            uvn = self.new("ShaderNodeUVMap", label="UV set %d" % idx)
            if idx < len(self.uv_names):
                uvn.uv_map = self.uv_names[idx]
            elif self.uv_names and (self.uv_names[0] == "UV_SINGLE" or any(n.startswith("EXTRAUVS") for n in self.uv_names)):
                # The importers name set n EXTRAUVS<n-1>.  Name the set this material really reads, not this mesh's first: the material is shared, and a
                # mesh that has the set (SM_COM_Grass01 has two, SM_COM_FieldGrass_01 one, both MI_HideGrass01) must get it.  Meshes without it are
                # given a copy of their last set after the build, as the game does (see the padding in main).
                uvn.uv_map = "EXTRAUVS%d" % (idx - 1)
                log("UV set %d (%s) is not on the mesh this was built from (it has %d): meshes without it read their last set" % (idx, uvn.uv_map, len(self.uv_names)))
            elif self.uv_names:
                log("UV set %d does not exist on the object (has %d): using the first" % (idx, len(self.uv_names)))
                uvn.uv_map = self.uv_names[0]
            self._uv[base_key] = self.atlas_uv(uvn.outputs["UV"]) if self.atlas_cells else uvn.outputs["UV"]
        vec = self._uv[base_key]
        if scale != (1.0, 1.0) or offset != (0.0, 0.0) or rotation:
            mp = self.new("ShaderNodeMapping", label="Tiling x%.3g,%.3g" % (scale[0], scale[1]))
            self.put(mp.inputs[0], vec)
            mp.inputs[1].default_value = (offset[0], offset[1], 0.0)
            mp.inputs[2].default_value = (0.0, 0.0, rotation * 2.0 * math.pi)       # Unreal's rotator works in turns
            mp.inputs[3].default_value = (scale[0], scale[1], 1.0)
            vec = mp.outputs[0]
        self._uv[key] = vec
        return vec

    def bounds_uv(self, scale=(1.0, 1.0), offset=(0.0, 0.0), rotation=0.0):
        """0 to 1 across the object's bounding box (Unreal's object-bound UVs; Blender's Y is mirrored and its V is flipped, which cancel)."""
        tc = self.new("ShaderNodeTexCoord", label="Object bounds")
        vec = tc.outputs["Generated"]
        if scale != (1.0, 1.0) or offset != (0.0, 0.0) or rotation:
            mp = self.new("ShaderNodeMapping", label="Tiling x%.3g,%.3g" % (scale[0], scale[1]))
            self.put(mp.inputs[0], vec)
            mp.inputs[1].default_value = (offset[0], offset[1], 0.0)
            mp.inputs[2].default_value = (0.0, 0.0, rotation * 2.0 * math.pi)
            mp.inputs[3].default_value = (scale[0], scale[1], 1.0)
            vec = mp.outputs[0]
        return vec

    def image(self, ref, vector, color=True, role=None):
        """Image texture node for an Unreal asset path (None when the file is missing).  Returns (color socket, alpha socket, node)."""
        img = dbd_matio.load_texture_image(ref, self.base, self.bpy)
        if img is None:
            log("texture file not found: %s" % ref)
            return None
        try:
            img.colorspace_settings.name = "sRGB" if color else "Non-Color"
        except Exception:
            pass
        n = self.new("ShaderNodeTexImage", label=("%s: " % role if role else "") + os.path.basename(ref).split(".")[0])
        n.image = img
        n.interpolation = "Linear"
        if vector is not None:
            self.put(n.inputs[0], vector)
        return n.outputs["Color"], n.outputs["Alpha"], n


# ---------------------------------------------------------------------------------------------------------------------------------
# Layout: left to right along the data flow, one labelled band (frame) per section
# ---------------------------------------------------------------------------------------------------------------------------------

COLLAPSE = {"ShaderNodeMath", "ShaderNodeMapping", "ShaderNodeSeparateColor", "ShaderNodeCombineColor", "ShaderNodeRGBToBW",
            "ShaderNodeUVMap", "ShaderNodeVertexColor"}
HEIGHT = {"ShaderNodeTexImage": 300, "ShaderNodeBsdfPrincipled": 760, "ShaderNodeGroup": 120, "ShaderNodeMixRGB": 130, "ShaderNodeMix": 130,
          "ShaderNodeNormalMap": 120, "ShaderNodeHueSaturation": 160, "ShaderNodeOutputMaterial": 120, "NodeGroupInput": 120, "NodeGroupOutput": 120}
COLOURS = {"ShaderNodeTexImage": (0.20, 0.27, 0.42), "ShaderNodeGroup": (0.45, 0.30, 0.12), "ShaderNodeMixRGB": (0.20, 0.36, 0.22),
           "ShaderNodeMix": (0.20, 0.36, 0.22), "ShaderNodeNormalMap": (0.30, 0.25, 0.45)}
COLUMN = 340
COLUMN_NARROW = 190
GAP = 28


def _node_height(n):
    return 34 if getattr(n, "hide", False) else HEIGHT.get(getattr(n, "bl_idname", ""), 140)


def arrange(g, frames=True):
    """
    Lay the nodes created through `g` out: x by data-flow depth (textures far left, the shader on the right), y in one band per section
    (Layer 1, Blend, Shader ...), small helper nodes collapsed, nodes colour-coded, and a labelled frame around every band.
    """
    created = g.created
    if not created:
        return
    nodes = [n for n, _ in created]
    known = {id(n) for n in nodes}
    sources = {}
    for link in g.tree.links:
        if id(link.from_node) in known and id(link.to_node) in known:
            sources.setdefault(id(link.to_node), []).append(link.from_node)
    depth = {}

    def depth_of(n):
        key = id(n)
        if key in depth:
            return depth[key]
        depth[key] = 0                                  # guards a (never expected) cycle
        d = 0
        for s in sources.get(key, ()):
            d = max(d, depth_of(s) + 1)
        depth[key] = d
        return d

    for n in nodes:
        depth_of(n)
    deepest = max(depth.values())
    for n in nodes:
        kind = getattr(n, "bl_idname", "")
        if kind in COLLAPSE:
            n.hide = True
        if kind in COLOURS:
            n.use_custom_color = True
            n.color = COLOURS[kind]

    order = []
    for _n, sec in created:
        if sec not in order:
            order.append(sec)
    shader = [s for s in order if s == "Shader"]
    bands = [s for s in order if s != "Shader"] + shader          # the shader band goes last, then is centred on the others
    members = {s: [n for n, sec in created if sec == s] for s in order}
    # column widths: a column holding only collapsed helper nodes is narrow
    wide = {}
    for n in nodes:
        d = depth[id(n)]
        wide[d] = wide.get(d, False) or not getattr(n, "hide", False)
    width = {d: (COLUMN if w else COLUMN_NARROW) for d, w in wide.items()}
    def x_of(d):
        # a column is as far left of the next one as it is wide itself, so a wide node never runs into the column to its right
        return -sum(width[k] for k in width if d <= k < deepest)
    y = 0
    placed = {}
    for sec in bands:
        y -= 60                                          # room for the frame's label
        columns = {}
        for n in members[sec]:
            columns.setdefault(depth[id(n)], []).append(n)
        band = 0
        for d, col in columns.items():
            offset = 0
            for n in col:
                n.location = (x_of(d), y - offset)
                offset += _node_height(n) + GAP
            band = max(band, offset)
        placed[sec] = (y, band)
        y -= band + 150
    if shader and len(bands) > 1:                                  # centre the shader band beside the layers above it
        top = 0.0
        bottom = placed[bands[-2]][0] - placed[bands[-2]][1]
        want = (top + bottom) / 2.0 + placed["Shader"][1] / 2.0
        shift = want - placed["Shader"][0]
        others = [n for n in nodes if n not in members["Shader"]]
        right_of_others = (max(n.location[0] for n in others) + COLUMN) if others else 0
        left_of_shader = min(n.location[0] for n in members["Shader"])
        dx = max(0.0, right_of_others - left_of_shader)           # the shader band sits strictly to the right of everything else
        for n in members["Shader"]:
            x, yy = n.location[0], n.location[1]
            n.location = (x + dx, yy + shift)
    if frames:
        for sec in order:
            if len(members[sec]) < 2:
                continue
            fr = g.nodes.new("NodeFrame")
            fr.label = sec
            fr.label_size = 22
            fr.shrink = True
            for n in members[sec]:
                n.parent = fr


# ---------------------------------------------------------------------------------------------------------------------------------
# Texture mapping parameters
# ---------------------------------------------------------------------------------------------------------------------------------

# 'Use UV World Projection': the layer tiles by world position seen from above, not through a UV set.  The size of one repeat at tiling 1 is a
# constant inside the master, which is not exported.  1.5 m is measured: the damaged asphalt these materials use covers 1.3 to 1.8 m per repeat at
# tiling 1 on the Meteor road chunks, which map it through their UVs.  (The ground tiles' UV sets run once across 16 or 32 m, so reading them made
# MI_COM_AsphaltGrass_01's grass one texture across 43 m.)
WORLD_UV = -1
WORLD_PROJECTION_METRES = 1.5


def uv_params(p, sfx, extra_tiling=1.0):
    """(channel, scale, offset, rotation) of a layer: the master's UV tiling options apply unless 'Use UV Tiling Options' is explicitly off.
    The channel is WORLD_UV when the layer uses world projection."""
    channel = WORLD_UV if p.sw("Use UV World Projection", sfx, False) else p.num("UV Channel", sfx, 0.0)
    if channel != WORLD_UV:
        # The UV set the game really samples the layer's maps with.  'UV Channel' can't be read literally: every material that sets it to 1 is
        # sampled on UV set 0 (79 of 79), the wheelbarrow among them, whose set 1 put the bare metal on its painted bucket.
        for slot in ("BaseColor Map", "Normal Map", "HRM\\ORM Map"):
            ref = p.tex(slot, sfx)
            streamed = p.streamed.get(texture_stem(ref).lower()) if ref else None
            if streamed is not None:
                channel = float(streamed)
                break
    if p.w.get("Use UV Tiling Options" + sfx) is not False:        # the export lists the switch only when it was changed: absent means on
        master = p.num("UV Tiling Master", sfx, 1.0)
        u, v = p.num("U Tiling", sfx, 1.0), p.num("V Tiling", sfx, 1.0)
        scale = (master * u * extra_tiling, master * v * extra_tiling)
        offset = (p.num("U Offset", sfx, 0.0), p.num("V Offset", sfx, 0.0))
        if sfx == "" and p.sw("Use UV Atlas", "", False) and not p.sw("Atlas Use Custom Data", "", False):
            # A sheet of 2 x 2 posters: the mesh's UVs span the whole sheet and Atlas Index picks a cell.  The grid is not in the export: it was read off the
            # sheets (normal and corrupted versions side by side).  Index 0, the only one the materials set, is the top left.  With custom data see Graph.atlas_uv.
            scale = (scale[0] * 0.5, scale[1] * 0.5)
            offset = (offset[0], offset[1] + 0.5)
        return channel, scale, offset, p.num("Rotation", sfx, 0.0)
    return channel, (extra_tiling, extra_tiling), (0.0, 0.0), 0.0


def shaped(g, x, black_level, contrast, what="value"):
    """
    The master's RaiseBlackLevels + CheapContrast, identity at (1.0, 0.0).  Black level BL keeps that share of the original dark values and lifts
    the rest to white: x*BL + (1-BL) (BL 0.05 lifts almost everything to 1: a rough carpet).  Contrast c is lerp(-c, 1+c, x).
    """
    if abs(black_level - 1.0) > 1e-4:
        x = g.math("MULTIPLY_ADD", x, black_level, 1.0 - black_level, clamp=True, label="%s black level %.3g" % (what, black_level))
    if abs(contrast) > 1e-4:
        x = g.math("MULTIPLY_ADD", x, 1.0 + 2.0 * contrast, -contrast, clamp=True, label="%s contrast %.3g" % (what, contrast))
    return x


NORMAL_GROUP = "DBD Normal (rebuild Z, flip green)"


def normal_group(bpy_module):
    """
    The node group that turns an exported normal map into one Blender's Normal Map node accepts: Z rebuilt from X and Y (the export drops it:
    blue is always 1.0) and Unreal's downward green channel flipped.  Built once and shared by every material, so each normal map is ONE node.
    """
    groups = bpy_module.data.node_groups
    existing = groups.get(NORMAL_GROUP)
    if existing is not None:
        return existing
    ng = groups.new(NORMAL_GROUP, "ShaderNodeTree")
    ng.interface.new_socket("Color", in_out="INPUT", socket_type="NodeSocketColor")
    ng.interface.new_socket("Normal", in_out="OUTPUT", socket_type="NodeSocketColor")
    gg = Graph(ng, None, bpy_module, [])
    gg.section = "Rebuild Z, flip green"
    gi = gg.new("NodeGroupInput")
    go = gg.new("NodeGroupOutput")
    r, g_, _b = gg.separate(gi.outputs["Color"], label="R G (B is empty)")
    x = gg.math("MULTIPLY_ADD", r, 2.0, -1.0, label="x = R*2-1")
    y = gg.math("MULTIPLY_ADD", g_, -2.0, 1.0, label="y = 1-2G (flip)")                 # Unreal's Y points down, Blender's up
    s = gg.math("ADD", gg.math("MULTIPLY", x, x), gg.math("MULTIPLY", y, y), label="x2+y2")
    z = gg.math("SQRT", gg.math("SUBTRACT", 1.0, s, clamp=True), label="z = sqrt(1-x2-y2)")
    out = gg.combine(gg.math("MULTIPLY_ADD", x, 0.5, 0.5), gg.math("MULTIPLY_ADD", y, 0.5, 0.5), gg.math("MULTIPLY_ADD", z, 0.5, 0.5))
    gg.links.new(out, go.inputs["Normal"])
    arrange(gg, frames=False)
    return ng


def decode_normal(g, color):
    """One group node: the exported normal colour in, a Blender-ready tangent-space normal colour out (see normal_group)."""
    n = g.new("ShaderNodeGroup", label="Normal: rebuild Z, flip green")
    n.node_tree = normal_group(g.bpy)
    g.put(n.inputs[0], color)
    return n.outputs[0]


def flat_normal_color():
    return FLAT_NORMAL


# ---------------------------------------------------------------------------------------------------------------------------------
# One material layer
# ---------------------------------------------------------------------------------------------------------------------------------

class Layer(object):
    """The outputs of one built layer.  Any of them may be None (nothing to contribute)."""
    albedo = None
    alpha = None           # alpha output of the base-colour texture
    normal = None          # decoded colour (0..1 encoded), already flattened by the intensity (when below 1)
    normal_gain = 1.0      # an intensity above 1 = a stronger bump: applied as the Normal Map node's strength
    emission = None        # (colour, strength) a blend material's emissive layers give
    rough = None
    metal = None
    ao = None
    emissive = None
    placeholder = False    # the colour is only the master's placeholder (no texture, no colour of its own)


def _rgba(c, default=(1.0, 1.0, 1.0, 1.0)):
    if not isinstance(c, dict):
        return default
    return (c.get("R", 1.0), c.get("G", 1.0), c.get("B", 1.0), c.get("A", 1.0))


def is_placeholder_colour(c):
    """The masters' "nothing set" base colours (DA00FF, 7F00F7, 3600EC ...): purple / blue-violet with no green."""
    return isinstance(c, dict) and c.get("G", 1.0) < 0.02 and c.get("B", 0.0) > 0.88 and c.get("R", 1.0) < 0.9


TINT_WITHOUT_MAP = True
# The masters whose tint covers the whole surface when there is no tint map.  M_Simple_InteractableObject is M_Simple for hooks, gates and doors: without it
# their tint was skipped (Wormhole's hook webbing, MI_WRM_GigerTileHole_01_Interactable, stayed grey-blue instead of brown).
SIMPLE_MASTERS = ("M_Simple", "M_Simple_InteractableObject")
# ... and M_Foliage: its grass is pale straw until the grey-green Tint Color darkens it (MI_HideGrass01 came out near white without it)
WHOLE_TINT_MASTERS = SIMPLE_MASTERS + ("M_Foliage",)
# Liminal's Entity railings set saturation 0 on the Entity flesh texture, which would make them grey, but they are pink in the game.  What keeps the colour is
# not in the exports, so low saturation is ignored on this texture alone.  Other materials keep it: many pair saturation 0 with a coloured tint, like MI_Com_FabricAwningBasic_Blue_01.
FLESH_MIN_SATURATION = 0.5


def is_colour_map(ref):
    """
    Tint maps are not all colours: some slots hold a mask (T_Pallet_M, T_RgbMaskWithAlpha_Default) or even an ORM.  Multiplied over the albedo those paint it with
    soot, so only the colour maps are used: _BC textures, swatch atlases and _Tint maps.
    """
    stem = os.path.basename(str(ref)).split(".")[0].lower()
    return stem.endswith(("_bc", "_tint"))


def is_flesh_texture(ref):
    return bool(ref) and "t_com_entity_tile" in str(ref).lower()


def is_cyan_default(c):
    return isinstance(c, dict) and c.get("R", 1) < 0.01 and c.get("G", 0) > 0.98 and c.get("B", 0) > 0.98


def pm_source(p, pm_key, snow_key):
    """
    The texture to use when a base-layer slot is EMPTY.  PM_Diffuse / PM_Normals / PM_SpecularMasks hold the material's effective textures: they are
    the same file as the main slot in 70-86% of the M_Simple materials, and where the main slot is empty (snow, ice and other alternative modes:
    ~9% of ORM / 8% of normal slots, plus materials such as MI_COM_WindsweptSnow_01) they are the only place the real texture is.  A material with
    'Is Snow' on also lists it under the Snow slots.  Not used when the main slot has a texture whose switch is off (PM may be stale then).
    """
    ref = p.tex(pm_key)
    if ref:
        return pm_key, ref
    if p.sw("Is Snow", "", False):
        ref = p.tex(snow_key)
        if ref:
            return snow_key, ref
    return None


def build_layer(p, g, sfx, name):
    """Albedo / normal / roughness / metallic / AO of the material layer whose parameters carry the suffix `sfx`."""
    L = Layer()

    # ---- albedo: the map when its switch is on, else the flat colour
    ref = p.tex("BaseColor Map", sfx)
    if p.use("Use BaseColor Map", sfx) and ref:
        ch, sc, off, rot = uv_params(p, sfx, p.num("BaseColor Map Tiling", sfx, 1.0))
        tex = g.image(ref, g.uv(ch, sc, off, rot), color=True, role="BaseColor")
        if tex:
            L.albedo = tex[0]
            L.alpha = tex[1]
            log("%s albedo: map %s" % (name, os.path.basename(ref).split(".")[0]))
    tint_map = p.tex("BaseColor Tint Map") if sfx == "" and p.sw("Use Tint Map", "", False) else None
    if tint_map and not is_colour_map(tint_map):
        log("%s albedo: tint map %s skipped: it is a mask, not colours" % (name, os.path.basename(tint_map).split(".")[0]))
        tint_map = None
    if L.albedo is None and sfx == "" and not p.tex("BaseColor Map", ""):
        alt = pm_source(p, "PM_Diffuse", "Snow Basecolor")
        if alt and alt[1] != tint_map:          # PM_Diffuse can just be the tint map again: it is applied below, over the base colour
            tex = g.image(alt[1], g.uv(0), color=True, role="BaseColor")
            if tex:
                L.albedo, L.alpha = tex[0], tex[1]
                log("%s albedo: %s %s (the BaseColor Map slot is empty)" % (name, alt[0], os.path.basename(alt[1]).split(".")[0]))
    if L.albedo is None:
        colour = p.col("BaseColor", sfx)
        if colour is not None and is_placeholder_colour(colour):
            L.albedo = (0.5, 0.5, 0.5, 1.0)
            L.placeholder = sfx == ""
            log("%s albedo: no texture and only the master's placeholder colour (purple): neutral grey instead" % name)
        elif colour is not None:
            L.albedo = _rgba(colour)
            log("%s albedo: flat colour" % name)
    if L.albedo is not None:
        # hue / saturation / intensity adjustments (only meaningful when the master's switch is on)
        sat = p.num("BaseColor Saturation", sfx, p.num("Adjustment Saturation", sfx, 1.0))
        if sat < FLESH_MIN_SATURATION and is_flesh_texture(ref):
            log("%s albedo: saturation %.2f ignored on the Entity flesh texture" % (name, sat))
        elif p.sw("Use BaseColor Adjustments", sfx, False) and abs(sat - 1.0) > 1e-3:
            hs = g.new("ShaderNodeHueSaturation")
            g.put(hs.inputs[1], sat)
            g.put(hs.inputs[4], L.albedo)
            L.albedo = hs.outputs[0]
            log("%s albedo: saturation %.2f" % (name, sat))
        intensity = p.num("BaseColor Intensity", sfx, 1.0) * p.num("BaseColor Map Intensity", sfx, 1.0)
        if abs(intensity - 1.0) > 1e-3:
            L.albedo = g.mix_color(L.albedo, (intensity, intensity, intensity, 1.0), 1.0, blend="MULTIPLY")
            log("%s albedo: intensity %.2f" % (name, intensity))

    # ---- tint map: an atlas of flat colour swatches the mesh's UVs place each panel on (Umbra's hull: orange, mustard, grey, charcoal)
    tint_amount = p.num("Tint Map Intensity", "", 1.0)
    if tint_map and L.albedo is not None and tint_amount > 1.0 + 1e-3:
        log("%s albedo: tint map skipped (intensity %.3g is not a 0-1 amount: what the master does with it is unknown)" % (name, tint_amount))
    elif tint_map and L.albedo is not None:
        t = g.image(tint_map, g.uv(p.num("UV Channel Tint", "", 0.0)), color=True, role="Tint map")
        if t:
            L.albedo = g.mix_color(L.albedo, t[0], max(tint_amount, 0.0), blend="MULTIPLY", label="Tint map")
            log("%s albedo: tint map %s" % (name, os.path.basename(tint_map).split(".")[0]))

    # ---- tint (only where a mask exists: the default tint colour is cyan and the default mask is empty)
    if p.sw("Use Tint", sfx, False) or p.sw("Use Tint", "", False):
        mask_ref = p.tex("Tint Opacity Map") if p.sw("Use Tint Opacity Map", "", False) else None
        tint_colour = p.col("Tint Color")
        if L.albedo is not None and mask_ref and tint_colour:
            tile = p.num("Tint Opacity Map Tiling", "", 1.0)
            m = g.image(mask_ref, g.uv(p.num("UV Channel Tint", "", 0.0), (tile, tile)), color=False)
            if m:
                fac = g.math("MULTIPLY", g.bw(m[0]), p.num("Tint Opacity Map Intensity", "", 1.0), clamp=True)
                L.albedo = g.mix_color(L.albedo, _rgba(tint_colour), fac, blend="OVERLAY")
                log("%s tint: colour through the tint opacity map (overlay)" % name)
        elif L.albedo is not None and tint_colour and sfx == "" and p.master in WHOLE_TINT_MASTERS and not mask_ref and not is_cyan_default(tint_colour) and TINT_WITHOUT_MAP:
            # no map to confine it: the tint covers the whole surface.  Painted materials rely on this: many desaturate their texture and take their colour from here
            amount = min(max(p.num("BaseColor Tint Intensity", "", 1.0), 0.0), 1.0)
            L.albedo = g.mix_color(L.albedo, _rgba(tint_colour), amount, blend="OVERLAY")
            log("%s tint: colour over the whole surface (overlay %.2f)" % (name, amount))

    # ---- each placed copy its own shade between two colours (foliage: some clumps more yellow), by the object's or instance's random number
    low, high = p.col("Per Instance Minimum Color Variation"), p.col("Per Instance Maximum Color Variation")
    if L.albedo is not None and sfx == "" and isinstance(low, dict) and isinstance(high, dict) and             any(abs(low.get(k, 1.0) - high.get(k, 1.0)) > 1e-3 for k in "RGB"):
        info = g.new("ShaderNodeObjectInfo", label="Per copy random")
        shade = g.mix_color(_rgba(low), _rgba(high), info.outputs["Random"], label="Per instance colour variation")
        L.albedo = g.mix_color(L.albedo, shade, 1.0, blend="MULTIPLY")
        log("%s albedo: each copy shaded between the per-instance colours" % name)

    if L.albedo is not None and painted_blend(p) and p.sw("Use Tint", sfx, False) and not p.sw("Use Tint Opacity Map", sfx, False):
        tint_colour = p.col("Tint Color", sfx)
        if tint_colour and not is_cyan_default(tint_colour):
            amount = min(max(p.num("BaseColor Tint Intensity", sfx, 1.0), 0.0), 1.0)
            L.albedo = g.mix_color(L.albedo, _rgba(tint_colour), amount, blend="OVERLAY")
            log("%s tint: colour over the whole layer (overlay %.2f)" % (name, amount))

    # ---- normal
    nref = p.tex("Normal Map", sfx)
    if p.use("Use Normal Map", sfx) and nref:
        ch, sc, off, rot = uv_params(p, sfx, p.num("Normal Map Tiling", sfx, 1.0))
        tex = g.image(nref, g.uv(ch, sc, off, rot), color=False, role="Normal")
        if tex:
            nc = decode_normal(g, tex[0])
            inten = p.num("Normal Map Intensity", sfx, 1.0)
            if inten > 1.0 + 1e-3:
                L.normal_gain = inten
            elif abs(inten - 1.0) > 1e-3:
                nc = g.mix_color(FLAT_NORMAL, nc, max(inten, 0.0))                    # the master's FlattenNormal
            L.normal = nc
            log("%s normal: map %s (Z rebuilt, green flipped, intensity %.2f)" % (name, os.path.basename(nref).split(".")[0], inten))
    if L.normal is None and sfx == "" and not p.tex("Normal Map", ""):
        alt = pm_source(p, "PM_Normals", "Snow Normal")
        if alt:
            tex = g.image(alt[1], g.uv(0), color=False, role="Normal")
            if tex:
                L.normal = decode_normal(g, tex[0])
                log("%s normal: %s %s (the Normal Map slot is empty)" % (name, alt[0], os.path.basename(alt[1]).split(".")[0]))
    dref = p.tex("Normal Map Detail") if (sfx == "" and p.sw("Use Normal Map Detail", "", False)) else None
    if dref and L.normal is not None:
        ch, sc, off, rot = uv_params(p, "", p.num("Normal Map Detail Tiling", "", 1.0))
        dt = g.image(dref, g.uv(ch, sc, off, rot), color=False, role="Detail normal")
        if dt:
            L.normal = g.mix_color(L.normal, decode_normal(g, dt[0]), min(max(p.num("Normal Map Detail Intensity", "", 0.0), 0.0), 1.0), blend="OVERLAY")
            log("%s normal: detail normal overlaid" % name)

    # ---- ORM / HRM
    oref = p.tex("HRM\\ORM Map", sfx)
    # R is ambient occlusion in an ORM map but HEIGHT in an HRM map (checked on the pixels: an HRM texture's red is a narrow mid-grey band that
    # would darken the albedo by a third if used as AO): the switch says which, and so does the file name
    use_orm = p.sw("Use ORM", sfx, True) and not (oref and os.path.basename(oref).split(".")[0].lower().endswith("_hrm"))
    if p.use("Use HRM\\ORM Map", sfx) and oref:
        ch, sc, off, rot = uv_params(p, sfx, p.num("Roughness Map Tiling", sfx, 1.0))
        tex = g.image(oref, g.uv(ch, sc, off, rot), color=False, role="ORM" if use_orm else "HRM")
        if tex:
            r, gg, b = g.separate(tex[0])
            rough = shaped(g, gg, p.num("Roughness Map Black Level", sfx, 1.0), p.num("Roughness Map Contrast", sfx, 0.0), "roughness")
            mi = p.num("Roughness Map Intensity", sfx, 1.0)
            L.rough = g.math("MULTIPLY", rough, mi, clamp=True) if abs(mi - 1.0) > 1e-3 else rough
            L.metal = b
            if use_orm:
                L.ao = shaped(g, r, p.num("Occlusion Map Black Level", sfx, 1.0), p.num("Occlusion Map Contrast", sfx, 0.0), "AO")
            log("%s ORM: %s (%s)" % (name, os.path.basename(oref).split(".")[0], "R=AO G=rough B=metal" if use_orm else "R=height G=rough B=metal"))
    if L.rough is None and sfx == "" and not p.tex("HRM\\ORM Map", ""):
        alt = pm_source(p, "PM_SpecularMasks", "Snow HRM")
        if alt:
            tex = g.image(alt[1], g.uv(0), color=False, role="ORM")
            if tex:
                r, gg, b = g.separate(tex[0])
                hrm = os.path.basename(alt[1]).split(".")[0].lower().endswith("_hrm")
                L.rough, L.metal = gg, b
                if not hrm:
                    L.ao = r
                log("%s ORM: %s %s (the HRM\\ORM Map slot is empty; %s)" % (name, alt[0], os.path.basename(alt[1]).split(".")[0],
                                                                          "R=height G=rough B=metal" if hrm else "R=AO G=rough B=metal"))
    if L.rough is None:
        L.rough = p.num("Roughness Intensity", sfx, 0.5)
        log("%s roughness: constant %.2f (no ORM map)" % (name, L.rough))
    if p.sw("Is 100% Metallic", sfx, False):
        L.metal = 1.0
    elif p.sw("Is 100% Dialectric", sfx, False) or L.metal is None:
        L.metal = 0.0
    return L


# ---------------------------------------------------------------------------------------------------------------------------------
# Blending layers
# ---------------------------------------------------------------------------------------------------------------------------------

def blend_layers(g, base, over, fac):
    """`over` on top of `base` by `fac` (a socket or number): albedo, normal, roughness, metallic, AO."""
    out = Layer()
    for attr, kind in (("albedo", "color"), ("normal", "color"), ("rough", "float"), ("metal", "float"), ("ao", "float")):
        a, b = getattr(base, attr), getattr(over, attr)
        if b is None:
            setattr(out, attr, a)
        elif a is None:
            setattr(out, attr, b)
        elif kind == "color":
            setattr(out, attr, g.mix_color(a, b, fac))
        else:
            setattr(out, attr, g.mix_float(a, b, fac))
    out.alpha = getattr(base, "alpha", None)
    out.normal_gain = max(getattr(base, "normal_gain", 1.0), getattr(over, "normal_gain", 1.0))
    return out


def sharpen_edge(g, f):
    """
    The panel's Layer Edge sliders: (f - point) * sharpness + 0.5, clamped.  The game's transition between two layers is harder than the blend
    masks alone give; this steepens it around `edge_point` (a mostly dark mask needs a point well below 0.5 or the upper layer all but vanishes).
    Identity at the default sharpness of 1.
    """
    k = OPTIONS["transition"]
    if k <= 1.001:
        return f
    applied("Layer edges")
    return g.math("MULTIPLY_ADD", f, k, 0.5 - k * OPTIONS["edge_point"], clamp=True, label="layer edge (x%.3g at %.2f)" % (k, OPTIONS["edge_point"]))


def sharpen(g, f, spread):
    """(f - 0.5) * 0.5 / spread + 0.5: identity at the master's default spread of 0.5, sharper for a smaller spread."""
    if abs(spread - 0.5) < 1e-4 or spread <= 0.0:
        return f
    return g.math("MULTIPLY_ADD", g.math("SUBTRACT", f, 0.5), 0.5 / spread, 0.5, clamp=True)


def layer_height(p, g, sfx):
    """Height of a blend-map layer: its Custom HeightMap, else the red channel of an HRM map (R is height there).  None without either."""
    if p.sw("Use Heightmap from Material 1", sfx, False) and sfx != "":
        sfx = ""                                           # 'Use Heightmap from Material 1': the height of the base layer drives this blend
    href = p.tex("Custom HeightMap", sfx)
    oref = p.tex("HRM\\ORM Map", sfx)
    ref = href or (oref if oref and os.path.basename(oref).split(".")[0].lower().endswith("_hrm") else None)
    if not ref:
        return None
    ch, sc, off, rot = uv_params(p, sfx, p.num("BaseColor Map Tiling", sfx, 1.0))
    tex = g.image(ref, g.uv(ch, sc, off, rot), color=False, role="Height")
    return g.separate(tex[0])[0] if tex else None


# Which materials each look setting actually changed in the current run (name of the setting -> set of material names); main() returns the counts.
APPLIED = {}
CURRENT = ["", ""]       # the material being built, and the JSON file it is built from


def applied(setting):
    APPLIED.setdefault(setting, set()).add(CURRENT[0])


# Tuning dials for the behaviours that could not be read from the exports (the master materials' graphs are not exported).  The panel sets them
# before each run; these are the defaults.
OPTIONS = {
    "paint_mode": "MAX",       # blend texture + vertex paint on the same layer: MASK (the blend texture alone), ADD, MULTIPLY or MAX.
                               # MASK: rendering the chapel wall from its mesh data, ADD hid the whole block layer and MULTIPLY zeroed layers where
                               # the vertex colours are black (Industrial brick walls); the blend texture alone matches the in-game look
    "detail": 0.5,             # share of the grime / wear detail layers (normal + roughness only; never colour)
    "height_sharp": 4.0,       # how hard a height blend separates the two layers
    "stain": 0.8,              # strength of the flat-colour grime / soot layers (Material Bottom / Top without a colour texture)
    "grime_scale": 1.0,        # size of world-aligned grime masks: tile edge in metres at tiling 1
    "emissive": 0.9,           # multiplier on every emission strength (glowing screens, lamps, signs); 0 turns them off
    "transition": 1.0,         # sharpness of every layer-to-layer edge (1 = as the mask is; higher = starker)
    "edge_point": 0.5,         # mask value where that edge sits (lower = the upper layer covers more)
    "leaves": 0.6,             # strength of the leaves-on-top layer of the structure masters (0 turns it off)
    "moss_on": False,          # crawling moss of the structure masters (off by default: many materials switch it on, see crawling_moss)
    "moss": 0.6,               # its strength
}


def up_facing(g, contrast, height):
    """0..1 mask of how much the surface faces up (world normal Z): only clearly up-facing surfaces count."""
    geo = g.new("ShaderNodeNewGeometry")
    sep = g.new("ShaderNodeSeparateXYZ", label="World normal")
    g.links.new(geo.outputs["Normal"], sep.inputs[0])
    gain = 4.0 + min(max(contrast, 0.0), 4.0)
    return g.math("MULTIPLY_ADD", sep.outputs["Z"], gain, -(0.8 - min(max(height, 0.0), 0.15)) * gain, clamp=True, label="faces up")


def is_placeholder_layer_colour(p, sfx):
    colour = p.col("BaseColor", sfx)
    return colour is None or is_placeholder_colour(colour)


def stain_mask(p, g, sfx, mref):
    """
    The layer's OpacityMap as a 0..1 grey value.  'World aligned' masks are projected from world position on three planes (front, side, top)
    and blended by the surface normal, so on a wall the texture's up is world up and it tiles in metres, not through the mesh's UVs.
    """
    aligned = p.sw("Use World Aligned OpacityMap", sfx, False) or p.sw("Use World Aligned Opacity Map", sfx, False)
    tiling = p.num("UV Tiling Master Opacity", sfx, 1.0)
    if not aligned:
        tex = g.image(mref, g.uv(p.num("UV Channel Opacity", sfx, 0.0), (tiling,) * 2), color=False, role="Grime mask")
        return g.bw(tex[0]) if tex else None
    return world_mask(g, mref, tiling / max(OPTIONS["grime_scale"], 1e-3))


def world_mask(g, mref, scale):
    """A texture's grey value projected from world position on three planes (front, side, top), blended by the surface normal; `scale` tiles per metre."""
    geo = g.new("ShaderNodeNewGeometry", label="World position / normal")
    pos = g.new("ShaderNodeSeparateXYZ", label="World position")
    nrm = g.new("ShaderNodeSeparateXYZ", label="World normal")
    g.links.new(geo.outputs["Position"], pos.inputs[0])
    g.links.new(geo.outputs["Normal"], nrm.inputs[0])

    def plane(first, second, label):
        u = g.math("MULTIPLY", pos.outputs[first], scale)
        v = g.math("MULTIPLY", pos.outputs[second], scale)
        comb = g.new("ShaderNodeCombineXYZ", label=label)
        g.links.new(u, comb.inputs[0])
        g.links.new(v, comb.inputs[1])
        tex = g.image(mref, comb.outputs[0], color=False, role="Grime " + label)
        return g.bw(tex[0]) if tex else None

    front, side, top = plane("X", "Z", "front"), plane("Y", "Z", "side"), plane("X", "Y", "top")
    if front is None or side is None or top is None:
        return None
    wy = g.math("ABSOLUTE", nrm.outputs["Y"], label="front weight")      # a wall facing Y shows the X-Z plane
    wx = g.math("ABSOLUTE", nrm.outputs["X"], label="side weight")
    wz = g.math("ABSOLUTE", nrm.outputs["Z"], label="top weight")
    mixed = g.math("MULTIPLY_ADD", top, wz, g.math("MULTIPLY_ADD", side, wx, g.math("MULTIPLY", front, wy)))
    total = g.math("MAXIMUM", g.math("ADD", g.math("ADD", wx, wy), wz), 1e-4)
    return g.math("DIVIDE", mixed, total, clamp=True, label="grime mask")


def add_stain_layer(p, g, result, sfx, label):
    """
    A Material Bottom / Top layer that is a flat colour (soot, dirt) through a grunge mask: the dark patches on the chapel walls.  Its mask is
    thresholded around 0.5 with the layer's Blending Intensity as the sharpness, so the layer covers patches, not the whole surface.
    """
    g.section = "Material %s" % label
    mref = p.tex("OpacityMap", sfx)
    layer = build_layer(p, g, sfx, label)
    layer.metal = 0.0                       # the layer's ORM slot can hold a grunge mask: never read its channels as metal / AO
    layer.ao = None
    layer.rough = p.num("Roughness Intensity", sfx, 0.5)
    g.section = "Blending"
    grey = stain_mask(p, g, sfx, mref)
    if grey is None:
        return result
    sharp = max(p.num("Blending Intensity", sfx, 10.0), 1.0)
    edge = g.math("MULTIPLY", g.math("SUBTRACT", grey, 0.5), sharp, clamp=True, label="%s grime edge" % label)
    fac = g.math("MULTIPLY", edge, OPTIONS["stain"], clamp=True, label="%s grime strength" % label)
    log("%s: flat-colour grime layer through %s (sharpness %.3g, strength %.0f%%)" % (label, os.path.basename(mref).split(".")[0], sharp, OPTIONS["stain"] * 100))
    applied("Grime")
    layer_normal, layer.normal = layer.normal, None
    out = blend_layers(g, result, layer, fac)                      # colour and roughness through the grime mask
    if layer_normal is not None and result.normal is not None:      # the layer's grunge normal: its own strength, set by Wear Detail (0.5 = as authored)
        detail = min(OPTIONS["detail"] * 2.0, 2.0)
        if detail > 1e-3:
            out.normal = g.mix_color(result.normal, layer_normal, g.math("MULTIPLY", fac, detail, clamp=True, label="%s wear detail" % label))
            applied("Wear detail")
            log("%s: grime normal detail at %.0f%%" % (label, detail * 100))
        else:
            out.normal = result.normal
    elif layer_normal is not None:
        out.normal = layer_normal
    return out


def add_detail_layer(p, g, result, sfx, label):
    """
    A Material Bottom / Top layer without a colour texture of its own (grime / wear detail): its normal map and its roughness overlay, through its
    opacity mask, at reduced strength.  It leaves the colour alone: the flat colours of these layers coated whole walls.
    """
    nref, oref = p.tex("Normal Map", sfx), p.tex("HRM\\ORM Map", sfx)
    mref = p.tex("OpacityMap", sfx)
    wants_rough = p.sw("Use Roughness as Overlay", sfx, False) and oref
    if not mref or not (nref or wants_rough):
        return result
    g.section = "Detail %s" % label
    ot = g.image(mref, g.uv(p.num("UV Channel Opacity", sfx, 0.0), (p.num("UV Tiling Master Opacity", sfx, 1.0),) * 2), color=False, role="Detail mask")
    if not ot:
        return result
    strength = min(p.num("Blending Intensity", sfx, 10.0) / 10.0, 1.0) * OPTIONS["detail"]
    fac = g.math("MULTIPLY", g.bw(ot[0]), strength, clamp=True, label="%s detail strength" % label)
    ch, sc, off, rot = uv_params(p, sfx, p.num("Normal Map Tiling", sfx, 1.0))
    if nref and result.normal is not None:
        nt = g.image(nref, g.uv(ch, sc, off, rot), color=False, role="Detail normal")
        if nt:
            result.normal = g.mix_color(result.normal, decode_normal(g, nt[0]), fac)
            applied("Wear detail")
            log("%s: detail normal %s (through the mask, at most %.0f%%)" % (label, os.path.basename(nref).split(".")[0], strength * 100))
    if wants_rough and result.rough is not None:
        rt = g.image(oref, g.uv(ch, sc, off, rot), color=False, role="Detail roughness")
        if rt:
            result.rough = g.mix_float(result.rough, g.separate(rt[0])[1], fac)
            log("%s: roughness overlay %s" % (label, os.path.basename(oref).split(".")[0]))
    return result


def is_sand_default(c):
    """
    Layer 3's sandy colour on the human-tech hulls (0.594, 0.563, 0.495).  The material does not set it and it is not in the master, so it comes from a parent
    that is not exported (MI_UBA_HumanTechMain).  Left out on looks: built as a layer it gives hard pale patches that the game does not show.
    """
    return isinstance(c, dict) and abs(c.get("R", 0) - 0.59375) < 1e-3 and abs(c.get("G", 0) - 0.562856) < 1e-3 and abs(c.get("B", 0) - 0.494792) < 1e-3


def painted_blend(p):
    """
    A blend material whose one mask, painted for this mesh, gives its outline as well as its layers: the vault tarps, with folds in red, grime in green and patches
    in blue.  Its tints and flat layers are the look itself.  Elsewhere they stay off: ~440 materials set such colours and have not been checked.
    """
    return p.sw("Use Masked", "", False) and p.sw("Use BlendMap RGB", "", False) and bool(p.tex("Blend Map RGB", "         ."))


# Each blend layer's emissive slots are numbered apart from the layer's own suffix: {layer: (Emissive Map / Intensity / Tiling suffix, UV Channel suffix)}
LAYER_EMISSIVE_SLOTS = {2: (" .....", " ....."), 3: (" ......", " ......."), 4: (" .......", " ........")}


def layer_glow(p, g, number, sfx, layer, fac):
    """
    What an emissive layer gives off, only where the blend shows that layer: the embers on burnt wood.  Its map when it has one, else the layer's own colour.  A layer
    needs its 'Use Emissive' switch: Barn walls have the map switched on and nothing else, and a street of glowing barns would be wrong.  Returns (colour, strength).
    """
    slots = LAYER_EMISSIVE_SLOTS.get(number)
    if not slots or not p.sw("Use Emissive", sfx, False):
        return None
    strength = p.num("Intensity", slots[0], 0.5)
    if strength <= 0.0:
        return None
    colour = layer.albedo
    ref = p.tex("Emissive Map", slots[0]) if p.sw("Use Emissive Map", slots[0], False) else None
    if ref:
        tile = p.num("UV Tiling Master", slots[0], 1.0)
        tex = g.image(ref, g.uv(p.num("UV Channel", slots[1], 0.0), (tile, tile)), color=True, role="Emissive")
        if tex:
            colour = tex[0]
    if colour is None:
        return None
    log("emission: layer %d%s, strength %.2f" % (number, " map %s" % os.path.basename(ref).split(".")[0] if ref else " colour", strength))
    return g.mix_color((0.0, 0.0, 0.0, 1.0), colour, fac), strength


def own_opacity_map(p, sfx):
    return p.tex("Tint Opacity Map", sfx) if p.sw("Use Tint Opacity Map", sfx, False) else None


def colour_layer(p, sfx, number):
    """
    A layer with no texture of its own that the blend mask still spreads over the base: its flat colour is the whole layer.  On Umbra's and Wormhole's hulls
    these are the worn metal, the dust and the dark dirt, which is also what keeps the steel from looking clean and shiny.  Only tint-map materials and layers
    with a mask of their own for now: the dirt and the stick arms on the snowmen.  ~440 other materials set such colours and have not been checked.
    """
    glowing = p.sw("Use Emissive", sfx, False) and p.num("Intensity", LAYER_EMISSIVE_SLOTS.get(number, ("",))[0], 0.5) > 0.0
    if not ((p.sw("Use Tint Map", "", False) or own_opacity_map(p, sfx) or painted_blend(p) or glowing) and p.sw("Use BlendMap RGB", "", False) and p.tex("Blend Map RGB", "         .")):
        return False
    if number > 2 and not p.sw("Use Material %d" % number, "", False):
        return False
    colour = p.col("BaseColor", sfx)
    if colour is None or is_placeholder_colour(colour) or is_sand_default(colour):
        return False
    return p.sw("Use BaseColor", sfx, False)


def painted_colour_layer(p, sfx, number):
    """
    A flat-colour layer the artist paints on with vertex colour ('Use VertexPaint Options'): the soot and char on burnt wood (MI_Asy_WoodAsylum_01's near-black
    1A1919), dirt on floors.  It shows only where a mesh is painted, so it blends like a textured layer.  46 layers in 43 materials.
    """
    if not (p.sw("Use Vertex Paint", "", False) and p.sw("Use VertexPaint Options", sfx, False) and p.sw("Use BaseColor", sfx, False)):
        return False
    if number > 2 and not p.sw("Use Material %d" % number, "", False):
        return False
    colour = p.col("BaseColor", sfx)
    return colour is not None and not is_placeholder_colour(colour)


def build_blendmap(p, g):
    """M_BlendMapRgb: layers 1..4 (suffixes '', ' .', '  .', '   .') blended by Blend Map RGB (R, G, B) or vertex paint."""
    sfxs = ["", " .", "  .", "   ."]
    layers = []
    flat = set()
    for i, sfx in enumerate(sfxs):
        mapped = i == 0 or (p.use("Use BaseColor Map", sfx) and p.tex("BaseColor Map", sfx))
        if not mapped and painted_colour_layer(p, sfx, i + 1):
            mapped = True
            log("L%d: a flat colour painted on with vertex colour" % (i + 1))
        if not mapped and colour_layer(p, sfx, i + 1):
            flat.add(i + 1)
        if mapped or i + 1 in flat:
            g.section = "Layer %d%s" % (i + 1, " (base)" if i == 0 else "")
            layers.append((i + 1, sfx, build_layer(p, g, sfx, "L%d" % (i + 1))))
    g.section = "Blend masks"
    if len(layers) == 1:
        log("only the base layer is live")
        return build_ws_overlay(p, g, layers[0][2])
    mref = p.tex("Blend Map RGB", "         .")
    mask = None
    if (p.sw("Use BlendMap RGB", "", True) or p.sw("Use BlendMap Options", "", False)) and mref:
        ch, sc, off, rot = uv_params(p, "         .")
        mt = g.image(mref, g.uv(ch, sc, off, rot), color=False, role="Blend map")
        if mt:
            mask = g.separate(mt[0])
            log("blend: Blend Map RGB (R->L2, G->L3, B->L4)")
    vertex = None
    if mask is None or p.sw("Use Vertex Paint", "", False):
        vc = g.new("ShaderNodeVertexColor")
        vertex = g.separate(vc.outputs[0])
        log("blend: vertex paint (R->L2, G->L3, B->L4)%s" % (" - the mesh needs a colour attribute" if mask is None else ""))
    spreads = {2: p.num("Red Spread", "", 0.5), 3: p.num("Grn Spread", "", 0.5), 4: p.num("Blu Spread", "", 0.5)}
    falloffs = {2: p.num("Red FallOff", "", 0.5), 3: p.num("Grn FallOff", "", 0.5), 4: p.num("Blu FallOff", "", 0.5)}
    g.section = "Blending"
    result = layers[0][2]
    glows = []

    def blend_in(number, sfx, layer, fac):
        glow = layer_glow(p, g, number, sfx, layer, fac)
        if glow:
            glows.append(glow)
        return blend_layers(g, result, layer, fac)

    for number, sfx, layer in layers[1:]:
        chan = number - 2                              # 0 = R, 1 = G, 2 = B
        if chan > 2:
            continue
        f = mask[chan] if mask is not None else vertex[chan]
        if number in flat:
            # Spread = the mask value where the layer is at full strength, FallOff = how far below that it fades in.  Green at 1 / 0.025 is rare specks of
            # dust, blue at 0.8 / 0.8 is broad soft dirt; read as plain coverage the green channel paints the whole hull.
            if painted_blend(p):
                f = sharpen(g, f, spreads[number])     # read as a painted mask, like a layer with a texture
                layer.metal = 0.0
                layer.ao = None
                log("L%d: colour layer through the painted mask" % number)
                result = blend_in(number, sfx, layer, f)
                continue
            # A falloff wider than the spread would start above zero and coat the whole mesh, however empty the mask.
            fall = min(max(falloffs[number], 0.01), max(spreads[number], 0.01))
            f = g.math("MULTIPLY_ADD", f, 1.0 / fall, -(spreads[number] - fall) / fall, clamp=True,
                       label="spread %.3g falloff %.3g" % (spreads[number], falloffs[number]))
            log("L%d: colour layer (spread %.3g, falloff %.3g)" % (number, spreads[number], falloffs[number]))
            oref = own_opacity_map(p, sfx)
            if oref:
                tile = p.num("Tint Opacity Map Tiling", sfx, 1.0)
                ot = g.image(oref, g.uv(p.num("UV Channel Tint", sfx, 0.0), (tile, tile)), color=False, role="Layer mask")
                if ot:
                    grey = shaped(g, g.bw(ot[0]), p.num("Tint Opacity Map Black Level", sfx, 1.0), p.num("Tint Opacity Map Contrast", sfx, 0.0), "layer mask")
                    f = g.math("MULTIPLY", f, grey, clamp=True, label="through its own mask")
                    log("L%d: through %s" % (number, os.path.basename(oref).split(".")[0]))
                opacity = p.num("BaseColor Opacity", sfx, 1.0)
                if opacity < 1.0 - 1e-3:
                    f = g.math("MULTIPLY", f, opacity, clamp=True, label="colour opacity")
                layer.metal = 0.0                      # these slots hold grunge masks: never read their channels as metal / AO
                layer.ao = None
            result = blend_in(number, sfx, layer, f)
            continue
        grunge = False
        if mask is not None and vertex is not None and p.sw("Use BlendMap Options", "", False):
            spread = max(spreads.get(number, 0.5), 0.01)
            diff = g.math("SUBTRACT", vertex[chan], mask[chan], label="paint - grunge")
            f = g.math("MULTIPLY_ADD", diff, 1.0 / spread, 0.5, clamp=True, label="grunge edge (spread %.3g)" % spread)
            grunge = True
            log("L%d: vertex paint eaten away by the blend map grunge (spread %.3g)" % (number, spread))
        elif mask is not None and vertex is not None:
            # both on: the painted vertex colour adds to the baked mask.  (Multiplying them shrank the top layer to a quarter of the wall: the
            # chapel's vertex paint averages 0.44 and its mask 0.52, and in the game that layer covers most of the wall.)
            mode = OPTIONS["paint_mode"]
            applied("Vertex colours")
            if mode == "MULTIPLY":
                f = g.math("MULTIPLY", f, vertex[chan], clamp=True, label="mask * paint")
            elif mode == "MAX":
                f = g.math("MAXIMUM", f, vertex[chan], label="max(mask, paint)")
            elif mode == "ADD":
                f = g.math("ADD", f, vertex[chan], clamp=True, label="mask + paint")
            # MASK: the blend texture alone
        if p.sw("Use HeightBlend", sfx, False) and not grunge:
            h = layer_height(p, g, sfx)
            if h is not None:
                # where the paint is partial the layer's own height decides which spots show first (plaster wearing off the brick);
                # unpainted (0) stays the lower layer, fully painted (1) shows the layer
                eroded = g.math("MULTIPLY", g.math("SUBTRACT", g.math("ADD", f, h), 1.0), OPTIONS["height_sharp"], clamp=True, label="height blend")
                full = g.math("MULTIPLY", g.math("SUBTRACT", f, 0.9), 10.0, clamp=True, label="fully painted")
                f = g.math("MAXIMUM", eroded, full, label="plaster wear")
                applied("Height blend")
                log("L%d: height blend" % number)
        if not grunge:
            f = sharpen(g, f, spreads.get(number, 0.5))
        result = blend_in(number, sfx, layer, sharpen_edge(g, f))
    for sfx, switch, label in ((" ..", "Use Material Bottom", "bottom"), (" ...", "Use Material Top", "top")):
        if p.sw(switch, "", False) and not p.tex("BaseColor Map", sfx):
            if p.tex("OpacityMap", sfx) and not is_placeholder_layer_colour(p, sfx):
                result = add_stain_layer(p, g, result, sfx, label)         # a flat colour through a mask
            else:
                result = add_detail_layer(p, g, result, sfx, label)        # normal / roughness only
    final = build_ws_overlay(p, g, result)
    if glows:
        top = max(strength for _, strength in glows)
        total = None
        for colour, strength in glows:
            part = g.mix_color(colour, (strength / top, strength / top, strength / top, 1.0), 1.0, blend="MULTIPLY")
            total = part if total is None else g.mix_color(total, part, 1.0, blend="ADD")
        final.emission = (total, top)
    return final


def add_mask_layer(p, g, result, sfx, label):
    """A Material Bottom / Top layer (suffix ' ..' / ' ...') blended over `result` by its OpacityMap (a flat colour when it has no texture)."""
    g.section = "Material %s" % label
    layer = build_layer(p, g, sfx, label)
    g.section = "Blending"
    oref = p.tex("OpacityMap", sfx)
    if oref:
        ch, sc, off, rot = uv_params(p, "", 1.0)
        ot = g.image(oref, g.uv(p.num("UV Channel Opacity", sfx, 0.0), (p.num("UV Tiling Master Opacity", sfx, 1.0),) * 2), color=False)
        if ot:
            fac = g.math("MULTIPLY", g.bw(ot[0]), p.num("Blending Intensity", sfx, 10.0) / 10.0, clamp=True)
            log("%s layer blended by OpacityMap%s" % (label, sfx))
            return blend_layers(g, result, layer, sharpen_edge(g, fac))
    log("%s layer is on but has no opacity mask: skipped" % label)
    return result


def build_simple(p, g):
    """M_Simple family: base material, optional Material Bottom (' ..') / Top (' ...') by their opacity masks."""
    g.section = "Base material"
    result = build_layer(p, g, "", "base")
    for sfx, switch, label in ((" ..", "Use Material Bottom", "bottom"), (" ...", "Use Material Top", "top")):
        if p.sw(switch, "", False):
            result = add_mask_layer(p, g, result, sfx, label)
    return build_ws_overlay(p, g, result)


WS = "     ."


def build_ws_overlay(p, g, result):
    """
    The 'WS' (winter / snow) overlay group (suffix '     .'): the frost on concrete bags, snow caps on props.  Its textures sit in
    'BaseColor Map     .' / 'HRM\\ORM Map     .' / 'WS Snow Normal Map     .'; 'WS Is Snow' or 'Use WS Material Overlay' turns it on.  The master
    masks it by the world-space up-facing of the surface (Unreal's WorldNormal.Z against WS Height / WS Blend Contrast, times WS Opacity).
    That mask is an approximation here: Blender has no equivalent of the master's graph, so it is built from the geometry normal.
    """
    if not (p.sw("Use WS Material Overlay", "", False) or p.sw("WS Is Snow", "", False)):
        return result
    cref = p.tex("BaseColor Map", WS)
    if not cref:
        log("winter overlay is on but has no texture: skipped")
        return result
    g.section = "Winter / snow overlay"
    L = Layer()
    ch, sc, off, rot = uv_params(p, WS, p.num("BaseColor Map Tiling", WS, 1.0))
    uv = g.uv(ch, sc, off, rot)
    tex = g.image(cref, uv, color=True, role="BaseColor")
    if tex:
        L.albedo = tex[0]
        bright = p.num("WS Snow Brightness", "", 1.0)
        if abs(bright - 1.0) > 1e-3:
            L.albedo = g.mix_color(L.albedo, (bright, bright, bright, 1.0), 1.0, blend="MULTIPLY")
    nref = p.tex("WS Snow Normal Map", WS) or p.tex("Normal Map", WS)
    if nref:
        nt = g.image(nref, uv, color=False, role="Normal")
        if nt:
            L.normal = decode_normal(g, nt[0])
            L.normal_gain = max(p.num("WS Snow Normal Intensity", "", 1.0), 1.0)
    oref = p.tex("HRM\\ORM Map", WS)
    if oref:
        ot = g.image(oref, uv, color=False, role="HRM")
        if ot:
            L.rough = g.separate(ot[0])[1]
            L.metal = 0.0
    if L.rough is None:
        L.rough = p.num("Roughness Intensity", WS, 0.5)
        L.metal = 0.0
    # mask: the surface faces up (world normal Z), sharpened by the blend contrast, scaled by the overlay opacity
    geo = g.new("ShaderNodeNewGeometry")
    sep = g.new("ShaderNodeSeparateXYZ", label="World normal")
    g.links.new(geo.outputs["Normal"], sep.inputs[0])
    contrast = p.num("WS Blend Contrast", WS, 0.5)
    height = p.num("WS Height", WS, 0.1)
    up = g.math("MULTIPLY_ADD", sep.outputs["Z"], 1.0 + 4.0 * contrast, -(0.5 + height) * (1.0 + 4.0 * contrast), clamp=True,
                label="faces up")
    fac = g.math("MULTIPLY", up, min(max(p.num("WS Opacity", WS, 1.0), 0.0), 1.0), clamp=True, label="overlay opacity")
    log("winter overlay: %s over the base by up-facing mask (approximation; height %.3f, contrast %.2f)" % (os.path.basename(cref).split(".")[0], height, contrast))
    return blend_layers(g, result, L, fac)


# ---------------------------------------------------------------------------------------------------------------------------------
# Generic path (older masters, the PM_* generation, anything unfamiliar)
# ---------------------------------------------------------------------------------------------------------------------------------

# the material's own slots first, the PM_* copies last: PM_Normals can hold something else (the wind-sway detail normal on the tree leaves)
DIFFUSE_KEYS = ("Main_BaseColor", "BaseColorTexture", "BaseColor Map", "Base Color Texture", "DiffuseTexture", "Diffuse", "BC_Texture",
                "BaseColor", "MainTexture", "Texture", "ColorMap", "PM_Diffuse")
# Alpha_Mask: the character and charm masters' opacity slot (hair strands, lashes, glasses lenses, glass charms, fur, drips: 55 materials).  Without it
# they fell back to the colour texture's alpha, which is solid on most of them: hair rendered as solid helmets, lenses as grey discs.
OPACITY_KEYS = ("Opacity Map", "Opacity Mask", "OpacityMap", "Alpha Texture", "Opacity Map          .", "Opacity Details", "Alpha_Mask")
NORMAL_KEYS = ("Main_Normal", "NormalTexture", "Normal Map", "NormalMap Texture", "NormalMap_Texture", "Normal", "PM_Normals")
ORM_KEYS = ("Main_ORM", "HRM\\ORM Map", "ORM", "PackedTextures_MSR", "PM_SpecularMasks")


def first_texture(p, keys):
    for k in keys:
        ref = p.tex(k)
        if ref and not k.startswith("T_"):
            return k, ref
    return None, None


FLAT_COLOUR_KEYS = ("BaseColor", "Base Color", "DiffuseColor", "Diffuse Color", "Color", "Colour")
ROUGH_KEYS = ("Roughness", "RoughnessValue", "Roughness Value")
METAL_KEYS = ("Metallic", "MetallicValue", "Metallic Value")


def first_param(table, keys):
    for k in keys:
        if k in table:
            return k, table[k]
    return None, None


def is_legacy_hair(p):
    """
    The oldest survivor hair (Dwight's default, MI_DFHair01_TAA): no colour texture, only the black placeholder.  Its colour is the Root Color and Tip color
    values, blended along the strands by RootTip_Mask, and its strands are cut out by Alpha_Mask.  Newer hair has a real colour texture and keeps the generic path.
    """
    ref = first_texture(p, DIFFUSE_KEYS)[1]
    no_colour_map = not ref or texture_stem(ref).lower() in ("black", "black_linear")
    return bool(p.col("Root Color") and p.col("Tip color") and p.tex("RootTip_Mask") and no_colour_map)


def build_legacy_hair(p, g, L, uv):
    grad = g.image(p.tex("RootTip_Mask"), uv, color=False, role="Root to tip")
    if grad:
        colour = g.mix_color(_rgba(p.col("Root Color")), _rgba(p.col("Tip color")), g.bw(grad[0]), label="Root to tip colour")
        overall = p.col("OverallColor")
        if isinstance(overall, dict) and colour_peak(overall) > 0.0:
            colour = g.mix_color(colour, _rgba(overall), 1.0, blend="MULTIPLY", label="OverallColor")
        L.albedo = colour
        log("hair: colour from Root Color to Tip color along %s (no colour texture: an early hair material)" % texture_stem(p.tex("RootTip_Mask")))
    if p.tex("Alpha_Mask"):
        mask = g.image(p.tex("Alpha_Mask"), uv, color=False, role="Strands")
        if mask:
            L.alpha = g.bw(mask[0])
            log("hair: strands cut out by %s" % texture_stem(p.tex("Alpha_Mask")))
    if "RoughnessValue" in p.s:                   # not 'Roughness': these materials carry an unused one at 0, which made the hair mirror-glossy
        L.rough = min(max(float(p.s["RoughnessValue"]), 0.0), 1.0)
        log("hair: roughness %.2f (RoughnessValue)" % L.rough)


def _json_textures(node, out):
    """Every Texture2D an asset's JSON references, as asset paths, in order."""
    if isinstance(node, dict):
        if str(node.get("ObjectName", "")).startswith("Texture2D'") and node.get("ObjectPath"):
            if node["ObjectPath"] not in out:
                out.append(node["ObjectPath"])
        for v in node.values():
            _json_textures(v, out)
    elif isinstance(node, list):
        for v in node:
            _json_textures(v, out)
    return out


def master_textures(p, base_path):
    """
    The textures the material's master holds itself (not as parameters), so its instances list none: M_Moon samples its own picture.  The master is
    the recorded one, else the end of the Parent chain of any export of this material (the Models export of a material does not record its parent).
    """
    master = p.master
    if not master:
        for path in dbd_matio.file_index(base_path, (".json",)).get(CURRENT[0] or ""):
            try:
                raw = dbd_matio.read_json(path)
                master = dbd_matio.inherit_parents(raw, dbd_matio.legacy_material(raw), base_path, dbd_matio.find_material_json)[1]
            except Exception:
                master = None
            if master:
                break
    if not master:
        return []
    path = dbd_matio.find_material_json(master, base_path, log=lambda *a: None)
    try:
        return _json_textures(dbd_matio.read_json(path), []) if path else []
    except Exception:
        return []


def build_master_texture_glow(p, g, L, uv):
    """
    An unlit material that sets no texture and takes its one picture from its master (the moon): that picture, tinted by the material's colour, glows at
    its intensity, cut out by the picture's alpha.
    """
    if not p.unlit or L.albedo is not None or any(p.tex(k) for k in p.t):
        return
    refs = master_textures(p, g.base)
    if len(refs) != 1:
        return
    tex = g.image(refs[0], uv, color=True, role="Master's own texture")
    if not tex:
        return
    colours = [c for c in p.c.values() if isinstance(c, dict) and colour_peak(c) > 0.0]
    colour = tex[0]
    if len(colours) == 1:
        colour = g.mix_color(tex[0], _rgba(colours[0]), 1.0, blend="MULTIPLY")
    intensities = [float(v) for k, v in p.s.items() if "intensity" in k.lower() and isinstance(v, (int, float))]
    strength = intensities[0] if len(intensities) == 1 else 1.0
    L.emission = (colour, strength)
    L.alpha = tex[1]
    log("master's texture %s glows, tinted, strength %.2f, cut out by its alpha" % (texture_stem(refs[0]), strength))


def build_generic_extras(p, g, L, uv):
    build_master_texture_glow(p, g, L, uv)
    """What the generic path adds beyond the three maps: flat colour / roughness / metal parameters, the older structure masters' own roughness /
    metal / baked-AO maps, and the leaves on top."""
    if L.albedo is None and is_legacy_hair(p):
        build_legacy_hair(p, g, L, uv)
    # flat colour where there is no albedo texture (a single colour parameter is what these older materials have)
    if L.albedo is None:
        key, colour = first_param(p.c, FLAT_COLOUR_KEYS)
        if isinstance(colour, dict) and not is_placeholder_colour(colour):
            L.albedo = _rgba(colour)
            log("generic albedo: flat colour (%s)" % key)
    # roughness / metal: the older structure master has its own maps (switched on by TextureRoughness / CustomRoughness ...)
    if L.rough is None and (p.sw("TextureRoughness", "", False) or p.sw("CustomRoughness", "", False)):
        ref = p.tex("RoughnessMap Texture")
        tex = g.image(ref, uv, color=False) if ref else None
        if tex:
            L.rough = g.separate(tex[0])[0]
            log("generic roughness: RoughnessMap Texture")
    if L.metal is None and (p.sw("TextureMetallic", "", False) or p.sw("CustomMetallic", "", False)):
        ref = p.tex("MetallicMap Texture")
        tex = g.image(ref, uv, color=False) if ref else None
        if tex:
            L.metal = g.separate(tex[0])[0]
            log("generic metal: MetallicMap Texture")
    if L.rough is None:
        key, v = first_param(p.s, ROUGH_KEYS)
        if v is not None:
            L.rough = min(max(float(v), 0.0), 1.0)
            log("generic roughness: %s %.2f" % (key, L.rough))
    if L.metal is None:
        key, v = first_param(p.s, METAL_KEYS)
        if v is not None:
            L.metal = min(max(float(v), 0.0), 1.0)
            log("generic metal: %s %.2f" % (key, L.metal))
    # baked colour-AO map of the older structure master ('Blend AO Into Diffuse' / 'UseCAOBlend')
    cao = p.tex("CAOBlendTexture")
    if cao and os.path.basename(cao).split(".")[0].lower() != "grey" and (p.sw("Blend AO Into Diffuse", "", False) or p.sw("UseCAOBlend", "", False)) and L.ao is None:
        ch = 1 if p.sw("Use Second UV for CAO", "", False) else 0
        tile = p.num("CAOBlendTiling", "", 1.0) or 1.0
        tex = g.image(cao, g.uv(ch, (tile, tile)), color=False)
        if tex:
            L.ao = g.bw(tex[0])
            log("generic AO: CAOBlendTexture")
    # leaves on top (the older and the newer structure masters)
    leaves_on_top(p, g, L)
    crawling_moss(p, g, L)


def crawling_moss(p, g, L):
    """
    The structure masters' crawling moss ('21_UseCrawlingMoss'): the moss texture over up-facing surfaces, through the world-aligned MossMaskTexture.
    Optional (panel toggle, off by default): the switch is on for over a hundred materials, including ones where moss looks implausible (a hospital
    lamp), and the master's own height / curve controls are not readable, so where it appears is an approximation.
    """
    if not (OPTIONS["moss_on"] and OPTIONS["moss"] > 0 and p.sw("21_UseCrawlingMoss", "", False) and L.albedo is not None):
        return
    ref = p.tex("21_MossTexture")
    if not ref:
        return
    g.section = "Crawling moss"
    tile = p.num("21_MossTileAmount", "", 1.0) or 1.0
    uv = g.uv(0, (tile * (p.num("21_MossTileAmountX", "", 1.0) or 1.0), tile * (p.num("21_MossTileAmountY", "", 1.0) or 1.0)))
    tex = g.image(ref, uv, color=True, role="Moss")
    if not tex:
        return
    colour = tex[0]
    tint = p.col("21_MossColorTint")
    if isinstance(tint, dict) and not (tint["R"] >= 0.999 and tint["G"] >= 0.999 and tint["B"] >= 0.999):
        colour = g.mix_color(colour, _rgba(tint), 1.0, blend="MULTIPLY")
    fac = up_facing(g, 1.0, 0.0)
    mref = p.tex("MossMaskTexture")
    if mref and p.sw("21_TextureMask", "", False):
        grey = world_mask(g, mref, max(p.num("MossMaskScaleXY", "", 0.2), 0.01) / max(OPTIONS["grime_scale"], 1e-3))
        if grey is not None:
            fac = g.math("MULTIPLY", fac, grey, clamp=True, label="moss mask")
    fac = g.math("MULTIPLY", fac, OPTIONS["moss"], clamp=True, label="moss strength")
    L.albedo = g.mix_color(L.albedo, colour, fac)
    nref = p.tex("21_MossNormalTexture")
    if nref and L.normal is not None:
        nt = g.image(nref, uv, color=False, role="Moss normal")
        if nt:
            L.normal = g.mix_color(L.normal, decode_normal(g, nt[0]), fac)
    oref = p.tex("21_MossORMTexture")
    if oref and L.rough is not None and not isinstance(L.rough, (int, float)):
        ot = g.image(oref, uv, color=False, role="Moss ORM")
        if ot:
            L.rough = g.mix_float(L.rough, g.separate(ot[0])[1], fac)
    applied("Crawling moss")
    log("generic albedo: crawling moss (%s) over the up-facing surfaces" % os.path.basename(ref).split(".")[0])


def leaves_on_top(p, g, L):
    """LeavesTexture over the up-facing surfaces, where the material switches 'UseLeavesOnTop' on and the texture is a real one."""
    if not (p.sw("UseLeavesOnTop", "", False) and OPTIONS["leaves"] > 0 and L.albedo is not None):
        return
    ref = p.tex("LeavesTexture")
    if not ref or re.search(r"environment_mud", ref, re.I):          # the master's default leaves texture
        return
    g.section = "Leaves on top"
    tile = p.num("LeavesTileAmount", "", 1.0) or 1.0
    uv = g.uv(0, (tile * p.num("LeavesTileAmountX", "", 1.0), tile * p.num("LeavesTileAmountY", "", 1.0)),
              (p.num("LeavesOffsetX", "", 0.0), p.num("LeavesOffsetY", "", 0.0)))
    tex = g.image(ref, uv, color=True, role="Leaves")
    if not tex:
        return
    colour = tex[0]
    tint = p.col("LeavesTint")
    if isinstance(tint, dict):
        colour = g.mix_color(colour, _rgba(tint), 1.0, blend="MULTIPLY")
    fac = g.math("MULTIPLY", up_facing(g, 1.0, 0.0), min(max(p.num("LeavesBlend", "", 1.0), 0.0), 1.0) * OPTIONS["leaves"], clamp=True, label="leaves on top")
    L.albedo = g.mix_color(L.albedo, colour, fac)
    applied("Leaves on top")
    log("generic albedo: leaves on top (%s)" % os.path.basename(ref).split(".")[0])


def main_uv(p, g):
    """
    UVs of the Main layer / the older structure master's maps: Main_Tiling (a colour holding U, V), Main_Offset, Main_Rotation and TilingAmount.
    Ignoring them left the bricks of Industrial's plaster walls (Main_Tiling 2.25) and ~120 other materials (tiling 2 to 8) several times too big.
    """
    scale = vec2(p, "Main_Tiling") if "Main_Tiling" in p.c else (1.0, 1.0)
    if abs(scale[0]) < 1e-6 or abs(scale[1]) < 1e-6:
        scale = (1.0, 1.0)
    amount = p.num("TilingAmount", "", 1.0) or 1.0
    scale = (scale[0] * amount, scale[1] * amount)
    offset = vec2(p, "Main_Offset", (0.0, 0.0)) if "Main_Offset" in p.c else (0.0, 0.0)
    return g.uv(0, scale, offset, p.num("Main_Rotation", "", 0.0))


def is_silhouette(p):
    """
    M_Unlit_Billboards: the distant tree and house cards (21 materials: Apple Pie, Quantum, Umbra).  One texture, 'Opacity Mask', a black shape on
    white; the shape is what is drawn, a dark silhouette against the sky, so the mask is used the other way round.
    """
    return bool(p.unlit and p.blend_mode == 1 and p.tex("Opacity Mask") and not first_texture(p, DIFFUSE_KEYS)[1])


def is_screen(p):
    """
    The CRT screen master (M_Ind_Camp_ComputerScreen_Master: the Apple Pie arcade screens, Umbra's camp screens).  Its picture is the 'Overlay' texture;
    the rest is scrolling noise, glitches and a flipbook of static that a still build leaves out.
    """
    return bool(p.tex("Overlay")) and ("ScreenGlowIntensity" in p.s or "ScreenEmissiveIntensity" in p.s)


def texture_stem(ref):
    """'T_Name' of an Unreal asset path, for telling whether two slots hold the same texture."""
    return os.path.basename(re.sub(r"\.[^./\\]*$", "", str(ref).strip().replace("\\", "/"))).lower()


VERTEX_LAYER_CHANNELS = {"Red": 0, "Green": 1, "Blue": 2}


def vertex_colour_layers(p):
    """The layer names of a material whose maps are named Base_Color_<colour> / Normal_<colour> / ORM_<colour> (the Wales walls' master)."""
    return [m.group(1) for m in (re.match(r"^Base_Color_(Red|Green|Blue)$", k) for k in p.t) if m and p.tex(m.group(0))]


def build_vertex_colour_layers(p, g, names):
    """
    Layers named after vertex-colour channels: Blue is the wall itself, and each other layer is painted over it by its channel of the mesh's vertex
    colour (Red: the bare wall where the plaster has come off).  The 'Heightmap' breaks the painted edge up, sharpened by 'Blending Contrast'.
    """
    order = sorted(names, key=lambda n: (n != "Blue", VERTEX_LAYER_CHANNELS[n]))
    out, colours = None, None
    for name in order:
        scale = p.num("UV_Scale_" + name, "", 1.0) or 1.0
        uv = g.uv(0, (scale, scale))
        L = Layer()
        tex = g.image(p.tex("Base_Color_" + name), uv, color=True, role=name + " colour")
        if tex:
            L.albedo = tex[0]
        ref = p.tex("Normal_" + name)
        tex = g.image(ref, uv, color=False, role=name + " normal") if ref else None
        if tex:
            L.normal = decode_normal(g, tex[0])
        ref = p.tex("ORM_" + name)
        tex = g.image(ref, uv, color=False, role=name + " ORM") if ref else None
        if tex:
            L.ao, L.rough, L.metal = g.separate(tex[0])
        log("%s layer: %s (UV scale %.3g)" % (name, texture_stem(p.tex("Base_Color_" + name)), scale))
        if out is None:
            out = L
            continue
        if colours is None:
            colours = g.separate(g.new("ShaderNodeVertexColor", label="Vertex paint").outputs[0])
        fac = colours[VERTEX_LAYER_CHANNELS[name]]
        href = p.tex("Heightmap")
        htex = g.image(href, g.uv(0), color=False, role="Blend height") if href else None
        if htex:
            h = g.bw(htex[0])
            if p.num("Invert Blend Heightmap", "", 0.0) > 0.5:
                h = g.math("SUBTRACT", 1.0, h)
            contrast = p.num("Blending Contrast", "", 1.0)
            # Unreal's height lerp: the paint moved by the height, then its contrast raised around the middle
            x = g.math("ADD", g.math("MULTIPLY_ADD", fac, 2.0, -1.0), h)
            fac = g.math("MULTIPLY_ADD", x, 1.0 + 2.0 * contrast, -contrast, clamp=True, label="height blend (contrast %.3g)" % contrast)
            log("%s layer: painted by vertex colour %s, edge broken up by %s" % (name, name.lower(), texture_stem(href)))
        else:
            log("%s layer: painted by vertex colour %s" % (name, name.lower()))
        out = blend_layers(g, out, L, fac)
    return out


def build_generic(p, g):
    g.section = "Textures"
    names = vertex_colour_layers(p)
    if names:
        L = build_vertex_colour_layers(p, g, names)
        build_generic_extras(p, g, L, g.uv(0))
        if L.rough is None:
            L.rough = 0.5
        if L.metal is None:
            L.metal = 0.0
        return L
    L = Layer()
    uv = main_uv(p, g)
    key, ref = first_texture(p, DIFFUSE_KEYS)
    albedo_ref = ref
    if ref:
        tex = g.image(ref, uv, color=True)
        if tex:
            L.albedo, L.alpha = tex[0], tex[1]
            log("generic albedo: %s" % key)
            tint = p.col("ColorTintColour")
            if p.sw("UseColorTint", "", False) and isinstance(tint, dict) and not (tint["R"] >= 0.999 and tint["G"] >= 0.999 and tint["B"] >= 0.999):
                L.albedo = g.mix_color(L.albedo, _rgba(tint), 1.0, blend="MULTIPLY")
                log("generic albedo: colour tint (ColorTintColour)")
            if key == "Main_BaseColor":
                # the Main layer's own tint and saturation, as each splat layer has (Coal Tower's ground is darkened to 0.7)
                L.albedo = tint_layer(p, g, "Main", L.albedo)
    key, ref = first_texture(p, NORMAL_KEYS)
    if ref:
        tex = g.image(ref, uv, color=False)
        if tex:
            L.normal = decode_normal(g, tex[0])
            log("generic normal: %s" % key)
    # the older structure master has its own roughness / metal maps: they win over the PM_SpecularMasks copy (whose layout is not an ORM map)
    own_maps = (p.tex("RoughnessMap Texture") and (p.sw("TextureRoughness", "", False) or p.sw("CustomRoughness", "", False))) or                (p.tex("MetallicMap Texture") and (p.sw("TextureMetallic", "", False) or p.sw("CustomMetallic", "", False)))
    key, ref = first_texture(p, tuple(k for k in ORM_KEYS if not (own_maps and k == "PM_SpecularMasks")))
    if ref and albedo_ref and texture_stem(ref) == texture_stem(albedo_ref):
        # the export can name the colour map in the specular slot too (the Alchemist room's painted ceiling): it holds no roughness or metal
        log("generic ORM: %s is the colour map again, not used" % key)
        ref = None
    if ref:
        tex = g.image(ref, uv, color=False)
        if tex:
            r, gg, b = g.separate(tex[0])
            L.ao, L.rough, L.metal = r, gg, b
            log("generic ORM: %s (R=AO G=rough B=metal)" % key)
    if L.albedo is None and is_screen(p):
        L.albedo = (0.01, 0.01, 0.01, 1.0)           # a powered screen: dark glass, the picture is all glow (see emission_source)
        L.rough = 0.15
        log("screen: dark glass, the Overlay picture glows")
    build_generic_extras(p, g, L, uv)
    if L.rough is None:
        L.rough = 0.5
    if L.metal is None:
        L.metal = 0.0
    if p.master and re.search(r"Structures|Foliage|Decal|Glass|Opacity|TreeBark|Interactable", p.master):
        if p.sw("21_UseCrawlingMoss", "", False) and not OPTIONS["moss_on"]:
            log("master %s: this material has crawling moss, left out (switch 'Crawling Moss' on in Look Settings to add it)" % p.master)
    return L


# ---------------------------------------------------------------------------------------------------------------------------------
# Surface
# ---------------------------------------------------------------------------------------------------------------------------------

def specular_level(p, fam):
    """
    Blender's 'Specular IOR Level' (0.5 = Unreal's default 4% reflectance) where the material sets a specular value, else None (leave the default).
    M_Simple has no per-material specular: 'Specular' is 1.0 on every material and 'Use Specular' is on for 6 of 3,041.
    """
    def clamp(v):
        return min(max(float(v), 0.0), 1.0)
    if fam == "water":
        return clamp(p.num("Specular_Multiply", "", 0.5))
    if fam == "simple":
        return clamp(p.num("Specular", "", 1.0)) if p.sw("Use Specular", "", False) else None
    if fam == "blend":
        return clamp(p.num("Specular Value", "", 0.5)) if p.sw("Use Specular Value", "", False) else None
    for key in ("Main_SpecValue", "SpecularValue"):
        if key in p.s:
            return clamp(p.s[key])
    if p.sw("CustomSpecular", "", False) and "CustomSpecular" in p.s:
        return clamp(p.s["CustomSpecular"])
    return None


# ---------------------------------------------------------------------------------------------------------------------------------
# Splat layers of the 'Main_ / Red_ / Green_ / Cyan_' masters (M_Structures_v2 and the masters built on the same layout)
# ---------------------------------------------------------------------------------------------------------------------------------
# Only materials that really have a splat layer take this path; every other material of those masters, and the older M_Structures
# (BaseColorTexture / CAOBlendTexture naming, no splat layers), keep the generic path.

SPLAT_LAYERS = (("Red", 0), ("Green", 1), ("Cyan", 2), ("Alpha", 3))        # layer prefix, channel of Splat_RGBAMask / vertex colour


def splat_layers(p):
    """(prefix, channel) of the splat layers that have a texture of their own."""
    return [(pre, ch) for pre, ch in SPLAT_LAYERS if p.tex(pre + "_BaseColor") or p.tex(pre + "_Normal") or p.tex(pre + "_ORM")]


def vec2(p, name, default=(1.0, 1.0)):
    c = p.c.get(name)
    if not isinstance(c, dict):
        return default
    return (float(c.get("R", default[0])), float(c.get("G", default[1])))


def tint_layer(p, g, pre, albedo):
    """<pre>_BaseColorTint and <pre>_BaseColorSaturation on a layer's colour."""
    tint = p.c.get(pre + "_BaseColorTint")
    if isinstance(tint, dict) and not (abs(tint["R"] - 1) < 1e-3 and abs(tint["G"] - 1) < 1e-3 and abs(tint["B"] - 1) < 1e-3):
        albedo = g.mix_color(albedo, _rgba(tint), 1.0, blend="MULTIPLY")
        log("%s albedo: tint" % pre)
    sat = p.num(pre + "_BaseColorSaturation", "", 1.0)
    if abs(sat - 1.0) > 1e-3:
        hs = g.new("ShaderNodeHueSaturation")
        g.put(hs.inputs[1], sat)
        g.put(hs.inputs[4], albedo)
        albedo = hs.outputs[0]
    return albedo


def layer_uv_frame(p, pre):
    """(scale, offset) of a splat layer."""
    scale, offset = vec2(p, pre + "_Tiling"), vec2(p, pre + "_Offset", (0.0, 0.0))
    if abs(scale[0]) < 1e-6 or abs(scale[1]) < 1e-6:
        scale = (1.0, 1.0)
    parent = None
    if pre == "Red" and p.sw("Use_Red_MainVariant", "", False):
        # a variant of the Main layer lives in the Main layer's UV space: its tiling and offset are on top of Main's (Industrial's painted bricks must be
        # the same size as the burned ones under them)
        parent = "Main"
    elif pre == "Cyan" and p.sw("Use_Cyan_GreenVariant", "", False):
        parent = "Green"
    elif p.sw("UVs_UseWorld", "", False):
        # The ground masters (MI_DirtTerrain02 and 20-odd others): the layers' tiling is about 1 against the Main layer's 4 to 8, and at 1 across a whole
        # 16 m tile Coal Tower's twigs came out with pine cones 60 cm wide.  Their textures match the Main layer's scale, so they tile on top of it.
        # The master's graph is not exported: this is read from the textures.
        parent = "Main"
    if parent == "Main" and "Main_Tiling" in p.c:
        mt = vec2(p, "Main_Tiling")
        amount = p.num("TilingAmount", "", 1.0) or 1.0
        mo = vec2(p, "Main_Offset", (0.0, 0.0))
        scale = (scale[0] * mt[0] * amount, scale[1] * mt[1] * amount)
        offset = (offset[0] + mo[0], offset[1] + mo[1])
    elif parent == "Green":
        gs, go = layer_uv_frame(p, "Green")
        scale = (scale[0] * gs[0], scale[1] * gs[1])
        offset = (offset[0] + go[0], offset[1] + go[1])
    return scale, offset


def build_splat_layer(p, g, pre, base):
    """One splat layer: <pre>_BaseColor / _Normal / _ORM with its tiling, tint and saturation; what it lacks it takes from `base`."""
    L = Layer()
    scale, offset = layer_uv_frame(p, pre)
    uv = g.uv(0, scale, offset, p.num(pre + "_Rotation", "", 0.0))
    ref = p.tex(pre + "_BaseColor")
    tex = g.image(ref, uv, color=True, role="BaseColor") if ref else None
    if tex:
        L.albedo = tex[0]
        log("%s albedo: %s" % (pre, os.path.basename(ref).split(".")[0]))
        L.albedo = tint_layer(p, g, pre, L.albedo)
    else:
        L.albedo = base.albedo
    ref = p.tex(pre + "_Normal")
    tex = g.image(ref, uv, color=False, role="Normal") if ref else None
    if tex:
        L.normal = decode_normal(g, tex[0])
        flat = p.num(pre + "_NormalFlatness", "", 0.0)
        if flat > 1e-3:
            L.normal = g.mix_color(L.normal, FLAT_NORMAL, min(flat, 1.0))
        log("%s normal: %s" % (pre, os.path.basename(ref).split(".")[0]))
    else:
        L.normal = base.normal
    ref = p.tex(pre + "_ORM")
    tex = g.image(ref, uv, color=False, role="ORM") if ref else None
    if tex:
        r, gg, b = g.separate(tex[0])
        L.rough, L.metal, L.ao = gg, b, r
        log("%s ORM: %s (R=AO G=rough B=metal)" % (pre, os.path.basename(ref).split(".")[0]))
    else:
        L.rough, L.metal, L.ao = base.rough, base.metal, base.ao
    return L


def build_splat(p, g):
    """The Main layer exactly as the generic path builds it, plus the splat layers blended over it."""
    result = build_generic(p, g)
    live = splat_layers(p)
    g.section = "Blend masks"
    mask = None
    mref = p.tex("Splat_RGBAMask")
    # Only where the material switches the mask on.  Many carry a leftover mask texture with the switch off (Farm's shack planks have T_IceNoise),
    # and reading it smeared their rusty-metal layer over the wood.
    if mref and p.use("Use_Splat_RGBAMask"):
        tile = vec2(p, "Splat_RGBAMask_Tiling")
        off = vec2(p, "Splat_RGBAMask_Offset", (0.0, 0.0))
        tile = tile if min(tile) > 1e-6 else (1.0, 1.0)
        rot = p.num("Splat_RGBAMaskRotation", "", 0.0)
        if p.sw("RGBAMaskUVObjectBound", "", False):
            # the mask spans the object's bounding box, not its UVs (Coal Tower's ground tile has UVs running past 1)
            vec = g.bounds_uv(tile, off, rot)
            log("blend: splat mask over the object's bounds")
        else:
            vec = g.uv(0, tile, off, rot)
        mt = g.image(mref, vec, color=False, role="Splat mask")
        if mt:
            rr, gg, bb = g.separate(mt[0])
            mask = (rr, gg, bb, mt[1])
            log("blend: Splat_RGBAMask (R=Red, G=Green, B=Cyan, A=Alpha layer)")
    vertex = None
    if mask is None or p.sw("RGBAMask+VertexColors", "", False):
        vc = g.new("ShaderNodeVertexColor")
        rr, gg, bb = g.separate(vc.outputs[0])
        vertex = (rr, gg, bb, vc.outputs[1])
        log("blend: vertex colours (R=Red, G=Green, B=Cyan, A=Alpha layer)%s" % (" - the mesh needs a colour attribute" if mask is None else ""))
    base = result
    g.section = "Blending"
    for pre, ch in live:
        layer = build_splat_layer(p, g, pre, base)
        if mask is not None and vertex is not None:
            # The meshes' unpainted vertex colours are BLACK (the Industrial brick walls: red 0, green / blue about 0.02), so multiplying them with the
            # mask made the layers vanish.  Painted vertex colour adds to the mask instead (the same dial as the blend-map materials).
            mode = OPTIONS["paint_mode"]
            applied("Vertex colours")
            if mode == "MULTIPLY":
                f = g.math("MULTIPLY", mask[ch], vertex[ch], clamp=True, label="splat * paint")
            elif mode == "MAX":
                f = g.math("MAXIMUM", mask[ch], vertex[ch], label="max(splat, paint)")
            elif mode == "MASK":
                f = mask[ch]
            else:
                f = g.math("ADD", mask[ch], vertex[ch], clamp=True, label="splat + paint")
            log("%s: splat mask %s vertex colours" % (pre, {"MULTIPLY": "x", "MAX": "max", "MASK": "alone,", "ADD": "+"}.get(mode, "+")))
        else:
            f = (mask if mask is not None else vertex)[ch]
        result = blend_layers(g, result, layer, sharpen_edge(g, f))
    return result


def build_water(p, g):
    """
    The puddle shader: no surface texture, just dark tinted water, nearly a mirror, in the shape of PuddleShape.  Its ripple and flow settings animate it and have no
    place in a still build.  The master's graph is not exported: the shape map with Falloff as its power is a reading of the parameters.
    """
    L = Layer()
    colour = p.col("Water Tint")
    L.albedo = _rgba(colour) if colour else (0.01, 0.01, 0.01, 1.0)
    L.rough = max(p.num("Roughness_Multiply", "", 0.01), 0.0)
    L.metal = 0.0
    log("water: tint, roughness %.2f" % L.rough)
    g.section = "Water"
    shape = p.tex("PuddleShape")
    tex = g.image(shape, g.uv(0), color=False, role="Puddle shape") if shape else None
    if tex:
        L.alpha = g.math("POWER", g.bw(tex[0]), max(p.num("Falloff", "", 1.0), 0.01), clamp=True, label="puddle falloff")
        log("water: shape %s" % os.path.basename(shape).split(".")[0])
    normal = p.tex("Water_Normal_01") or p.tex("PM_Normals")
    if normal:
        tile = p.num("N1_Tiling", "", 1.0)
        t = g.image(normal, g.uv(0, (tile, tile)), color=False, role="Normal")
        if t:
            L.normal = decode_normal(g, t[0])
            strength = p.num("Strength", "", 1.0)
            if abs(strength - 1.0) > 1e-3:
                L.normal_gain = strength
    return L


def family(p):
    m = p.master or ""
    if "PuddleShape" in p.t:
        return "water"
    if m == "M_BlendMapRgb":
        return "blend"
    if "Main_BaseColor" in p.t and splat_layers(p) and (p.tex("Splat_RGBAMask") or p.sw("Use_VertexColorBlending", "", False)):
        return "splat"
    if m.startswith("M_Simple"):
        return "simple"
    # same parameter names and switch conventions as M_Simple (checked: 80 of 81 decals and all 33 foliage materials switch their maps on)
    if m in ("M_Foliage", "M_Decal", "M_MeshDecal_Translucent", "M_Glass") or m.startswith(("M_OpacityTranslucent", "M_OpacityDithering")):
        return "simple"
    if not m:                                   # no master recorded: go by the slot names
        if any(k.startswith("Blend Map RGB") for k in p.t):
            return "blend"
        if p.tex("BaseColor Map") or p.tex("HRM\\ORM Map") or p.tex("Normal Map"):
            return "simple"
    return "generic"


def colour_peak(c):
    """The brightest channel of a colour, or 0.  Emissive values run well past 1 (a bulb's is 15), and Blender takes those as colour times strength."""
    return max(float(c.get(k, 0.0)) for k in "RGB") if c else 0.0


def scaled_colour(c, peak):
    return (float(c.get("R", 0.0)) / peak, float(c.get("G", 0.0)) / peak, float(c.get("B", 0.0)) / peak, 1.0)


def structure_emission(p, g):
    """
    M_Structures_v2: each of Main, Red, Green, Cyan and Alpha has its own value and mask, the channels through the splat mask.  Returns (colour, strength), or None.
    """
    found = []
    for channel, index in (("Main", None), ("Red", 0), ("Green", 1), ("Cyan", 2), ("Alpha", 3)):
        custom = channel == "Red" and p.sw("Use_Red_CustomEmissive", "", False)
        if not (custom or p.sw("Use_%s_Emissive" % channel, "", False) or p.sw("Use_%s_EmissiveMask" % channel, "", False)):
            continue
        value = p.col("%s_EmissiveValue" % channel)
        peak = colour_peak(value)
        if peak <= 0.0:
            continue
        ref = p.tex("%s_EmissiveMask" % channel) if custom or p.sw("Use_%s_EmissiveMask" % channel, "", False) else None
        found.append((channel, index, value, peak, None if ref and "white" in os.path.basename(ref).lower() else ref))
    if not found:
        return None
    top = max(f[3] for f in found)
    splat_ref = p.tex("Splat_RGBAMask") if p.use("Use_Splat_RGBAMask") else None
    layered = any(f[1] is not None for f in found)
    splat = g.image(splat_ref, g.uv(0), color=False, role="Splat mask") if splat_ref and layered else None
    if splat is None and layered and p.sw("Use_VertexColorBlending", "", False):
        # No splat texture (the engine's Black_Linear is not exported): the layers are painted with vertex colour, so the glow is too.  Without this the
        # oil lamps' red layer (the glass and flame) lit the whole lamp.
        vc = g.new("ShaderNodeVertexColor", label="Vertex paint")
        r, gg, b = g.separate(vc.outputs[0])
        splat = (None, vc.outputs[1])
        channels = (r, gg, b)
        log("emission: layers through the vertex paint")
    else:
        channels = None
    total = None
    for channel, index, value, peak, ref in found:
        colour = scaled_colour(value, top)
        if ref:
            tex = g.image(ref, g.uv(0), color=True, role="%s emissive mask" % channel)
            if not tex:
                continue
            colour = g.mix_color(tex[0], colour, 1.0, blend="MULTIPLY")
        if index is not None and splat:
            amount = splat[1] if index == 3 else (channels[index] if channels else g.separate(splat[0])[index])
            colour = g.mix_color((0.0, 0.0, 0.0, 1.0), colour, amount)
        total = colour if total is None else g.mix_color(total, colour, 1.0, blend="ADD")
        log("emission: %s value %.3g%s" % (channel, peak, " through %s" % os.path.basename(ref).split(".")[0] if ref else ""))
    return (total, top) if total is not None else None


def custom_emission(p, g):
    """The 012_ lights: one mask, its red channel lit in one colour and its green in another.  Returns (colour, strength), or None."""
    ref = p.tex("012_EmissiveMask")
    if not (ref and p.sw("012_UseCustomEmissive", "", False) and p.sw("012_UseCustomEmissiveMask", "", False)):
        return None
    red, green = p.col("012_EmissiveValueR"), p.col("012_EmissiveValueG")
    top = max(colour_peak(red), colour_peak(green))
    tex = g.image(ref, g.uv(0), color=False, role="Emissive mask") if top > 0.0 else None
    if not tex:
        return None
    r, gg, _ = g.separate(tex[0])
    total = g.mix_color((0.0, 0.0, 0.0, 1.0), scaled_colour(red, top), r)
    log("emission: 012 mask %s, value %.3g" % (os.path.basename(ref).split(".")[0], top))
    return g.mix_color(total, scaled_colour(green, top), gg, blend="ADD"), top


def emission_source(p, g, L):
    """Where this material's glow comes from: each master keeps it somewhere else.  Returns (colour, strength before the panel's slider), or None."""
    if p.sw("Use Emissive", "", False) or p.sw("Use Emissive Map", " ....", False):
        colour = p.col("Emissive Color", " ....")
        strength = p.num("Intensity", " ....", 0.5)
        eref = p.tex("Emissive Map", " ....") if p.sw("Use Emissive Map", " ....", False) else None
        if eref and strength > 0.0:
            tex = g.image(eref, g.uv(p.num("UV Channel", " ....", 0.0)), color=True)
            if tex:
                # the master's yellow would turn a colour map's cyan green and its pink red: only a colour the material really sets tints the map
                log("emission: map, strength %.2f" % strength)
                # ... nor one inherited from a parent: MIM_Simple_Emissive_03's blue turned Gas Heaven's red circle black
                own = p.own_colours is None or ("Emissive Color" + " ....") in p.own_colours
                return (g.mix_color(tex[0], _rgba(colour), 1.0, blend="MULTIPLY") if colour and own and not is_emissive_default(colour) else tex[0]), strength
        oref = p.tex("Opacity Map", " ....") if p.sw("Use Opacity Map", " ....", False) else None
        if oref and strength > 0.0 and colour and not is_emissive_default(colour):
            tex = g.image(oref, g.uv(p.num("UV Channel", " ....", 0.0)), color=False, role="Emissive mask")
            if tex:
                log("emission: colour through %s, strength %.2f" % (os.path.basename(oref).split(".")[0], strength))
                return g.mix_color((0.0, 0.0, 0.0, 1.0), _rgba(colour), g.bw(tex[0])), strength
        custom = custom_emission(p, g)
        if custom:
            return custom
        flat = p.col("Emmisive Color")                 # with two m's: the whole surface glows
        if colour_peak(flat) > 0.0 and strength > 0.0:
            peak = colour_peak(flat)
            log("emission: Emmisive Color over the whole surface, strength %.2f" % (strength * peak))
            return scaled_colour(flat, peak), strength * peak
        if colour and colour.get("A", 0) > 0 and strength > 0.0 and not eref:
            log("emission: flat colour, strength %.2f" % strength)
            return _rgba(colour), strength
        base = p.col("BaseColor")                      # MI_COM_Emissive and its colours: no texture, no mask, the flat colour is the light
        if strength > 0.0 and colour_peak(base) > 0.0 and not is_placeholder_colour(base) and not (p.sw("Use BaseColor Map", "", False) and p.tex("BaseColor Map")):
            peak = colour_peak(base)
            log("emission: BaseColor over the whole surface, strength %.2f" % (strength * peak))
            return scaled_colour(base, peak), strength * peak
        if p.sw("Use Emissive", "", False) and strength > 0.0 and L.albedo is not None and p.sw("Use BaseColor Map", "", False) and p.tex("BaseColor Map"):
            if p.sw("Use BaseColor Alpha as Emissive", "", False):       # only where the texture's alpha says so
                if L.alpha is None:
                    return None
                log("emission: base colour through its alpha, strength %.2f" % strength)
                return g.mix_color((0.0, 0.0, 0.0, 1.0), L.albedo, L.alpha), strength
            log("emission: the base colour texture, strength %.2f" % strength)  # posters and signs: the picture is the light
            return L.albedo, strength
    built = structure_emission(p, g)
    if built:
        return built
    if p.sw("UseEmmisiveMask", "", False):                        # M_Structures
        ref = p.tex("EmmisiveColorTexture")
        colour = p.col("Emmisive Color")
        strength = p.num("EmissiveValue", "", 0.0) * colour_peak(colour)
        tex = g.image(ref, g.uv(0), color=True, role="Emissive mask") if ref and strength > 0.0 else None
        if tex:
            log("emission: EmmisiveColorTexture %s, strength %.2f" % (os.path.basename(ref).split(".")[0], strength))
            return g.mix_color(tex[0], scaled_colour(colour, colour_peak(colour)), 1.0, blend="MULTIPLY"), strength
    if p.sw("UseEmissiveTile", "", False):
        ref = p.tex("Emissive_Tileable_Texture")
        tiling = (p.num("Emissive_Tile_X", "", 1.0) * p.num("Emissive_Tile", "", 1.0), p.num("Emissive_Tile_Y", "", 1.0) * p.num("Emissive_Tile", "", 1.0))
        strength = p.num("Emissive Intensity", "", 1.0)
        tex = g.image(ref, g.uv(0, tiling), color=True, role="Emissive") if ref and strength > 0.0 else None
        if tex:
            log("emission: tiled map %s, strength %.2f" % (os.path.basename(ref).split(".")[0], strength))
            return tex[0], strength
    if is_screen(p):
        tex = g.image(p.tex("Overlay"), g.uv(0, (p.num("Overlay_Tiling_X", "", 1.0), p.num("Overlay_Tiling_Y", "", 1.0))), color=True, role="Screen picture")
        if tex:
            strength = max(p.num("ScreenGlowIntensity", "", 1.0), p.num("ScreenEmissiveIntensity", "", 0.0)) * p.num("OverlayVisibility", "", 1.0)
            log("emission: screen picture %s, strength %.3g" % (os.path.basename(p.tex("Overlay")).split(".")[0], strength))
            return tex[0], strength
    colour_map = p.tex("ColorMap")
    if colour_map and p.num("EmissiveIntensity", "", 0.0) > 0.0 and L.albedo is not None:
        # The Alchemist room's painted star ceiling (M_CHU_POM_AlchemistCeiling): the colour map glows at EmissiveIntensity
        strength = p.num("EmissiveIntensity", "", 0.0)
        log("emission: the colour map at EmissiveIntensity %.3g" % strength)
        return L.albedo, strength
    mask_colour, mask_ref = p.col("EmissiveColor Mask"), p.tex("EmissiveColor Mask")
    if mask_ref and colour_peak(mask_colour) > 0.0:
        # the effect materials (MI_Halloween2025_TendrilsAtlas): a colour glowing through a grey mask, at Emissive Power
        tex = g.image(mask_ref, g.uv(0), color=False, role="Emissive mask")
        if tex:
            peak = colour_peak(mask_colour)
            strength = p.num("Emissive Power", "", 1.0) * peak
            log("emission: EmissiveColor Mask through %s, strength %.2f" % (os.path.basename(mask_ref).split(".")[0], strength))
            return g.mix_color((0.0, 0.0, 0.0, 1.0), scaled_colour(mask_colour, peak), g.bw(tex[0])), strength
    if p.col("Emissive_Color") and "Emissive_Intensity" in p.s:   # the flicker material.  The crows and ground dirt have the colour alone
        strength = p.num("Emissive_Intensity", "", 1.0)
        log("emission: Emissive_Color, strength %.2f" % strength)
        return _rgba(p.col("Emissive_Color")), strength
    return None


def add_emission(p, g, bsdf, L):
    source = emission_source(p, g, L) or L.emission
    if p.unlit:
        # nothing lights it: its own colour is all there is.  Black base and no highlight, so the scene's lights add nothing.
        if source is None and L.albedo is not None:
            source = (L.albedo, 1.0)
            log("unlit: the base colour shown as it is")
        for sock in (bsdf.inputs["Base Color"], bsdf.inputs["Specular IOR Level"]):
            for link in list(sock.links):
                g.links.remove(link)
        g.put(bsdf.inputs["Base Color"], (0.0, 0.0, 0.0, 1.0))
        g.put(bsdf.inputs["Specular IOR Level"], 0.0)
    if source is None:
        return
    colour, strength = source
    g.put(bsdf.inputs["Emission Color"], colour)
    g.put(bsdf.inputs["Emission Strength"], strength * OPTIONS["emissive"])
    applied("Emissive")


def is_emissive_default(c):
    """The master's Emissive Color (FFEA00).  Every emissive slot of a material holds it, the unused ones included."""
    return abs(c.get("R", 0) - 1.0) < 1e-3 and abs(c.get("G", 0) - 0.821232) < 1e-3 and c.get("B", 0) < 1e-3


def add_normal_overlay(p, g, L):
    """The object's own baked normal map, over the tiled ones: the face and folds on a snowman, the carving on a chair.  Without it the mesh only has its tiling."""
    ref = p.tex("Detail Normal Map") if p.sw("Use Detail Normal Map overlay", "", False) else None
    if not ref:
        return
    master = p.num("Detail normal - UV Tiling Master", "", 1.0)
    tiling = (master * p.num("Detail normal - U Tiling", "", 1.0), master * p.num("Detail normal - V Tiling", "", 1.0))
    tex = g.image(ref, g.uv(p.num("Detail normal - UV Channel", "", 0.0), tiling), color=False, role="Baked normal")
    if not tex:
        return
    baked = decode_normal(g, tex[0])
    strength = p.num("Detail Normal Map overlay - Intensity", "", 1.0)
    if L.normal is None:
        L.normal = baked
    else:
        L.normal = g.mix_color(L.normal, baked, min(max(strength, 0.0), 1.0), blend="OVERLAY")
    if strength > 1.0 + 1e-3:
        L.normal_gain = max(L.normal_gain, strength)
    log("normal: baked map %s overlaid (intensity %.2f)" % (os.path.basename(ref).split(".")[0], strength))


def declares_atlas(raw):
    """
    The older list exports leave the static switches out (MI_LM_Posters_03), but they only hold the parameters the material really uses, so an Atlas Index among
    those means the atlas is on.  The newer exports list every parameter, so the index proves nothing there.
    """
    first = raw[0] if isinstance(raw, list) and raw and isinstance(raw[0], dict) else {}
    values = (first.get("Properties") or {}).get("ScalarParameterValues") or []
    return any(((v.get("ParameterInfo") or {}).get("Name") or "") in ("Atlas Index", "AtlasIndex") for v in values if isinstance(v, dict))


def build_surface(p, g, material, fam, raw=None):
    tree = g.tree
    tree.nodes.clear()
    if (p.sw("Use UV Atlas", "", False) and p.sw("Atlas Use Custom Data", "", False)) or declares_atlas(raw):
        # the grid is not in the export: read off the sheets, 3 x 2 posters and 2 x 2 toy blocks
        g.atlas_cells = (3.0, 2.0) if "poster" in os.path.basename(p.tex("BaseColor Map") or "").lower() else (2.0, 2.0)
    g.section = "Shader"
    out = g.new("ShaderNodeOutputMaterial", label="Material Output")
    bsdf = g.new("ShaderNodeBsdfPrincipled", label="Principled BSDF")
    g.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

    if fam == "blend":
        L = build_blendmap(p, g)
    elif fam == "simple":
        L = build_simple(p, g)
    elif fam == "splat":
        L = build_splat(p, g)
    elif fam == "water":
        L = build_water(p, g)
    else:
        L = build_generic(p, g)

    g.section = "Finish"
    add_normal_overlay(p, g, L)
    if L.albedo is not None:
        if L.ao is not None:                      # Blender's Principled BSDF has no AO input: darken the albedo by it, at reduced strength
            L.albedo = g.mix_color(L.albedo, g.combine(L.ao, L.ao, L.ao), 0.6, blend="MULTIPLY")
        g.put(bsdf.inputs["Base Color"], L.albedo)
    if L.normal is not None:
        nm = g.new("ShaderNodeNormalMap")
        if g.uv_names:
            nm.uv_map = g.uv_names[0]
        g.put(nm.inputs["Color"], L.normal)
        if L.normal_gain != 1.0:
            nm.inputs["Strength"].default_value = L.normal_gain
            log("normal strength %.2f" % L.normal_gain)
        g.links.new(nm.outputs["Normal"], bsdf.inputs["Normal"])
    spec = specular_level(p, fam)
    if spec is not None:
        g.put(bsdf.inputs["Specular IOR Level"], spec)
        log("specular level %.2f" % spec)
    g.put(bsdf.inputs["Roughness"], L.rough if L.rough is not None else 0.5)
    g.put(bsdf.inputs["Metallic"], L.metal if L.metal is not None else 0.0)

    # ---- alpha: only for masked / translucent materials, from the source the master's switches name
    g.section = "Alpha"
    if p.blend_mode in (1, 2):
        alpha = None
        if is_silhouette(p):
            ot = g.image(p.tex("Opacity Mask"), g.uv(0), color=False, role="Silhouette")
            if ot:
                alpha = g.math("SUBTRACT", 1.0, g.bw(ot[0]), label="dark shape = solid")
                for sock in (bsdf.inputs["Base Color"],):
                    for link in list(sock.links):
                        g.links.remove(link)
                g.put(bsdf.inputs["Base Color"], (0.0, 0.0, 0.0, 1.0))
                log("alpha: billboard silhouette, the dark shape of %s (drawn black)" % os.path.basename(p.tex("Opacity Mask")).split(".")[0])
        if alpha is None and fam in ("generic", "splat"):
            key, oref = first_texture(p, OPACITY_KEYS)
            if oref:
                ot = g.image(oref, g.uv(0), color=False)
                if ot:
                    alpha = g.bw(ot[0])
                    log("alpha: %s" % key)
        if alpha is None and p.sw("Use BaseColor Map as Opacity", "          .", False) and getattr(L, "alpha", None) is not None:
            alpha = L.alpha
            log("alpha: base colour alpha")
        oref = p.tex("Opacity Map", "          .") if p.sw("Use Opacity Map", "          .", False) else None
        if alpha is None and oref:
            ot = g.image(oref, g.uv(p.num("UV Channel", "          .", 0.0)), color=False)
            if ot:
                alpha = g.bw(ot[0])
                log("alpha: opacity map")
        oref = p.tex("Opacity Map") if p.sw("Use Opacity Map", "", False) else None
        if alpha is None and oref:
            ot = g.image(oref, g.uv(p.num("UV Channel Opacity Map", "", 0.0)), color=False)
            if ot:
                alpha = g.bw(ot[0])
                log("alpha: Opacity Map")
        if alpha is None and p.blend_mode == 2 and L.placeholder and L.normal is not None:
            # A normal-only decal (MIM_Decal_Normal: MI_COM_Entity_Decal_Waves_01): in the game it only bends the lighting of the surface under it.
            # Blender cannot do that from a separate mesh, so it is clear where the map is flat and a dark gloss where it bends: the ripples show,
            # not a grey sheet.
            _r, _g, flatness = g.separate(L.normal)
            alpha = g.math("MULTIPLY", g.math("SUBTRACT", 1.0, flatness), 4.0, clamp=True, label="normal bend")
            for sock in (bsdf.inputs["Base Color"], bsdf.inputs["Roughness"], bsdf.inputs["Metallic"]):
                for link in list(sock.links):
                    g.links.remove(link)
            g.put(bsdf.inputs["Base Color"], (0.02, 0.02, 0.02, 1.0))
            g.put(bsdf.inputs["Roughness"], 0.15)
            log("alpha: a normal-only decal: clear, the ripples where its normal map bends show as dark gloss")
        if alpha is None and getattr(L, "alpha", None) is not None:
            alpha = L.alpha
            log("alpha: base colour alpha (fallback)")
        if alpha is not None:
            if p.blend_mode == 1:       # a masked material: Blender has no clip mode any more, so the cut-out is made in the graph
                alpha = g.math("GREATER_THAN", alpha, p.clip, label="Opacity mask clip")
            g.put(bsdf.inputs["Alpha"], alpha)
        material.surface_render_method = "DITHERED" if p.blend_mode == 1 else "BLENDED"
    else:
        material.surface_render_method = "DITHERED"
    material.use_backface_culling = not p.two_sided

    # ---- emission
    g.section = "Emission"
    add_emission(p, g, bsdf, L)
    arrange(g)


# ---------------------------------------------------------------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------------------------------------------------------------

def streamed_uvs(first, base_path):
    """
    {texture name (lower case): UV set} from the material's TextureStreamingData: the UV set the cooked material actually samples each texture
    with.  The Models export of a material leaves it out, so the Properties export of the same material is read for it.
    """
    def read(item):
        props = item.get("Properties") if isinstance(item, dict) else None
        rows = props.get("TextureStreamingData") if isinstance(props, dict) else None
        out = {}
        for r in rows or []:
            if isinstance(r, dict) and r.get("TextureName") and isinstance(r.get("UVChannelIndex"), int):
                out.setdefault(str(r["TextureName"]).lower(), r["UVChannelIndex"])
        return out
    found = read(first)
    if found or not CURRENT[0]:
        return found
    same = dbd_matio.game_path(CURRENT[1]) if CURRENT[1] else None
    for path in dbd_matio.file_index(base_path, (".json",)).get(CURRENT[0]):
        if same and dbd_matio.game_path(path) != same:
            continue                                   # another asset of the same name (see dbd_matio.pick_for_mesh)
        try:
            raw = dbd_matio.read_json(path)
        except Exception:
            continue
        found = read(raw[0] if isinstance(raw, list) and raw else raw)
        if found:
            return found
    return {}


def build_material(material_name, json_path, base_path, bpy_module, uv_names=()):
    """Build one material from its JSON.  Returns the decision lines."""
    del LOG[:]
    CURRENT[0] = material_name
    CURRENT[1] = json_path
    raw = dbd_matio.read_json(json_path)
    legacy = dbd_matio.legacy_material(raw)
    first = raw[0] if isinstance(raw, list) and raw and isinstance(raw[0], dict) else raw
    own = legacy
    legacy, top_master, found, missing = dbd_matio.inherit_parents(raw, legacy, base_path, dbd_matio.find_material_json)
    if found:
        # a texture the material itself sets is meant to be used: where only a parent switched its map off, switch it on again
        for slot, ref in own["Textures"].items():
            switch = "Use " + slot
            if ref and not PLACEHOLDER.search(str(ref).lower()) and switch not in own["Switches"] and not legacy["Switches"].get(switch):
                legacy["Switches"][switch] = True
    p = Params(legacy, first)
    p.streamed = streamed_uvs(first, base_path)
    if found:
        p.own_colours = {_norm(k) for k in own["Colors"]}
    if p.master is None and top_master:
        p.master = top_master
    fam = family(p)
    log("master=%s family=%s blend=%s two_sided=%s" % (p.master or "(none recorded)", fam, p.blend_mode, p.two_sided))
    if found:
        log("delta instance: parameters inherited from %s" % " -> ".join(found))
    if missing:
        log("delta instance: parent %s is not exported, so the master's defaults are assumed" % ", ".join(missing))
    material = bpy_module.data.materials.get(material_name) or bpy_module.data.materials.new(material_name)
    g = Graph(material.node_tree, base_path, bpy_module, list(uv_names))
    if not build_additive_glow(p, g, material):
        build_surface(p, g, material, fam, raw)
    return list(LOG)


BLEND_ADDITIVE = 3


def build_additive_glow(p, g, material):
    """
    An additive, unlit material with no textures of its own or its master's (Quiche's fake light beams, M_ClubSplitLight): its light is added to what
    is behind it, in its tint at its intensity, shaped by the mesh's vertex colour - the beam meshes carry the rays in RGB and the fade along the
    beam in alpha.  Blender: Transparent + Emission.  Returns False for anything else.
    """
    if p.blend_mode != BLEND_ADDITIVE or not p.unlit or any(p.tex(k) for k in p.t) or master_textures(p, g.base):
        return False
    g.tree.nodes.clear()
    g.section = "Shader"
    colours = [c for c in p.c.values() if isinstance(c, dict) and colour_peak(c) > 0.0]
    tint = _rgba(colours[0]) if len(colours) == 1 else (1.0, 1.0, 1.0, 1.0)
    intensities = [float(v) for k, v in p.s.items() if "intensity" in k.lower() and isinstance(v, (int, float))]
    strength = intensities[0] if len(intensities) == 1 else 1.0
    vc = g.new("ShaderNodeVertexColor", label="Vertex paint: rays (RGB), fade (alpha)")
    shape = g.mix_color(vc.outputs[0], g.combine(vc.outputs[1], vc.outputs[1], vc.outputs[1]), 1.0, blend="MULTIPLY")
    colour = g.mix_color(shape, tint, 1.0, blend="MULTIPLY", label="Tint")
    emit = g.new("ShaderNodeEmission", label="Glow")
    g.put(emit.inputs["Color"], colour)
    g.put(emit.inputs["Strength"], strength * OPTIONS["emissive"])
    clear = g.new("ShaderNodeBsdfTransparent", label="Behind it")
    add = g.new("ShaderNodeAddShader", label="Added on top")
    g.links.new(clear.outputs[0], add.inputs[0])
    g.links.new(emit.outputs[0], add.inputs[1])
    out = g.new("ShaderNodeOutputMaterial", label="Material Output")
    g.links.new(add.outputs[0], out.inputs["Surface"])
    material.surface_render_method = "BLENDED"
    material.use_backface_culling = False
    for attr in ("use_transparent_shadow",):
        if hasattr(material, attr):
            setattr(material, attr, True)
    if hasattr(material, "shadow_method"):
        material.shadow_method = "NONE"
    applied("Emissive")
    log("additive glow: tint x %s x vertex colour, added to what is behind (no textures: the master draws it procedurally)" % ("%.3g" % strength))
    arrange(g)
    return True


# Maya's default material: on helper geometry such as the cloth-physics attachments of outfits, never meant to be seen
INVISIBLE_MATERIAL = re.compile(r"(^|_)(bbox)?lambert\d*$", re.I)


def make_invisible(bpy_module, name):
    """A material that shows nothing, in render and material preview alike."""
    material = bpy_module.data.materials.get(name) or bpy_module.data.materials.new(name)
    material.use_nodes = True
    nodes = material.node_tree.nodes
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    clear = nodes.new("ShaderNodeBsdfTransparent")
    material.node_tree.links.new(clear.outputs[0], out.inputs["Surface"])
    clear.location = (-200, 0)
    material.surface_render_method = "DITHERED"
    material.diffuse_color = (1.0, 1.0, 1.0, 0.0)
    material["dbd_invisible"] = True
    return material


def with_instance_sources(objects):
    """The selection plus the hidden source object of every Tile Builder instancer in it: the instances show the source's materials."""
    out = list(objects)
    seen = set(o.name for o in out)
    for obj in objects:
        source = obj.get("dbd_instance_source") if hasattr(obj, "get") else None
        if source is not None and getattr(source, "type", "") == "MESH" and source.name not in seen:
            out.append(source)
            seen.add(source.name)
    return out


def main(context, base_path, bpy_module=None):
    """Build the materials of the selected objects.  Returns the run counts plus 'report': one line group per material decided, then the summary."""
    import bpy
    run = dbd_matio.RunLog()
    report = []

    def say(line):
        print(line)
        report.append(line)

    APPLIED.clear()

    def summary():
        result = run.summary(printer=say)
        if result.get("no_json"):
            for line in dbd_matio.search_report(base_path):
                say(line)
        result["applied"] = {k: len(v) for k, v in APPLIED.items()}
        if APPLIED:
            say("Look settings used on: " + ", ".join("%s %d" % (k, len(v)) for k, v in sorted(APPLIED.items())))
        else:
            say("Look settings: none of the selected materials use them (they only affect materials with vertex-painted layers, height blends, "
                "grime layers, leaves or moss)")
        result["report"] = report
        return result

    selected = with_instance_sources(bpy.context.selected_objects)
    if not selected:
        say("No objects selected.")
        return summary()
    done = set()
    paths = {}
    fell_back = set()

    def locate(name, mesh=None):
        if (name, mesh) not in paths:
            paths[(name, mesh)] = dbd_matio.find_material_json(name, base_path, log=lambda *a: None, mesh_name=mesh)
        return paths[(name, mesh)]

    # One earlier version gave meshes with no vertex colour an all-white layer named 'Col', which lit the whole of the wheel lamps.  It stays in saved
    # files: take it off again.  The importers name their layers PSKVTXCOL_0, so a white 'Col' is only ever that one.
    cleaned = set()
    for obj in selected:
        me = obj.data if getattr(obj, "type", "") == "MESH" else None
        attr = me.color_attributes.get("Col") if me is not None and me.name not in cleaned else None
        if attr is not None and len(attr.data):
            vals = [0.0] * (4 * len(attr.data))
            attr.data.foreach_get("color", vals)
            if min(vals) >= 0.999:
                me.color_attributes.remove(attr)
                cleaned.add(me.name)
    if cleaned:
        say("Removed the white colour layer an earlier version added (%d meshes): %s" % (len(cleaned), ", ".join(sorted(cleaned)[:8])))
    for obj in selected:
        uv_names = [l.name for l in obj.data.uv_layers] if getattr(obj, "type", "") == "MESH" and obj.data else []
        mesh = re.sub(r"\.\d+$", "", obj.data.name) if getattr(obj, "data", None) else obj.name
        for slot in obj.material_slots:
            name = slot.material.name if slot.material else None
            if name:
                run.used_on(name, mesh)
            if name and slot.link == "OBJECT" and not locate(name, mesh):      # an override that is not in the export would be blank: the mesh's own material beats that
                fell_back.add(name)
                slot.link = "DATA"
                name = slot.material.name if slot.material else None
                if name:
                    run.used_on(name, mesh)
            if not name or name in done:
                continue
            done.add(name)
            if INVISIBLE_MATERIAL.search(name):
                make_invisible(bpy, name)
                run.ok(name)
                say("-- %s" % name)
                say("     invisible: a Lambert material marks helper geometry the game never shows")
                continue
            path = locate(name, mesh)
            if not path:
                run.no_json_for(name)
                continue
            try:
                lines = build_material(name, path, base_path, bpy, uv_names)
                run.ok(name)
                say("-- %s" % name)
                for ln in lines:
                    say("     " + ln)
                    if ln.startswith("texture file not found:"):
                        run.texture_missing(name, ln.split(": ", 1)[1])
            except Exception as exc:
                run.error(name, exc)
                say("Error building %s: %s: %s" % (name, type(exc).__name__, exc))
                traceback.print_exc()
    # A material is built once, from the first selected mesh that has it, and names its UV sets after that mesh's.  A mesh sharing it with fewer UV
    # sets (SM_CHU_Rampart_02 has one, SM_CHU_Rampart_01 two) then reads a set it does not have, which Blender gives as zeros: the texture smears.
    # Give such meshes the missing sets as copies of their first, the same stand-in the material uses when it is built from that mesh alone.
    padded = set()
    for obj in selected:
        me = obj.data if getattr(obj, "type", "") == "MESH" else None
        if me is None or me.name in padded or not len(me.uv_layers):
            continue
        wanted = set()
        for slot in obj.material_slots:
            mat = slot.material
            if mat is not None and mat.use_nodes and mat.node_tree:
                wanted |= {n.uv_map for n in mat.node_tree.nodes if n.bl_idname == "ShaderNodeUVMap" and n.uv_map}
        missing = sorted(wanted - {layer.name for layer in me.uv_layers})
        if not missing:
            continue
        first = [0.0] * (2 * len(me.uv_layers[0].data))
        me.uv_layers[len(me.uv_layers) - 1].data.foreach_get("uv", first)     # the game reads a missing set as the mesh's last one
        for name in missing:
            if len(me.uv_layers) >= 8:            # Blender's limit
                break
            layer = me.uv_layers.new(name=name, do_init=False)
            layer.data.foreach_set("uv", first)
        me.uv_layers.active_index = 0
        me.uv_layers[0].active_render = True
        padded.add(me.name)
    if padded:
        say("Meshes given a copy of their last UV set for a set their shared materials read (%d): %s" % (len(padded), ", ".join(sorted(padded)[:8])))
    if fell_back:
        say("Not in the export, so these objects kept the mesh's own material (%d). Export them, then rebuild the map:" % len(fell_back))
        for name in sorted(fell_back):
            say("     " + name + run.where(name))
    return summary()
