bl_info = {
    "name": "OhPorty's DbD Blueprint/Tile Builder",
    "author": "OhPorty",
    "version": (1, 0, 8),
    "blender": (5, 0, 0),
    "location": "3D Viewport > Sidebar (N) > Porty's BPs",
    "description": "Rebuilds Dead by Daylight tiles, blueprints, full maps and uMaps from FModel exports.",
    "category": "Object",
}

import bpy
from bpy_extras.io_utils import ExportHelper
import importlib
import json
import os
import re
import sys
import textwrap
import traceback

# Define Property Group for file paths
class JSONImporterGUIProperties(bpy.types.PropertyGroup):
    json_file_path_1: bpy.props.StringProperty(
        name="Tile JSON",
        description="Not shown on the panel: only the retired child-placing operator reads this",
        default="",
        maxlen=1024,
        subtype='FILE_PATH'
    )
    json_file_path_2: bpy.props.StringProperty(
        name="Blueprint JSON",
        description="A tile or blueprint export to build on its own",
        default="",
        maxlen=1024,
        subtype='FILE_PATH'
    )
    umap_sublevels: bpy.props.BoolProperty(
        name="Include Sub-Levels",
        description="Also build the levels this one streams in. Lobby.json, for one, keeps its scenery in sub-levels",
        default=True
    )
    json_file_path_3: bpy.props.StringProperty(
        name="uMap JSON",
        description="A .umap export to import",
        default="",
        maxlen=1024,
        subtype='FILE_PATH'
    )
    json_file_path_5: bpy.props.StringProperty(
        name="FModel Scene",
        description="A map, tile or level FModel exported as a USD scene (.usda): right-click it in FModel, World, with Mesh Format set to Universal Scene Description",
        default="",
        maxlen=1024,
        subtype='FILE_PATH'
    )
    json_file_path_4: bpy.props.StringProperty(
        name="Tiled Map JSON",
        description="The map's Paper2D tile map export, e.g. TiledMaps/Completed/16-Wales/Wal_Level_01.json",
        default="",
        maxlen=1024,
        subtype='FILE_PATH'
    )
    map_seed: bpy.props.IntProperty(
        name="Map Seed",
        description="Picks the map's tiles and where its generators, totems, pallets and chests go. The same seed always builds the same map",
        default=1,
        min=0
    )
    model_base_path: bpy.props.StringProperty(
        name="Exports Folder",
        description="Your FModel export folder. Meshes and any blueprints a build needs are found under it",
        default="",
        maxlen=1024,
        subtype='DIR_PATH'
    )
    auto_build_children: bpy.props.BoolProperty(
        name="Build missing blueprints automatically",
        description="Build any blueprint a tile needs that isn't in the scene yet. Off = those spots stay empty",
        default=True
    )
    spawn_scene_blueprints: bpy.props.BoolProperty(
        name="Rooms, basements and set pieces",
        description="Also build what the game spawns at runtime: basements, rooms, store and hall setups, rides, exit gates",
        default=True
    )
    build_lockers: bpy.props.BoolProperty(
        name="Lockers", description="Build lockers", default=True)
    build_vaults: bpy.props.BoolProperty(
        name="Vaults", description="Mark every window vault with its collision box (the vault itself has no mesh)", default=True)
    build_generators: bpy.props.BoolProperty(
        name="Generators", description="Build generators", default=True)
    build_pallets: bpy.props.BoolProperty(
        name="Pallets", description="Build pallets", default=True)
    build_totems: bpy.props.BoolProperty(
        name="Totems", description="Build totems", default=True)
    build_hooks: bpy.props.BoolProperty(
        name="Hooks", description="Build hooks at every hook spot, the basement's included, in the realm's own style where known", default=True)
    build_hatch: bpy.props.BoolProperty(
        name="Hatch", description="Build the hatch", default=True)
    build_chests: bpy.props.BoolProperty(
        name="Chests", description="Build chests", default=True)
    count_chests: bpy.props.IntProperty(
        name="Chests", description="Used only when the export has no game data. 0 = every spawn point", default=3, min=0)
    count_generators: bpy.props.IntProperty(
        name="Generators", description="Used only when the export has no game data. 0 = every spawn point", default=7, min=0)
    count_totems: bpy.props.IntProperty(
        name="Totems", description="Used only when the export has no game data. 0 = every spawn point", default=5, min=0)
    count_pallets: bpy.props.IntProperty(
        name="Pallets", description="Used only when the export has no game data. 0 = every spawn point",
        default=14, min=0)
    count_lockers: bpy.props.IntProperty(
        name="Lockers", description="Used only when the export has no game data. 0 = every spawn point", default=0, min=0)
    build_lights: bpy.props.BoolProperty(
        name="Lights", description="Build the point / spot / rect lights with their exported colour, intensity, radius and cone angles", default=True)
    build_generator_lights: bpy.props.BoolProperty(
        name="Generator lights",
        description="Build the spot lights just above each generator (its flood light). Rarely wanted, so off by default",
        default=False)
    build_lights_off: bpy.props.BoolProperty(
        name="Lights that are off", description=("Also build the lights that are off in the export (hidden, not affecting the world - fog and "
                                                 "translucency only - or zero intensity), disabled and tagged with the reason on the object"),
        default=True)
    light_round_as_disc: bpy.props.BoolProperty(
        name="Round lights as discs",
        description=("Build each round point light as two flat disc area lights (facing down and up) instead of a point light. A disc cannot "
                     "poke through the surface the lamp sits on, but it only lights two ways, where a point light shines every way as in the game"),
        default=False)
    light_no_volume_names: bpy.props.StringProperty(
        name="No fog scatter for lights named",
        description=("Comma-separated: lights whose name contains any of these (case-insensitive) do not scatter in volumes: Volume Scatter ray "
                     "visibility and Volume Factor are switched off. 'fill' = the fill lights"),
        default="fill")
    light_static_no_volume: bpy.props.BoolProperty(
        name="Static lights skip fog",
        description=("Lights that Unreal marks Static (baked) do not scatter in volumes: their Volume Scatter ray visibility and Volume Factor are "
                     "switched off. Lights with no mobility written are not treated as static"),
        default=True)
    light_spot_size: bpy.props.FloatProperty(
        name="Spot light size (m)",
        description=("Size of every spot light's source. 0 = none: just the sharp-tipped cone, no sphere at its tip to clip into the surface; the "
                     "beam's Blend still softens the cone. A larger size softens the shadows but is moved clear of the surface"),
        default=0.0, min=0.0, soft_max=0.3, unit="LENGTH")
    light_min_radius: bpy.props.FloatProperty(
        name="Light size min (m)",
        description=("Smallest size a point / spot light gets. The size is what softens the shadows in Blender: a tiny light casts razor-sharp "
                     "shadows (42% of the exported lights have no source radius). Larger sizes are kept up to 0.3 m"),
        default=0.1, min=0.0, soft_max=0.3, unit="LENGTH")
    light_strength: bpy.props.FloatProperty(
        name="Light strength x",
        description=("Multiplier on the converted intensity.  615 (with Blender's Exposure at 1, which a build sets) matches the game: every map "
                     "pins its camera exposure at brightness 0.1.  Halve it for each stop of Exposure you add.  1 = the exported values in "
                     "Blender watts.  The original Unreal values stay on each light as custom properties"),
        default=615.0, min=0.0, soft_max=10000.0)
    skip_name_patterns: bpy.props.StringProperty(
        name="Skip components named",
        description="Comma-separated: components whose name or mesh name contains any of these are not built",
        default="DetectZone,DetectionZone")
    hide_hidden_in_game: bpy.props.BoolProperty(
        name="Hide what's hidden in game",
        description="Components the game keeps invisible are imported, but hidden in the viewport and render",
        default=True
    )
    use_instancing: bpy.props.BoolProperty(
        name="Use instancing",
        description=("Grass, plants and other meshes the game repeats as instances become one object per set, which is faster to build and work "
                     "with. Untick to build every instance as its own object, as older versions did"),
        default=True
    )
    export_children: bpy.props.BoolProperty(
        name="Include everything under selected",
        description="Also export every object under the selected ones: select a build's top empty to export the whole build",
        default=True
    )

# Shared helper modules; reloaded with the scripts so edits take effect without restarting Blender
HELPER_MODULES = ("dbd_core", "psk_reader", "uemodel_reader", "dbd_map", "dbd_procgen", "dbd_umap", "dbd_blender", "dbd_usd", "dbd_export")


def reload_helpers():
    for name in HELPER_MODULES:
        module = sys.modules.get("%s.%s" % (__package__, name))
        if module is not None:
            importlib.reload(module)


def run_script(operator, module_name, imported_flag_name):
    """Import/reload a script module and run its main(context), reporting real errors (not just a missing main)."""
    try:
        reload_helpers()
        module = importlib.import_module("." + module_name, __package__)
        if globals()[imported_flag_name]:
            importlib.reload(module)
        globals()[imported_flag_name] = True
    except ModuleNotFoundError as exc:
        operator.report({'ERROR'}, "%s.py (or a helper module) not found in the addon folder: %s" % (module_name, exc))
        return {'CANCELLED'}
    if not hasattr(module, "main"):
        operator.report({'ERROR'}, "%s.py must define a 'main(context)' function" % module_name)
        return {'CANCELLED'}
    try:
        result = module.main(bpy.context)
    except Exception as exc:
        traceback.print_exc()
        operator.report({'ERROR'}, "%s failed: %s" % (operator.bl_label, exc))
        return {'CANCELLED'}
    if isinstance(result, str) and result:          # a script's warning: shown in Blender, not only in the System Console
        operator.report({'WARNING'}, result)
        return {'FINISHED'}
    operator.report({'INFO'}, "%s finished" % operator.bl_label)
    return {'FINISHED'}


# Class-level flags to track imports
script1_imported = False
script2_imported = False
script3_imported = False
script4_imported = False
script5_imported = False

_SEED_STATE = [0]


def unreal_new_seed():
    """
    A fresh map seed from Unreal's own FRandomStream math: Seed = Seed * 196314165 + 907633515 (uint32), the value taken from the
    top 15 bits - the 0..32767 range the game's stored seeds use (e.g. SharedTileRandomizer 690 / 4532 / 22059).
    """
    import time
    if not _SEED_STATE[0]:
        _SEED_STATE[0] = time.time_ns() & 0xFFFFFFFF
    _SEED_STATE[0] = (_SEED_STATE[0] * 196314165 + 907633515) & 0xFFFFFFFF
    return _SEED_STATE[0] >> 17


class OBJECT_OT_NewMapSeed(bpy.types.Operator):
    bl_idname = "object.new_map_seed"
    bl_label = "New Seed"
    bl_description = "Roll a new seed with Unreal's random-stream math. Press Build Full Map to see it"

    def execute(self, context):
        context.scene.json_importer_gui_props.map_seed = unreal_new_seed()
        return {'FINISHED'}


# Operator for running Script 1
class OBJECT_OT_RunScript1(bpy.types.Operator):
    bl_idname = "object.run_script1"
    bl_label = "Run Script 1"
    bl_description = "Place every child blueprint of the tile (one instanced copy per ChildActorComponent)"
    bl_options = {'UNDO'}

    def execute(self, context):
        return run_script(self, "Script1", "script1_imported")

# Operator for running Script 2
class OBJECT_OT_RunScript2(bpy.types.Operator):
    bl_idname = "object.run_script2"
    bl_label = "Build Blueprint"
    bl_description = "Build one tile or blueprint on its own. Every spawn point is shown: the counts only apply to a full map"
    bl_options = {'UNDO'}

    def execute(self, context):
        return run_script(self, "Script2", "script2_imported")

# Operator for running Script 3
class OBJECT_OT_RunScript3(bpy.types.Operator):
    bl_idname = "object.run_script3"
    bl_label = "Import uMap"
    bl_description = "Build the level, replacing any earlier build of it"
    bl_options = {'UNDO'}

    def execute(self, context):
        return run_script(self, "Script3", "script3_imported")

# Operator for running Script 4 (whole map from a Paper2D tile map)
class OBJECT_OT_RunScript5(bpy.types.Operator):
    bl_idname = "object.run_script5"
    bl_label = "Import FModel Scene"
    bl_description = "Place a map, tile or level exactly as FModel exported it, with the meshes from your normal export, replacing any earlier import of it"
    bl_options = {'UNDO'}

    def execute(self, context):
        return run_script(self, "Script5", "script5_imported")


class OBJECT_OT_RunScript4(bpy.types.Operator):
    bl_idname = "object.run_script4"
    bl_label = "Build Full Map"
    bl_description = "Build the whole map for this seed, replacing any earlier build of it"
    bl_options = {'UNDO'}

    def execute(self, context):
        return run_script(self, "Script4", "script4_imported")

# Panels
HELP = (
    ("Start here", (
        "This add-on rebuilds Dead by Daylight maps and tiles from files you export with FModel.",
        "Do steps 1 to 3 in order. You only need to export once.",
    )),
    ("1. Set up FModel", (
        "Open FModel's Settings.",
        "Turn on Keep Directory Structure.",
        "Turn on Serialize Script Bytecode.",
        "Mesh Format: ActorX (psk) or UEFormat (uemodel) both work.",
        "Note the Output Directory. You'll pick it in step 3.",
    )),
    ("2. Export", (
        "In FModel, right-click each folder below and choose Export Folder.",
        "Content/Blueprints: Properties (.json)",
        "Content/Data: Properties (.json)",
        "Content/ProceduralLevelGeneration: Properties (.json)",
        "Content/Meshes: Models",
        "Plugins/Realms: Models (newer realms, like Liminal, are only here)",
        "Last, the blueprints kept with the meshes and realms: press Ctrl+Shift+F, search for BP_, press Ctrl+A to select them all, and export them as Properties (.json).",
    )),
    ("3. Build", (
        "Exports Folder: pick FModel's Output Directory.",
        "A whole map: in Full Map, pick a file in ProceduralLevelGeneration/TiledMaps/Completed and press Build Full Map.",
        "The Seed picks the layout. The same seed always gives the same map.",
        "One tile: in Single Tile, pick a file in Content/Blueprints/Tiles and press Build Blueprint.",
        "Big maps take a while. Blender looks frozen until it's done.",
    )),
    ("Something is missing?", (
        "Open Window > Toggle System Console, then build again.",
        "It lists the files it couldn't find. Export those and build again.",
        "Check the boxes in Gameplay Objects.",
        "If there's a red box at the top of this panel, remove the other copy and restart Blender.",
    )),
    ("Hiding parts of a build", (
        "Each build gets its own collection in the Outliner.",
        "Untick a group, like Trees and Plants, to hide it.",
    )),
    ("Exporting to FBX", (
        "Click a build's top empty in the Outliner to select it.",
        "Open Export and press Export Selection as FBX.",
        "Instanced grass and plants become separate objects in the file. Your scene stays as it was.",
    )),
    ("Other buttons", (
        "uMap Import: builds a level from Content/Maps, like a lobby.",
        "FModel Scene: imports a .usda that FModel exported with World. The meshes come from your normal export.",
    )),
)


def draw_help(layout, context, sections):
    """One collapsible section per topic, closed to begin with, with text that wraps to the sidebar's width."""
    width = max(context.region.width - 40, 100) / (6.5 * context.preferences.system.ui_scale)
    for number, (heading, lines) in enumerate(sections):
        header, body = layout.panel("dbd_help_%d" % number, default_closed=True)
        header.label(text=heading)
        if body is None:
            continue
        col = body.box().column(align=True)
        col.scale_y = 0.8
        for index, line in enumerate(lines):
            if index:
                col.separator(factor=0.8)
            for part in textwrap.wrap(line.replace("/", "/ "), max(int(width), 16), break_long_words=False):
                col.label(text=part)


def gui_props(context):
    return context.scene.json_importer_gui_props


# Two copies of this add-on can be enabled at once (the old zip install and the extension, say): they register the same panels, buttons
# and scene settings, so the copy registered last replaces the other's.  Each copy only removes what is its own, gives the other its
# classes back when it is turned off, and the panel warns while both are on.
SETTINGS_PROP = "json_importer_gui_props"
ADDON_NAME = "OhPorty's DbD Blueprint/Tile Builder"     # not bl_info["name"]: Blender deletes bl_info from an extension when it loads it
COPY_IDS = ("dbd_tile_builder", "tile builder")


def _is_copy(key, module):
    if key == __package__:
        return False
    name = ((getattr(module, "bl_info", None) or {}).get("name") or "") if module else ""
    return name == ADDON_NAME or key.rsplit(".", 1)[-1].lower() in COPY_IDS


def other_copies(context):
    """Module names of the other enabled copies of this add-on."""
    return [key for key in context.preferences.addons.keys() if _is_copy(key, sys.modules.get(key))]


def copy_label(key):
    """('Extension', None) or ('Old add-on', its folder): short, so the sidebar doesn't cut it off."""
    parts = key.split(".")
    if len(parts) == 3 and parts[0] == "bl_ext":
        return "Extension", None
    return "Old add-on", key


def draw_copy_warning(layout, context):
    others = other_copies(context)
    if not others:
        return
    box = layout.box()
    box.alert = True
    col = box.column(align=True)
    col.label(text="Another copy of this add-on is on", icon='ERROR')
    for prefix, key in [("This one: ", __package__)] + [("Also on: ", k) for k in others]:
        kind, folder = copy_label(key)
        col.label(text=prefix + kind)
        if folder:
            col.label(text="    folder: " + folder)
    col.label(text="Remove one in Preferences > Add-ons,")
    col.label(text="then restart Blender.")


def _own_version():
    """This copy's version, from its blender_manifest.toml (an extension has no bl_info once loaded), else from bl_info."""
    try:
        with open(os.path.join(os.path.dirname(__file__), "blender_manifest.toml"), encoding="utf-8") as f:
            m = re.search(r'^version = "([^"]+)"', f.read(), re.M)
        if m:
            return m.group(1)
    except OSError:
        pass
    info = globals().get("bl_info") or {}
    return ".".join(str(n) for n in info.get("version", ())) or "?"


OWN_VERSION = _own_version()
VERSION_LINE = "Version %s · %s" % (OWN_VERSION, "Extension" if __package__.startswith("bl_ext.") else "Add-on (old install)")


def _version_tuple(text):
    try:
        return tuple(int(n) for n in str(text).split("."))
    except ValueError:
        return ()


_UPDATE_CHECK = {"mtime": None, "version": None}


def available_update():
    """
    The newer version Blender's own update check found for this extension, or None.  Blender keeps a copy of each repository's index.json in the
    repository's .blender_ext folder (it refreshes it when it checks for updates, which is what marks updates in Preferences): read that, no network.
    """
    if not __package__.startswith("bl_ext."):
        return None
    index = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".blender_ext", "index.json")
    try:
        mtime = os.path.getmtime(index)
    except OSError:
        return None
    if mtime != _UPDATE_CHECK["mtime"]:              # read again only when Blender has refreshed it
        _UPDATE_CHECK["mtime"], _UPDATE_CHECK["version"] = mtime, None
        own_id = __package__.rsplit(".", 1)[-1]
        try:
            with open(index, encoding="utf-8") as f:
                for item in json.load(f).get("data") or []:
                    if item.get("id") == own_id:
                        _UPDATE_CHECK["version"] = item.get("version")
        except (OSError, ValueError, AttributeError):
            pass
    newer = _UPDATE_CHECK["version"]
    return newer if newer and _version_tuple(newer) > _version_tuple(OWN_VERSION) else None


def draw_update(layout):
    newer = available_update()
    if not newer:
        return
    box = layout.box()
    col = box.column(align=True)
    col.label(text="Update available: %s" % newer, icon='COLLECTION_COLOR_03')     # yellow in every theme: ERROR draws white in Blender 5's default
    col.label(text="You have %s. To update, go to" % OWN_VERSION)
    col.label(text="Edit > Preferences > Get Extensions")


def draw_version(layout):
    """Shown by 1.0.2 and later only: a panel without this line is drawn by an older copy."""
    row = layout.row()
    row.enabled = False
    row.label(text=VERSION_LINE, icon='CHECKMARK')


def file_field(layout, props, name, label, alert=False):
    """A label above its box: beside it the sidebar cuts the label short at its default width."""
    col = layout.column(align=True)
    col.label(text=label)
    row = col.row()
    row.alert = alert
    row.prop(props, name, text="")


def run_button(layout, props, json_path, operator, text):
    """The section's main button.  It wakes up once both the exports folder and the section's file are set."""
    row = layout.row()
    row.scale_y = 1.4
    row.enabled = bool(props.model_base_path and json_path)
    row.operator(operator, text=text, icon='PLAY')


class OBJECT_PT_JSONImporterGUIPanel(bpy.types.Panel):
    bl_label = "Porty's Blueprint Builder"
    bl_idname = "OBJECT_PT_json_importer_gui_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Porty's BPs"

    def draw(self, context):
        layout = self.layout
        draw_copy_warning(layout, context)
        draw_update(layout)
        draw_version(layout)
        if not hasattr(context.scene, SETTINGS_PROP):
            layout.label(text="Settings missing: restart Blender", icon='ERROR')
            return
        props = gui_props(context)
        file_field(layout, props, "model_base_path", "Exports Folder", alert=not props.model_base_path)
        if not props.model_base_path:
            layout.label(text="Set this folder first", icon='ERROR')


class BuilderSubPanel(object):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Porty's BPs"
    bl_parent_id = "OBJECT_PT_json_importer_gui_panel"

    @classmethod
    def poll(cls, context):
        return hasattr(context.scene, SETTINGS_PROP)


class OBJECT_PT_BuilderFullMap(BuilderSubPanel, bpy.types.Panel):
    bl_label = "Full Map"
    bl_idname = "OBJECT_PT_builder_full_map"

    def draw(self, context):
        layout = self.layout
        props = gui_props(context)
        file_field(layout, props, "json_file_path_4", "Tiled Map JSON")
        row = layout.row(align=True)
        row.prop(props, "map_seed", text="Seed")
        row.operator("object.new_map_seed", text="New Seed", icon='FILE_REFRESH')
        run_button(layout, props, props.json_file_path_4, "object.run_script4", "Build Full Map")


class OBJECT_PT_BuilderBlueprint(BuilderSubPanel, bpy.types.Panel):
    bl_label = "Single Tile or Blueprint"
    bl_idname = "OBJECT_PT_builder_blueprint"

    def draw(self, context):
        layout = self.layout
        props = gui_props(context)
        file_field(layout, props, "json_file_path_2", "Tile or Blueprint JSON")
        run_button(layout, props, props.json_file_path_2, "object.run_script2", "Build Blueprint")


class OBJECT_PT_BuilderUsd(BuilderSubPanel, bpy.types.Panel):
    bl_label = "FModel Scene (.usda)"
    bl_idname = "OBJECT_PT_builder_usd"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = gui_props(context)
        file_field(layout, props, "json_file_path_5", "FModel Scene")
        run_button(layout, props, props.json_file_path_5, "object.run_script5", "Import FModel Scene")


class OBJECT_PT_BuilderUmap(BuilderSubPanel, bpy.types.Panel):
    bl_label = "uMap Import"
    bl_idname = "OBJECT_PT_builder_umap"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = gui_props(context)
        file_field(layout, props, "json_file_path_3", "uMap JSON")
        layout.prop(props, "umap_sublevels")
        run_button(layout, props, props.json_file_path_3, "object.run_script3", "Import uMap")


class OBJECT_PT_BuilderObjects(BuilderSubPanel, bpy.types.Panel):
    bl_label = "Gameplay Objects"
    bl_idname = "OBJECT_PT_builder_objects"

    ROWS = (("build_generators", "count_generators"), ("build_totems", "count_totems"), ("build_chests", "count_chests"),
            ("build_pallets", "count_pallets"), ("build_lockers", "count_lockers"), ("build_hooks", None), ("build_vaults", None), ("build_hatch", None))

    def draw(self, context):
        props = gui_props(context)
        col = self.layout.column(align=True)
        split = col.split(factor=0.55)
        split.label(text="Build")
        split.label(text="How many")
        for flag, count in self.ROWS:
            split = col.split(factor=0.55)
            split.prop(props, flag)
            cell = split.row()
            cell.active = getattr(props, flag)
            if count:
                cell.prop(props, count, text="")
            else:
                cell.label(text="All")
        self.layout.label(text="0 = every spawn point")


class OBJECT_PT_BuilderLights(BuilderSubPanel, bpy.types.Panel):
    bl_label = "Lights"
    bl_idname = "OBJECT_PT_builder_lights"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        self.layout.prop(gui_props(context), "build_lights", text="")

    def draw(self, context):
        props = gui_props(context)
        col = self.layout.column()
        col.active = props.build_lights
        col.prop(props, "light_strength")
        col.prop(props, "light_min_radius")
        col.prop(props, "light_spot_size")
        col.prop(props, "build_lights_off")
        col.prop(props, "build_generator_lights")
        col.prop(props, "light_round_as_disc")
        col.prop(props, "light_static_no_volume")
        file_field(col, props, "light_no_volume_names", "No fog for lights named")


class OBJECT_PT_BuilderAdvanced(BuilderSubPanel, bpy.types.Panel):
    bl_label = "Advanced"
    bl_idname = "OBJECT_PT_builder_advanced"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = gui_props(context)
        layout.prop(props, "spawn_scene_blueprints")
        layout.prop(props, "auto_build_children")
        layout.prop(props, "hide_hidden_in_game")
        layout.prop(props, "use_instancing")
        file_field(layout, props, "skip_name_patterns", "Skip components named")


class OBJECT_OT_ExportFbx(bpy.types.Operator, ExportHelper):
    bl_idname = "object.dbd_export_fbx"
    bl_label = "Export Selection as FBX"
    bl_description = ("Export the selected objects to an FBX file. Instanced grass and plants are turned into separate objects for the "
                      "file, then put back as they were")
    bl_options = {'REGISTER'}
    filename_ext = ".fbx"
    filter_glob: bpy.props.StringProperty(default="*.fbx", options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return bool(context.selected_objects)

    def execute(self, context):
        try:
            reload_helpers()
            exporter = importlib.import_module(".dbd_export", __package__)
            props = gui_props(context)
            count, made = exporter.export_selection(context, self.filepath, include_children=props.export_children)
        except Exception as exc:
            traceback.print_exc()
            self.report({'ERROR'}, "FBX export failed: %s" % exc)
            return {'CANCELLED'}
        self.report({'INFO'}, "Exported %d objects to %s%s" % (count, os.path.basename(self.filepath),
                                                                 (" (%d were instances)" % made) if made else ""))
        return {'FINISHED'}


class OBJECT_PT_BuilderExport(BuilderSubPanel, bpy.types.Panel):
    bl_label = "Export"
    bl_idname = "OBJECT_PT_builder_export"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = gui_props(context)
        layout.prop(props, "export_children")
        row = layout.row()
        row.scale_y = 1.4
        row.operator("object.dbd_export_fbx", icon='EXPORT')
        if not context.selected_objects:
            layout.label(text="Select what to export first", icon='INFO')


class OBJECT_PT_BuilderHelp(BuilderSubPanel, bpy.types.Panel):
    bl_label = "Help"
    bl_idname = "OBJECT_PT_builder_help"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        draw_help(self.layout, context, HELP)


# Registration (the "Script 1" operator stays registered but has no button: Build Blueprint places the child actors itself)
CLASSES = (JSONImporterGUIProperties, OBJECT_OT_NewMapSeed, OBJECT_OT_RunScript1, OBJECT_OT_RunScript2, OBJECT_OT_RunScript3,
           OBJECT_OT_RunScript4, OBJECT_OT_RunScript5, OBJECT_PT_JSONImporterGUIPanel, OBJECT_PT_BuilderFullMap, OBJECT_PT_BuilderBlueprint,
           OBJECT_PT_BuilderUmap, OBJECT_PT_BuilderUsd, OBJECT_PT_BuilderObjects, OBJECT_PT_BuilderLights, OBJECT_PT_BuilderAdvanced,
           OBJECT_OT_ExportFbx, OBJECT_PT_BuilderExport, OBJECT_PT_BuilderHelp)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.json_importer_gui_props = bpy.props.PointerProperty(type=JSONImporterGUIProperties)


def _owns_settings():
    prop = bpy.types.Scene.bl_rna.properties.get(SETTINGS_PROP)
    return prop is not None and JSONImporterGUIProperties.is_registered and prop.fixed_type == JSONImporterGUIProperties.bl_rna


def _restore_other_copies():
    """Give an enabled copy back the classes and settings this copy had replaced (an old copy's register() can't be rerun: it would clash)."""
    for key in list(bpy.context.preferences.addons.keys()):
        module = sys.modules.get(key)
        if not _is_copy(key, module):
            continue
        for cls in getattr(module, "CLASSES", ()):
            if not cls.is_registered:
                try:
                    bpy.utils.register_class(cls)
                except Exception as exc:
                    print("Tile Builder: could not give %s back %s: %s" % (key, cls.__name__, exc))
        group = getattr(module, "JSONImporterGUIProperties", None)
        if group is not None and group.is_registered and bpy.types.Scene.bl_rna.properties.get(SETTINGS_PROP) is None:
            bpy.types.Scene.json_importer_gui_props = bpy.props.PointerProperty(type=group)


def unregister():
    if _owns_settings():
        del bpy.types.Scene.json_importer_gui_props
    for cls in reversed(CLASSES):
        if cls.is_registered:          # not when another copy registered the same class over this one
            bpy.utils.unregister_class(cls)
    _restore_other_copies()


if __name__ == "__main__":
    register()
