"""
Script 2 - General Blueprint build.

Builds one blueprint JSON (tile, sub-building, prop, ...) from its SimpleConstructionScript:
every StaticMeshComponent / instanced mesh is imported from its .pskx and placed with the exact
actor-space transform resolved by dbd_core, ChildActorComponents become empties that receive an
instanced copy of the child blueprint (if it was built earlier), and scene components / actor
spawners become hidden marker empties.
"""
import bpy

from . import dbd_blender
from . import dbd_core
def main(context):
    props = context.scene.json_importer_gui_props
    json_path = bpy.path.abspath(props.json_file_path_2)
    if not json_path:
        print("Script 2: no Blueprint JSON selected.")
        return

    try:
        bp = dbd_core.load_blueprint(json_path, find=dbd_blender.BlueprintLocator(props.model_base_path).find)
    except Exception as exc:
        print("Script 2: could not read %s: %s" % (json_path, exc))
        raise

    print("Building %s from %s" % (bp.class_name, json_path))
    print("  %d SCS nodes, %d placements (%d from inherited overrides)" % (
        len(bp.nodes), len(bp.placements), len([p for p in bp.placements if p.source == "inherited"])))

    report = dbd_blender.Report()
    locator = None
    if props.auto_build_children:
        locator = dbd_blender.BlueprintLocator(props.model_base_path)
        if not locator.bases:
            print("  Auto-build of child blueprints is on but no valid Model Base Path is set.")
    ctx = dbd_blender.BuildContext(props.model_base_path, report, props.hide_hidden_in_game, locator,
                                   **dbd_blender.options_from_props(props))
    main_empty = dbd_blender.build_blueprint(bp, ctx=ctx)
    dbd_blender.organize_build(main_empty, bp.class_name, bp.class_name.removesuffix("_C"))
    if ctx.auto_built:
        print("  Auto-built %d child blueprints: %s" % (len(ctx.auto_built), ", ".join(ctx.auto_built)))
    dbd_blender.apply_game_sky(context.scene, ctx, json_path=json_path)
    dbd_blender.file_sky_parts(bp.class_name, bp.class_name.removesuffix("_C"))
    dbd_blender.match_game_exposure(context.scene, ctx)
    report.print_summary("Blueprint build: %s" % bp.class_name)
    print("Script executed successfully.")
