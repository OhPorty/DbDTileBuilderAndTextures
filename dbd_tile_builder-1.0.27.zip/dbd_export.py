"""
FBX export of the selection, with Tile Builder instancers turned into real objects for the export and taken out again afterwards.

FBX has no Geometry Nodes, and most programs read instances poorly, so each instancer's points become ordinary objects for the length of the export:
copies of its source object (mesh data and override materials shared) at the instances' transforms, under the instancer's parent so the hierarchy holds.
"""
import bpy
import mathutils
import numpy as np

from . import dbd_blender


def is_instancer(obj):
    return obj.type == "MESH" and obj.get("dbd_instance_source") is not None and obj.modifiers.get("DbD Instances") is not None


def point_transforms(obj):
    """The instancer's per-point 4x4s (instancer space) as mathutils matrices."""
    mesh = obj.data
    attribute = mesh.attributes.get(dbd_blender.TRANSFORM_ATTRIBUTE)
    if attribute is None:
        return []
    flat = np.zeros(len(attribute.data) * 16, dtype=np.float32)
    attribute.data.foreach_get("value", flat)
    cols = flat.reshape(-1, 4, 4)                 # stored column by column
    return [mathutils.Matrix(m.T.tolist()) for m in cols]


def gather(context, include_children):
    """The objects to export: the selection, and everything under it when asked, left out when hidden in the viewport."""
    chosen = []
    seen = set()
    for obj in context.selected_objects:
        for o in [obj] + (list(obj.children_recursive) if include_children else []):
            if o.name in seen or not o.visible_get():
                continue
            seen.add(o.name)
            chosen.append(o)
    return chosen


def realize(instancer, collection):
    """Real objects for one instancer's instances, linked into `collection`.  Returns them."""
    source = instancer.get("dbd_instance_source")
    out = []
    if source is None:
        return out
    world = instancer.matrix_world
    for i, local in enumerate(point_transforms(instancer)):
        copy = source.copy()                      # shares the mesh; keeps the override materials
        copy.name = "%s_%d" % (instancer.name, i)
        for key in ("dbd_source_key",):
            if key in copy:
                del copy[key]
        collection.objects.link(copy)
        copy.parent = instancer.parent
        copy.matrix_world = world @ local
        out.append(copy)
    return out


def export_selection(context, filepath, include_children=True, **fbx_options):
    """
    Export the selection to `filepath`.  Returns (objects exported, instances made real).  The scene is left as it was found, even when the export fails.
    """
    if not hasattr(bpy.ops.export_scene, "fbx"):
        raise RuntimeError("Blender's FBX exporter is turned off: enable 'FBX format' in Preferences > Add-ons")
    view_layer = context.view_layer
    chosen = gather(context, include_children)
    if not chosen:
        raise RuntimeError("Nothing to export: select the objects, or a build's top empty")
    was_selected = [o for o in view_layer.objects if o.select_get()]
    was_active = view_layer.objects.active

    temp = bpy.data.collections.new("DbD_FBX_Export")
    context.scene.collection.children.link(temp)
    made = []
    try:
        export = []
        for obj in chosen:
            if is_instancer(obj):
                made += realize(obj, temp)
            else:
                export.append(obj)
        export += made
        for o in was_selected:
            o.select_set(False)
        for o in export:
            o.select_set(True)
        if export:
            view_layer.objects.active = export[0]
        options = dict(use_selection=True, object_types={"EMPTY", "MESH", "LIGHT", "ARMATURE", "OTHER"},
                       use_mesh_modifiers=True, path_mode="AUTO")
        options.update(fbx_options)
        bpy.ops.export_scene.fbx(filepath=filepath, **options)
        return len(export), len(made)
    finally:
        dbd_blender._remove_objects(made)
        bpy.data.collections.remove(temp)
        for o in view_layer.objects:
            if o.select_get():
                o.select_set(False)
        for o in was_selected:
            try:
                o.select_set(True)
            except ReferenceError:
                pass
        view_layer.objects.active = was_active
