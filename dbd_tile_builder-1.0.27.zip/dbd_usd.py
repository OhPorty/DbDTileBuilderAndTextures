"""
A map, tile or level FModel exported as a USD scene (right-click > World, Mesh Format: Universal Scene Description).  FModel runs the game's own generator for
it, with the meshes' real collision, so what it places is exactly what the game places.  Only the placements are read from the .usda: each mesh it references
is loaded from the user's normal export (.pskx, .psk, .uemodel) at the same path, so the USD copies of the meshes are not needed.

USD space here is Unreal's in centimetres with Y mirrored, which is Blender's frame: a transform only needs its translation scaled to metres.
"""
import os
import re

import bpy
import mathutils

from . import dbd_blender
from . import dbd_core

MESH_PRIMS = ("Mesh", "SkelRoot")
LIGHT_PRIMS = ("SphereLight", "RectLight", "DistantLight")
SKIPPED_SHAPES = re.compile(r"/Engine/|/StarterContent/Shapes/", re.I)


def blender_matrix(gf):
    """A USD world transform (row vectors, cm) as a Blender matrix (column vectors, m)."""
    m = mathutils.Matrix([list(gf.GetRow(i)) for i in range(4)]).transposed()
    m.translation = m.translation * 0.01
    return m


def object_path(asset):
    """'.../DeadByDaylight/Content/Meshes/X/SM_A.usda' -> '/Game/Meshes/X/SM_A.SM_A'; a realm plugin's Content gives '/<Realm>/...'."""
    path = asset.replace("\\", "/")
    head, sep, tail = path.rpartition("/Content/")
    if not sep:
        return None, None
    stem = os.path.splitext(os.path.basename(tail))[0]
    folder = os.path.basename(head)
    mount = "Game" if folder in ("DeadByDaylight", "") else ("Engine" if folder == "Engine" else folder)
    return "/%s/%s.%s" % (mount, os.path.splitext(tail)[0], stem), stem


def stripped_layer(path, assets):
    """
    A copy of the layer without its references, which are recorded in `assets` ({prim path: absolute file}).  USD would try to open every mesh file FModel
    wrote beside the scene, and warn hundreds of thousands of times for those not kept: the meshes come from the normal export instead.  Sub-layers (a level's
    streamed levels) are stripped the same way.
    """
    from pxr import Sdf
    source = Sdf.Layer.FindOrOpen(path)
    if source is None:
        raise RuntimeError("could not open %s" % path)
    layer = Sdf.Layer.CreateAnonymous(".usda")
    layer.TransferContent(source)
    folder = os.path.dirname(path)

    def visit(spec):
        refs = spec.referenceList
        items = list(refs.prependedItems) + list(refs.explicitItems) + list(refs.appendedItems)
        target = next((i.assetPath for i in items if i.assetPath), None)
        if target:
            assets[str(spec.path)] = os.path.normpath(os.path.join(folder, target))
            refs.ClearEdits()
        for child in spec.nameChildren:
            visit(child)

    for root in layer.rootPrims:
        visit(root)
    layer.subLayerPaths[:] = [stripped_layer(os.path.normpath(os.path.join(folder, sub)), assets).identifier for sub in list(layer.subLayerPaths)]
    return layer


def referenced_asset(prim, assets):
    return assets.get(str(prim.GetPath()))


def override_materials(prim):
    """[material name per section] from the prim's OverrideMaterials and its Section_i bindings."""
    names = {}
    for child in prim.GetChildren():
        match = re.match(r"Section_(\d+)$", child.GetName())
        if not match:
            continue
        rel = child.GetRelationship("material:binding")
        targets = rel.GetTargets() if rel else []
        if targets:
            names[int(match.group(1))] = targets[0].name
    return [names.get(i) for i in range(max(names) + 1)] if names else []


def gameplay_category(prim, cache):
    """The gameplay group of the nearest blueprint scope above the prim ('BP_Pallet_C' -> pallets), or None."""
    key = str(prim.GetPath())
    if key not in cache:
        own = None
        name = prim.GetName()
        if prim.GetTypeName() == "Scope" and name.endswith("_C"):
            own = dbd_core.gameplay_class_category(name)
        parent = prim.GetParent()
        cache[key] = own or (gameplay_category(parent, cache) if parent and not parent.IsPseudoRoot() else None)
    return cache[key]


def build_light(prim, world, main, owner, ctx):
    """A Blender light from a USD light FModel wrote: the Unreal values through the add-on's own conversion.  USD lights face -Z, as Blender's do."""
    get = lambda name, default: (prim.GetAttribute(name).Get() if prim.GetAttribute(name) and prim.GetAttribute(name).HasAuthoredValue() else default)
    kind = prim.GetTypeName()
    colour = get("inputs:color", (1.0, 1.0, 1.0))
    props = {"Intensity": float(get("inputs:intensity", 0.0)), "LightColor": {"R": colour[0] * 255.0, "G": colour[1] * 255.0, "B": colour[2] * 255.0},
             "CastShadows": bool(get("inputs:castShadows", True))}
    if get("inputs:enableColorTemperature", False):
        props["bUseTemperature"] = True
        props["Temperature"] = float(get("inputs:colorTemperature", 6500.0))
    if kind == "SphereLight" and prim.GetAttribute("inputs:shaping:cone:angle"):
        comp = "SpotLightComponent"
        outer = float(get("inputs:shaping:cone:angle", 44.0))
        props.update(OuterConeAngle=outer, InnerConeAngle=outer * (1.0 - float(get("inputs:shaping:cone:softness", 0.0))), SourceRadius=float(get("inputs:radius", 0.0)))
    elif kind == "SphereLight":
        comp = "PointLightComponent"
        props["SourceRadius"] = float(get("inputs:radius", 0.0))
    elif kind == "RectLight":
        comp = "RectLightComponent"
        props.update(SourceHeight=float(get("inputs:width", 64.0)), SourceWidth=float(get("inputs:height", 64.0)))
    else:
        comp = "DirectionalLightComponent"
        props["LightSourceAngle"] = float(get("inputs:angle", 0.5357))
    info = dbd_core.light_from_props(comp, props)
    btype = info["blender_type"]
    data = bpy.data.lights.new(prim.GetName(), btype)
    data.color = info["color"]
    data.energy = info["watts"] * ctx.light_strength
    data.use_shadow = info["cast_shadows"]
    if btype == "SPOT":
        outer = min(max(info["outer_degrees"], 1.0), 89.0)
        data.spot_size = 2.0 * outer * 3.141592653589793 / 180.0
        data.spot_blend = min(max(1.0 - min(info["inner_degrees"], outer) / outer, 0.0), 1.0)
    elif btype == "AREA":
        data.shape = "RECTANGLE"
        data.size, data.size_y = max(info.get("height_m", 0.64), 0.01), max(info.get("width_m", 0.64), 0.01)
    elif btype == "POINT":
        data.shadow_soft_size = dbd_core.soft_radius(info["source_radius_ue_m"], ctx.light_min_radius)
    obj = bpy.data.objects.new(prim.GetName(), data)
    obj.visible_camera = False
    dbd_blender._link(obj)
    obj.parent = main
    obj.matrix_basis = world
    obj["dbd_owner"] = owner
    if info["switched_off"]:
        obj.hide_render = obj.hide_viewport = True
    ctx.report.built["lights"] += 1


def place_mesh(prim, world, main, owner, ctx, name, gameplay, assets):
    asset = referenced_asset(prim, assets)
    if not asset:
        return
    path, stem = object_path(asset)
    if not path:
        return
    if SKIPPED_SHAPES.search(path) or stem in dbd_core.ENGINE_SHAPES:
        ctx.report.skipped_engine_shapes += 1
        return
    from pxr import UsdGeom
    hidden = UsdGeom.Imageable(prim).ComputeVisibility() == UsdGeom.Tokens.invisible
    for obj in ctx.meshes.instance(path, stem, name):
        dbd_blender._link  # objects are linked by MeshLibrary.instance
        obj.parent = main
        obj.matrix_basis = world
        obj["dbd_owner"] = owner
        if gameplay:
            obj["dbd_gameplay"] = gameplay
        dbd_blender.apply_override_materials(obj, override_materials(prim), ctx.report)
        if hidden:
            obj["ue_hidden_in_game"] = True
            if ctx.hide_hidden_in_game:
                obj.hide_render = obj.hide_viewport = True
        ctx.report.built["meshes"] += 1


def place_instancer(proto, matrices, main, owner, ctx, name, gameplay, assets):
    """A point instancer's copies of one prototype as one Geometry Nodes instancer (see dbd_blender.make_instancer)."""
    asset = referenced_asset(proto, assets)
    if not asset:
        return
    path, stem = object_path(asset)
    if not path:
        return
    if SKIPPED_SHAPES.search(path) or stem in dbd_core.ENGINE_SHAPES:
        ctx.report.skipped_engine_shapes += 1
        return
    from pxr import UsdGeom
    hidden = UsdGeom.Imageable(proto).ComputeVisibility() == UsdGeom.Tokens.invisible
    rows = [[list(r) for r in m] for m in matrices]
    for source in ctx.meshes.source(path, stem, override_materials(proto)):
        obj = dbd_blender.make_instancer(name, source, rows)
        obj.parent = main
        obj["dbd_owner"] = owner
        if gameplay:
            obj["dbd_gameplay"] = gameplay
        if hidden:
            obj["ue_hidden_in_game"] = True
            if ctx.hide_hidden_in_game:
                obj.hide_render = obj.hide_viewport = True
        ctx.report.built["instanced meshes"] += len(rows)
        ctx.report.built["instancers (one object per instanced component)"] += 1


def import_scene(usda_path, ctx):
    """Place everything a FModel USD scene holds.  Returns (main empty, owner, name) for organize_build."""
    from pxr import Usd, UsdGeom
    assets = {}
    stage = Usd.Stage.Open(stripped_layer(usda_path, assets))
    name = os.path.splitext(os.path.basename(usda_path))[0]
    owner = "usd:%s" % name
    removed = dbd_blender.remove_previous_build(owner)
    if removed:
        print("Removed %d objects from a previous import of %s" % (removed, name))
    main = dbd_blender.make_empty("%s_FModel" % name, size=2.0)
    main["dbd_owner"] = owner
    xforms = UsdGeom.XformCache(Usd.TimeCode.Default())
    categories = {}
    for prim in stage.Traverse():
        kind = prim.GetTypeName()
        if "/Prototypes/" in str(prim.GetPath()):
            continue                                    # a point instancer's mesh: placed by its instancer
        try:
            if kind in MESH_PRIMS:
                place_mesh(prim, blender_matrix(xforms.GetLocalToWorldTransform(prim)), main, owner, ctx, prim.GetName(), gameplay_category(prim, categories), assets)
            elif kind == "PointInstancer":
                instancer = UsdGeom.PointInstancer(prim)
                prototypes = instancer.GetPrototypesRel().GetTargets()
                indices = instancer.GetProtoIndicesAttr().Get() or []
                transforms = instancer.ComputeInstanceTransformsAtTime(Usd.TimeCode.Default(), Usd.TimeCode.Default())
                world = xforms.GetLocalToWorldTransform(prim)
                gameplay = gameplay_category(prim, categories)
                pairs = list(zip(indices, transforms))
                if ctx.instancing:
                    by_proto = {}
                    for index, local in pairs:
                        by_proto.setdefault(index, []).append(blender_matrix(local * world))
                    for index, matrices in by_proto.items():
                        proto = stage.GetPrimAtPath(prototypes[index]) if index < len(prototypes) else None
                        if proto is None or proto.GetTypeName() not in MESH_PRIMS:
                            continue
                        if len(matrices) > 1:
                            place_instancer(proto, matrices, main, owner, ctx, prim.GetName(), gameplay, assets)
                        else:
                            place_mesh(proto, matrices[0], main, owner, ctx, "%s_Instance_0" % prim.GetName(), gameplay, assets)
                            ctx.report.built["instanced meshes"] += 1
                    continue
                for i, (index, local) in enumerate(pairs):
                    proto = stage.GetPrimAtPath(prototypes[index]) if index < len(prototypes) else None
                    if proto is not None and proto.GetTypeName() in MESH_PRIMS:
                        place_mesh(proto, blender_matrix(local * world), main, owner, ctx, "%s_Instance_%d" % (prim.GetName(), i), gameplay, assets)
                        ctx.report.built["instanced meshes"] += 1
            elif kind in LIGHT_PRIMS and ctx.lights:
                build_light(prim, blender_matrix(xforms.GetLocalToWorldTransform(prim)), main, owner, ctx)
        except Exception as exc:
            ctx.report.warnings.append("%s: %s" % (prim.GetPath(), exc))
    return main, owner, name
