"""
Shared helpers for dbd_matbuild.py (Porty's Material Maker): reading fModel material exports and finding material / texture files.

* legacy_material(raw)   reads a FModel material export of ANY era and returns the dict shape the scripts were written for:
                             {"Textures": {key: "/Game/.../name"}, "Parameters": {"Scalars", "Colors", "Switches", "IsTranslucent",
                              "BlendMode", "Properties": {"TwoSided"}}, ...the same values again at the top level}
  Shapes it understands:
    - old dict export:      Textures {key: "path"}, Parameters {Scalars, Colors, Switches, ...}
    - new dict export:      Textures {key: {"AssetPathName": ...} | {"ObjectName", "ObjectPath"} | null}, and Scalars / Colors / Switches /
                            BlendMode / IsTranslucent at the TOP level (no "Parameters"), TwoSided under Properties.BasePropertyOverrides
    - Unreal property list: [ {"Properties": {TextureParameterValues, ScalarParameterValues, VectorParameterValues, ...}} ]
* find_material_json()  finds <material name>.json under the export (any folder layout), the newest copy when there are several
* find_texture_file()   finds the texture file for an Unreal asset path under the export, whatever folder layout the export used
* RunLog                counts what happened and prints one summary at the end

Nothing here depends on a drive letter or a folder name.  The only Blender use is bpy.app.driver_namespace, which keeps the file index
between runs of the add-on (a module reload would otherwise throw it away); outside Blender it falls back to a module dictionary.
"""
import json
import os
import re
import time

TEXTURE_EXTENSIONS = (".png", ".tga")

# ---------------------------------------------------------------------------------------------------------------------------------
# Reading material exports
# ---------------------------------------------------------------------------------------------------------------------------------

_BLEND_MODES = {"opaque": 0, "masked": 1, "translucent": 2, "additive": 3, "modulate": 4, "alphacomposite": 5, "alphaholdout": 6}


def texture_ref(value):
    """
    The Unreal asset path of a texture reference, however the export wrote it: a plain string, {"AssetPathName": ...},
    {"ObjectPath": ...} or only {"ObjectName": "Texture2D'T_Name'"}.  None for null / empty.
    """
    if isinstance(value, str):
        value = value.strip()
        return value or None
    if isinstance(value, dict):
        for key in ("AssetPathName", "ObjectPath"):
            v = value.get(key)
            if isinstance(v, str) and v.strip():
                return v.strip()
        name = value.get("ObjectName")
        if isinstance(name, str) and name.strip():
            m = re.search(r"'([^']+)'", name)
            return (m.group(1) if m else name).strip()
    return None


def _num(value, default=0.0):
    try:
        v = float(value)
        return v if v == v and abs(v) != float("inf") else default
    except (TypeError, ValueError):
        return default


def _color(value):
    if isinstance(value, dict):
        return {k: _num(value.get(k), 1.0) for k in ("R", "G", "B", "A")}
    return None


def _blend_mode(value):
    """BlendMode as the export's integer (0 opaque, 1 masked, 2 translucent ...), from an int or a name like 'BLEND_Translucent'."""
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    if isinstance(value, str):
        low = value.lower()
        for name, number in _BLEND_MODES.items():
            if name in low:
                return number
    return 0


def _name(info):
    n = info.get("Name") if isinstance(info, dict) else None
    if isinstance(n, dict):                    # FName written as {"Name": ...} or similar
        n = n.get("Name") or n.get("String") or next((v for v in n.values() if isinstance(v, str)), None)
    return n if isinstance(n, str) else ""


def _from_property_list(item):
    """An Unreal property export (a list whose first object carries Properties)."""
    props = item.get("Properties") or {}
    out = {"Textures": {}, "Scalars": {}, "Colors": {}, "Switches": {}}
    for e in props.get("TextureParameterValues") or []:
        if not isinstance(e, dict):
            continue
        ref = texture_ref(e.get("ParameterValue"))
        if ref:
            out["Textures"][_name(e.get("ParameterInfo"))] = ref
    for e in props.get("ScalarParameterValues") or []:
        if isinstance(e, dict):
            out["Scalars"][_name(e.get("ParameterInfo"))] = _num(e.get("ParameterValue"), 0.0)
    for e in props.get("VectorParameterValues") or []:
        c = _color(e.get("ParameterValue")) if isinstance(e, dict) else None
        if c:
            out["Colors"][_name(e.get("ParameterInfo"))] = c
    static = props.get("StaticParametersRuntime") or {}
    for e in (static.get("StaticSwitchParameters") or []) if isinstance(static, dict) else []:
        if isinstance(e, dict):
            out["Switches"][_name(e.get("ParameterInfo"))] = bool(e.get("Value"))
    bpo = props.get("BasePropertyOverrides") if isinstance(props.get("BasePropertyOverrides"), dict) else {}
    out["BlendMode"] = _blend_mode(bpo.get("BlendMode"))
    out["TwoSided"] = bool(bpo.get("TwoSided"))
    out["IsTranslucent"] = out["BlendMode"] == 2
    return out


def _from_dict(d):
    """Old (with 'Parameters') and new (everything at the top level) dict exports."""
    params = d.get("Parameters") if isinstance(d.get("Parameters"), dict) else {}

    def pick(key):
        v = params.get(key)
        return v if isinstance(v, dict) else (d.get(key) if isinstance(d.get(key), dict) else {})

    out = {"Textures": {}, "Scalars": {}, "Colors": {}, "Switches": {}}
    for k, v in (d.get("Textures") or {}).items() if isinstance(d.get("Textures"), dict) else []:
        ref = texture_ref(v)
        if ref:
            out["Textures"][k] = ref
    for k, v in pick("Scalars").items():
        out["Scalars"][k] = _num(v, 0.0)
    for k, v in pick("Colors").items():
        c = _color(v)
        if c:
            out["Colors"][k] = c
    for k, v in pick("Switches").items():
        out["Switches"][k] = bool(v)
    props = d.get("Properties") if isinstance(d.get("Properties"), dict) else {}
    bpo = props.get("BasePropertyOverrides") if isinstance(props.get("BasePropertyOverrides"), dict) else {}
    old_props = params.get("Properties") if isinstance(params.get("Properties"), dict) else {}
    blend = params.get("BlendMode", d.get("BlendMode", bpo.get("BlendMode")))
    out["BlendMode"] = _blend_mode(blend)
    out["TwoSided"] = bool(old_props.get("TwoSided") or bpo.get("TwoSided") or d.get("TwoSided"))
    translucent = params.get("IsTranslucent", d.get("IsTranslucent"))
    out["IsTranslucent"] = bool(translucent) if translucent is not None else out["BlendMode"] == 2
    return out


def legacy_material(raw):
    """Any material export -> the shape the scripts expect (see the module docstring).  Never raises for odd values."""
    item = raw
    if isinstance(raw, list):
        item = next((i for i in raw if isinstance(i, dict) and ("Properties" in i or "Textures" in i)), raw[0] if raw and isinstance(raw[0], dict) else {})
    if not isinstance(item, dict):
        item = {}
    data = _from_property_list(item) if ("Properties" in item and "Textures" not in item and "Parameters" not in item
                                         and any(k in (item.get("Properties") or {}) for k in ("TextureParameterValues", "ScalarParameterValues", "VectorParameterValues"))) \
        else _from_dict(item)
    parameters = {"Scalars": data["Scalars"], "Colors": data["Colors"], "Switches": data["Switches"],
                  "IsTranslucent": data["IsTranslucent"], "BlendMode": data["BlendMode"], "Properties": {"TwoSided": data["TwoSided"]}}
    result = {"Textures": data["Textures"], "Parameters": parameters}
    result.update({"Scalars": data["Scalars"], "Colors": data["Colors"], "Switches": data["Switches"], "IsTranslucent": data["IsTranslucent"],
                   "BlendMode": data["BlendMode"], "TwoSided": data["TwoSided"]})
    return result


def parent_name(raw):
    """Name of the parent material of a delta instance ('MIM_Simple_01'), or None."""
    item = raw[0] if isinstance(raw, list) and raw and isinstance(raw[0], dict) else raw
    props = item.get("Properties") if isinstance(item, dict) else None
    parent = props.get("Parent") if isinstance(props, dict) else None
    if isinstance(parent, dict) and parent.get("ObjectName"):
        return re.sub(r".*'(.+)'.*", r"\1", parent["ObjectName"])
    return None


def inherit_parents(raw, legacy, base_path, find, max_depth=8):
    """
    A delta instance lists only what differs from its parent (MI_* -> MIM_* -> master M_*).  Returns (legacy with the parents' values underneath
    the material's own, master name or None, [parent names that were found], [parent names that were not exported]).
    """
    found, missing, master = [], [], None
    chain = [legacy]
    seen = set()
    name = parent_name(raw)
    while name and len(found) + len(missing) < max_depth and name.lower() not in seen:
        seen.add(name.lower())
        if name.startswith("M_"):                  # a master: its parameter tables are only defaults, there is nothing to merge
            master = name
            break
        path = find(name, base_path)
        if not path:
            missing.append(name)
            break
        try:
            praw = read_json(path)
        except Exception:
            missing.append(name)
            break
        chain.append(legacy_material(praw))
        found.append(name)
        name = parent_name(praw)
    if len(chain) == 1:
        return legacy, master, found, missing
    merged = {"Textures": {}, "Scalars": {}, "Colors": {}, "Switches": {}}
    for layer in reversed(chain):                  # farthest parent first, the material itself last
        for key in merged:
            merged[key].update(layer.get(key) or {})
    out = dict(legacy)
    out.update(merged)
    params = dict(legacy["Parameters"])
    params.update({"Scalars": merged["Scalars"], "Colors": merged["Colors"], "Switches": merged["Switches"]})
    out["Parameters"] = params
    for layer in chain[1:]:                        # blend mode / two-sided / translucent: the nearest parent that is not the default
        for key in ("BlendMode", "IsTranslucent", "TwoSided"):
            if not out.get(key) and layer.get(key):
                out[key] = layer[key]
    return out, master, found, missing


def read_json(path):
    with open(path, "r", encoding="utf-8") as f:       # the default encoding of open() is cp1252 on Windows
        return json.load(f)


# ---------------------------------------------------------------------------------------------------------------------------------
# Finding files
# ---------------------------------------------------------------------------------------------------------------------------------

def _store():
    try:
        import bpy
        ns = bpy.app.driver_namespace
    except Exception:
        ns = _FALLBACK
    return ns.setdefault("dbd_matio_index", {})


_FALLBACK = {}
REFRESH_AFTER_MISS_SECONDS = 20.0


class FileIndex(object):
    """Every file with one of the extensions under `base`, by lower-case file stem (built once, kept between runs)."""

    def __init__(self, base, extensions):
        self.base, self.extensions = base, tuple(extensions)
        self.built = 0.0
        self.by_stem = {}
        self.build()

    def build(self):
        by_stem, unreadable = {}, []
        # a folder Windows will not open (most often a path past 260 characters when long paths are off) would otherwise be skipped without a word
        for dirpath, _dirs, files in os.walk(self.base, onerror=lambda e: unreadable.append(getattr(e, "filename", None) or str(e))):
            for f in files:
                stem, ext = os.path.splitext(f)
                if ext.lower() in self.extensions:
                    by_stem.setdefault(stem.lower(), []).append(os.path.join(dirpath, f))
        self.by_stem, self.built, self.unreadable = by_stem, time.time(), unreadable

    def get(self, stem):
        return self.by_stem.get(stem.lower(), [])


def file_index(base, extensions):
    key = (os.path.normcase(os.path.abspath(base)), tuple(extensions))
    store = _store()
    if key not in store:
        store[key] = FileIndex(base, extensions)
    return store[key]


def search_report(base_path):
    """Lines explaining where material JSONs were looked for, for a run that could not find some."""
    idx = file_index(base_path, (".json",))
    base = os.path.abspath(base_path)
    lines = ["Searched for material JSONs under: %s (%d JSON files)" % (base, sum(len(v) for v in idx.by_stem.values()))]
    if not os.path.isdir(base):
        lines.append("  That folder does not exist: pick FModel's Output Directory as the Exports Folder.")
        return lines
    # the game's shared materials, not a plugin's own Content/Materials
    shared = any("/content/materials/instances/" in p.replace("\\", "/").lower() and "/plugins/" not in p.replace("\\", "/").lower()
                 for paths in idx.by_stem.values() for p in paths)
    if not shared:
        lines.append("  No Content/Materials folder under it.  Most materials, the realm plugins' (Liminal's) included, live in Content/Materials: "
                     "pick the folder that holds DeadByDaylight, or export the meshes again so their materials come with them.")
    full = [os.path.abspath(os.path.join(base, f)) for f in idx.unreadable]
    for folder in full[:5]:
        if len(folder) >= 240:
            lines.append("  Could not open %s (%d characters).  Windows limits paths to 260 characters unless long paths are turned on: "
                         "use a shorter FModel output folder, such as C:\\FModel\\Exports." % (folder, len(folder)))
        else:
            lines.append("  Could not open %s (no permission to read it?)" % folder)
    if len(idx.unreadable) > 5:
        lines.append("  ... and %d more folders could not be opened" % (len(idx.unreadable) - 5))
    return lines


def refresh_indexes():
    """Forget the cached file indexes (new files were exported since the add-on last looked)."""
    _store().clear()


def newest(paths):
    """The most recently modified of several copies of the same file (path order breaks a tie, so the choice is stable)."""
    paths = list(paths)
    if not paths:
        return None

    def mtime(p):
        try:
            return os.path.getmtime(p)
        except OSError:
            return 0.0
    return min(paths, key=lambda p: (-mtime(p), os.path.normcase(p)))


_DUPLICATE_SUFFIX = re.compile(r"\.\d{3,}$")          # Blender's 'MI_Name.001'


def game_path(path):
    """The part of an exported file's path the game knows ('Content/Materials/Instances/X/MI_A'), the same for its Models and Properties copies."""
    parts = re.split(r"[\/]+", os.path.splitext(path)[0])
    low = [x.lower() for x in parts]
    for marker in ("content", "plugins"):
        if marker in low:
            i = len(low) - 1 - low[::-1].index(marker)
            return "/".join(parts[i:]).lower()
    return "/".join(parts[-4:]).lower()


def _usda_reference(mesh_name, material_name, base_path):
    """The game path of the material the mesh's exported .usda binds (FModel writes it next to the mesh), or None."""
    for usda in file_index(base_path, (".usda",)).get(mesh_name):
        try:
            with open(usda, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except OSError:
            continue
        for ref in re.findall(r"references\s*=\s*@([^@]+)@", text):
            if os.path.splitext(os.path.basename(ref))[0].lower() == material_name.lower():
                return game_path(os.path.normpath(os.path.join(os.path.dirname(usda), ref)))
    return None


def pick_for_mesh(hits, material_name, mesh_name, base_path):
    """
    Several assets of the game share a material name (29: an old copy left in Materials/Instances beside the one in its realm's folder, or two
    realms' own).  The one the mesh uses: the one its .usda names when that was exported, else the one whose folders match the mesh's own
    (a mesh in Industrial/Structures takes Instances/Industrial/Structures), else the newest.
    """
    groups = {}
    for h in hits:
        groups.setdefault(game_path(h), []).append(h)
    if len(groups) < 2 or not mesh_name:
        return newest(hits)
    want = _usda_reference(mesh_name, material_name, base_path)
    if want in groups:
        return newest(groups[want])
    meshes = file_index(base_path, MESH_EXTENSIONS).get(mesh_name)
    if meshes:
        folders = set(game_path(meshes[0]).split("/")[:-1]) - GENERIC_FOLDERS
        score = {g: len(folders & set(g.split("/")[:-1])) for g in groups}
        best = max(score.values())
        top = [g for g in groups if score[g] == best]
        if best and len(top) == 1:
            return newest(groups[top[0]])
    return newest(hits)


MESH_EXTENSIONS = (".pskx", ".psk", ".uemodel")
GENERIC_FOLDERS = {"content", "plugins", "realms", "meshes", "materials", "instances", "environment", "textures", "master_instances"}


def find_material_json(material_name, base_path, log=print, mesh_name=None):
    """<material_name>.json anywhere under base_path (case-insensitive, ignoring Blender's .001 suffix); the newest copy if there are several."""
    if not material_name:
        return None
    names = [material_name]
    stripped = _DUPLICATE_SUFFIX.sub("", material_name)
    if stripped != material_name:
        names.append(stripped)
    idx = file_index(base_path, (".json",))
    for attempt in (0, 1):
        for n in names:
            hits = idx.get(n)
            if hits:
                return pick_for_mesh(hits, n, mesh_name, base_path)
        if attempt == 0 and time.time() - idx.built > REFRESH_AFTER_MISS_SECONDS:
            idx.build()                         # not found: look again once in case it was exported after the index was built
        else:
            break
    if len(material_name) >= 60:                  # .psk / .pskx cut material names at 64 characters: take the one file that starts with the name
        starts = [k for k in idx.by_stem if k.startswith(material_name.lower())]
        if len(starts) == 1:
            return newest(idx.by_stem[starts[0]])
    log("Material JSON not found for: %s" % material_name)
    return None


def texture_candidates(ref):
    """Folders (relative to the export root) where the file of an Unreal asset path may sit, most specific first."""
    rel = re.sub(r"\.[^./\\]*$", "", ref.strip().strip("/").replace("\\", "/"))     # drop '.Name' / '.0'
    parts = [p for p in rel.split("/") if p]
    if not parts:
        return []
    mount, tail = parts[0], "/".join(parts[1:])
    out = ["/".join(parts)]
    if tail:
        out += ["DeadByDaylight/Content/" + tail, "Content/" + tail, tail, "Exports/DeadByDaylight/Content/" + tail,
                mount + "/Content/" + tail, "DeadByDaylight/Plugins/Realms/%s/Content/%s" % (mount, tail),
                "Plugins/Realms/%s/Content/%s" % (mount, tail), "Plugins/%s/Content/%s" % (mount, tail)]
    seen, result = set(), []
    for c in out:
        if c.lower() not in seen:
            seen.add(c.lower())
            result.append(c)
    return result


def find_texture_file(ref, base_path, extensions=TEXTURE_EXTENSIONS):
    """
    The texture file for an Unreal asset path ('/Game/Meshes/X/T_Name.T_Name'): the path under the export root in every layout the exports
    have used (Game/..., DeadByDaylight/Content/..., <mount>/Content/..., plugin folders), the newest copy if several exist, and as a last
    resort the file with that name anywhere under the export root.
    """
    if not ref:
        return None
    found = []
    for rel in texture_candidates(ref):
        for ext in extensions:
            p = os.path.join(base_path, *rel.split("/")) + ext
            if os.path.isfile(p):
                found.append(p)
    if found:
        return newest(found)
    stem = os.path.basename(re.sub(r"\.[^./\\]*$", "", ref.strip().replace("\\", "/")))
    idx = file_index(base_path, extensions)
    hits = idx.get(stem)
    if not hits:
        return None
    want = [p.lower() for p in re.sub(r"\.[^./\\]*$", "", ref.strip().strip("/").replace("\\", "/")).split("/")[1:-1]]

    def overlap(path):          # how many of the asset's folders the file's folders share, from the file outward
        have = [p.lower() for p in os.path.dirname(path).replace("\\", "/").split("/")]
        n = 0
        for a, b in zip(reversed(have), reversed(want)):
            if a != b:
                break
            n += 1
        return n
    best = max(overlap(p) for p in hits)
    return newest([p for p in hits if overlap(p) == best])


def load_texture_image(ref, base_path, bpy_module, log=print):
    """
    Blender image for an Unreal asset path, reusing one already loaded.  Images are named '<texture>.png' like the scripts expect
    ('<texture>.tga' for a tga file).  None if the file can't be found.
    """
    if not ref:
        return None
    stem = os.path.basename(re.sub(r"\.[^./\\]*$", "", ref.strip().replace("\\", "/")))
    images = bpy_module.data.images
    for ext in TEXTURE_EXTENSIONS:
        if stem + ext in images:
            return images[stem + ext]
    path = find_texture_file(ref, base_path)
    if not path:
        return None
    return images.load(filepath=path)


# ---------------------------------------------------------------------------------------------------------------------------------
# Run summary
# ---------------------------------------------------------------------------------------------------------------------------------

class RunLog(object):
    """What a run did: counted per material, printed once at the end."""

    def __init__(self):
        self.built, self.failed, self.no_json, self.missing_textures = [], {}, [], {}
        self.meshes = {}                   # material -> {mesh name: how many objects use it there}

    def ok(self, name):
        self.built.append(name)

    def error(self, name, exc):
        self.failed[name] = "%s: %s" % (type(exc).__name__, exc)

    def no_json_for(self, name):
        if name not in self.no_json:
            self.no_json.append(name)

    def used_on(self, material, mesh):
        if mesh:
            uses = self.meshes.setdefault(material, {})
            uses[mesh] = uses.get(mesh, 0) + 1

    def where(self, material, limit=6):
        """'on SM_A x3, SM_B and 4 more meshes', most used first: which meshes need this material."""
        uses = sorted(self.meshes.get(material, {}).items(), key=lambda kv: (-kv[1], kv[0]))
        if not uses:
            return ""
        names = ", ".join(("%s x%d" % u) if u[1] > 1 else u[0] for u in uses[:limit])
        more = len(uses) - limit
        return "  (on %s%s)" % (names, " and %d more mesh%s" % (more, "" if more == 1 else "es") if more > 0 else "")

    def texture_missing(self, material, ref):
        self.missing_textures.setdefault(ref, []).append(material)

    def summary(self, printer=print):
        printer("=" * 70)
        printer("Materials built: %d | failed: %d | no JSON found: %d | textures not found: %d" % (
            len(self.built), len(self.failed), len(self.no_json), len(self.missing_textures)))
        for name, why in self.failed.items():
            printer("  FAILED   %s  ->  %s" % (name, why))
        for name in self.no_json:
            printer("  NO JSON  %s%s" % (name, self.where(name)))
        for ref, mats in sorted(self.missing_textures.items())[:40]:
            printer("  NO TEXTURE FILE  %s  (used by %s)" % (ref, ", ".join(sorted(set(mats))[:3])))
        if len(self.missing_textures) > 40:
            printer("  ... and %d more missing textures" % (len(self.missing_textures) - 40))
        printer("=" * 70)
        return {"built": len(self.built), "failed": len(self.failed), "no_json": len(self.no_json),
                "missing_textures": len(self.missing_textures)}
