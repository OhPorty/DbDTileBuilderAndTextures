"""
Script 1 - Tile / child actor build.

Run after the child blueprints (candles, corpses, mist, buildings, ...) have been built with Script 2.
For every ChildActorComponent of the tile JSON it makes sure there is an empty at the exact resolved
transform (SCS hierarchy + inherited TileBase01 / BP_BaseEscapeTile containers) and puts a fresh
instanced copy of the child blueprint in it - one copy per component, so a blueprint used 20 times is
placed 20 times.  Safe to re-run: existing copies are replaced.
"""
import bpy

from . import dbd_blender
from . import dbd_core
def main(context):
    props = context.scene.json_importer_gui_props
    json_path = bpy.path.abspath(props.json_file_path_1)
    if not json_path:
        print("Script 1: no Tile JSON selected.")
        return

    bp = dbd_core.load_blueprint(json_path, find=dbd_blender.BlueprintLocator(props.model_base_path).find)
    print("Placing child actors of %s (%d ChildActorComponents)" % (bp.class_name, len(bp.child_actor_placements())))

    report = dbd_blender.Report()
    for w in bp.warnings:
        report.warnings.append("%s: %s" % (bp.class_name, w))

    main_empty = dbd_blender.find_blueprint_root(bp.class_name)
    if main_empty is None or not main_empty.get("dbd_owner"):
        # Tile geometry hasn't been built with Script 2 yet: create just the container for the child actors.
        main_empty = dbd_blender.make_main_empty(bp.class_name)
        report.warnings.append("%s had not been built with Script 2 - only its child actors were created" % bp.class_name)

    if props.auto_build_children:
        locator = dbd_blender.BlueprintLocator(props.model_base_path)
        ctx = dbd_blender.BuildContext(props.model_base_path, report, props.hide_hidden_in_game, locator,
                                       **dbd_blender.options_from_props(props))
        ctx.in_progress.add(bp.class_name)
        dbd_blender.ensure_child_blueprints(bp, ctx)

    opts = dbd_blender.options_from_props(props)
    dbd_blender.populate_child_actors(bp, main_empty, report, seed=opts["seed"], spawn_scene=opts["spawn_scene"],
                                      gameplay=opts["gameplay"])
    dbd_blender.organize_build(main_empty, bp.class_name, bp.class_name.removesuffix("_C"))
    report.print_summary("Child actors: %s" % bp.class_name)
    print("Script executed successfully.")
