"""
Script 5 - Import a map, tile or level FModel exported as a USD scene (.usda).

FModel places everything by the game's own rules; the meshes come from the normal export.  See dbd_usd.
"""
import bpy

from . import dbd_blender
from . import dbd_usd


def main(context):
    props = context.scene.json_importer_gui_props
    path = bpy.path.abspath(props.json_file_path_5)
    if not path:
        print("Script 5: no FModel scene selected.")
        return
    report = dbd_blender.Report()
    ctx = dbd_blender.BuildContext(props.model_base_path, report, props.hide_hidden_in_game, None, **dbd_blender.options_from_props(props))
    main_empty, owner, name = dbd_usd.import_scene(path, ctx)
    dbd_blender.organize_build(main_empty, owner, name)
    dbd_blender.match_game_exposure(context.scene, ctx)
    report.print_summary("FModel scene: %s" % name)
    print("Script executed successfully.")
