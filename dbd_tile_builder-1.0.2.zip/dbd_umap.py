"""
A .umap export as data: its actors, their components, each component's place in the world and the levels it streams in.  No Blender here: dbd_blender
builds what this reads.

An object reference in a level file ends in the object's position in the file ("/Game/Maps/LobbySaturn.304" is entry 304).  A component placed by a blueprint
only stores what the level changed, so the rest of its transform comes from the blueprint: see Level.set_defaults.
"""
import json
import os

from . import dbd_core

IDENTITY = ((1.0, 0.0, 0.0, 0.0), (0.0, 1.0, 0.0, 0.0), (0.0, 0.0, 1.0, 0.0), (0.0, 0.0, 0.0, 1.0))

# A level streaming in more than this is a hub that swaps themes in and out (OnlineLobby has 56): built together they would stack up.
HUB_LEVEL_COUNT = 8


class Level(object):
    def __init__(self, path):
        self.path = path
        self.name = os.path.splitext(os.path.basename(path))[0]
        with open(path, encoding="utf-8-sig") as f:
            self.items = json.load(f)
        self.level = next((i for i in self.items if isinstance(i, dict) and i.get("Type") == "Level"), None)
        if self.level is None:
            raise ValueError("%s is not a level. Tiles and blueprints go through Single Tile or Blueprint." % os.path.basename(path))
        self.package = str((self.level.get("Outer") or {}).get("ObjectPath") or "").rpartition(".")[0]
        self.defaults = {}
        self._world = {}
        self._components = {}
        for item in self.items:
            owner = self.get(item.get("Outer")) if isinstance(item, dict) else None
            if owner is not None:
                self._components.setdefault(id(owner), []).append(item)

    def get(self, ref):
        """The entry a reference points to, or None when it is empty or lives in another file."""
        if not isinstance(ref, dict):
            return None
        package, _, index = str(ref.get("ObjectPath") or "").rpartition(".")
        if package != self.package or not index.isdigit() or int(index) >= len(self.items):
            return None
        return self.items[int(index)]

    def actors(self):
        return [a for a in (self.get(r) for r in self.level.get("Actors") or []) if isinstance(a, dict)]

    def components(self, actor):
        return self._components.get(id(actor), [])

    @staticmethod
    def props(item):
        return item.get("Properties") or {}

    def root(self, actor):
        return self.get(self.props(actor).get("RootComponent"))

    def set_defaults(self, component, props):
        """What the blueprint says about this component.  The level's own values go on top."""
        self.defaults[id(component)] = props
        self._world.clear()

    def merged(self, component):
        return dict(self.defaults.get(id(component)) or {}, **self.props(component))

    def local(self, component):
        return dbd_core.local_matrix_ue(self.merged(component))

    def parent(self, component):
        return self.get(self.props(component).get("AttachParent"))

    def world(self, component):
        """The component's transform in the level (Unreal space)."""
        key = id(component)
        if key not in self._world:
            chain, seen, at = [], set(), component
            while at is not None and id(at) not in seen and id(at) not in self._world:
                seen.add(id(at))
                chain.append(at)
                at = self.parent(at)
            base = self._world.get(id(at), IDENTITY) if at is not None else IDENTITY
            for link in reversed(chain):
                base = dbd_core.mat_mul(base, self.local(link))
                self._world[id(link)] = base
        return self._world[key]

    def actor_space(self, component, root):
        """The component's transform relative to its actor's root, which is how a built blueprint places it."""
        matrix, seen, at = IDENTITY, set(), component
        while at is not None and at is not root and id(at) not in seen:
            seen.add(id(at))
            matrix = dbd_core.mat_mul(self.local(at), matrix)
            at = self.parent(at) or root
        return matrix

    def streamed(self):
        """[(world asset path, transform)] of the levels this one streams in."""
        out = []
        for item in self.items:
            if isinstance(item, dict) and str(item.get("Type") or "").startswith("LevelStreaming"):
                p = self.props(item)
                asset = (p.get("WorldAsset") or {}).get("AssetPathName")
                if asset:
                    moved = p.get("LevelTransform")
                    out.append((asset, dbd_core.instance_matrix_ue(moved) if moved else IDENTITY))
        return out


def class_path(actor):
    """Asset path of a blueprint actor's class: "BlueprintGeneratedClass'/Game/.../BP_X.BP_X_C'" -> '/Game/.../BP_X.BP_X_C'."""
    text = str(actor.get("Class") or "")
    return text.split("'")[1] if text.count("'") >= 2 else None


def _level_file(asset, near):
    """The export of a streamed level, in the export the chosen level came from."""
    root = near.replace("\\", "/").split("/DeadByDaylight/")[0]
    for relative in dbd_core.export_path_candidates(asset.rsplit(".", 1)[0]):
        candidate = "%s/%s.json" % (root, relative)
        if os.path.isfile(candidate):
            return candidate
    sibling = os.path.join(os.path.dirname(near), asset.rsplit(".", 1)[-1] + ".json")
    return sibling if os.path.isfile(sibling) else None


def load_levels(path, follow=True):
    """
    [(Level, transform)], the chosen level first, then what it streams in, and notes on what was left out.  Only the level that is opened decides what streams in:
    a sub-level's own list is for opening that level by itself.  A hub is built alone.
    """
    first = Level(path)
    levels, notes = [(first, IDENTITY)], []
    if not follow:
        return levels, notes
    streamed = first.streamed()
    if len(streamed) > HUB_LEVEL_COUNT:
        notes.append("%s switches between %d levels: its sub-levels were left out. Pick the one you want from the Maps folder." % (first.name, len(streamed)))
        return levels, notes
    seen = {first.name.lower()}
    for asset, moved in streamed:
        name = asset.rsplit(".", 1)[-1]
        if name.lower() in seen:
            continue
        seen.add(name.lower())
        found = _level_file(asset, path)
        if not found:
            notes.append("sub-level %s is not in the export" % name)
            continue
        try:
            levels.append((Level(found), moved))
        except (OSError, ValueError) as exc:
            notes.append("sub-level %s could not be read: %s" % (name, exc))
    return levels, notes
