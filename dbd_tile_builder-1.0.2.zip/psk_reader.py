"""
Fast static-mesh reader for Unreal .psk / .pskx files (UModel / ActorX export).  No bpy dependency - returns
NumPy arrays that dbd_blender turns into a Blender mesh with foreach_set (no operators, no selection).

Only what a static mesh needs is read: points, wedges (UV + material), faces, materials, vertex normals,
vertex colours and extra UV sets.  Skeleton / weight chunks are skipped (the builder never imported bones).

Layout (chunk = 32-byte header  <20s id><i type><i item size><i item count>  followed by the items)
    PNTS0000   3 x float32                       point positions (Unreal cm)
    VTXW0000/3200  uint32 point, f32 u, f32 v, u8 material, 3 pad     wedges = per-face-corner vertex data
    FACE0000   3 x uint16 wedge, u8 material, u8 aux, u32 smoothing   (FACE3200: uint32 wedge indices)
    MATT0000   64-byte material name + 24 bytes
    VTXNORMS   3 x float32 per point
    VERTEXCO.. 4 x uint8 per wedge
    EXTRAUVS.. 2 x float32 per wedge (one chunk per extra UV set)

The mesh is returned the way the Blender importer builds it: positions scaled by 0.01, each face's corners
ordered (wedge2, wedge1, wedge3) to flip the winding, v flipped (1 - v).
"""
import struct

import numpy as np

HEADER = struct.Struct("<20s3i")
SCALE_DOWN = 0.01


class PskError(Exception):
    pass


class PskMesh(object):
    __slots__ = ("positions", "faces", "uvs", "material_index", "materials", "normals",
                 "vertex_colors", "extra_uvs", "name")

    @property
    def vertex_count(self):
        return len(self.positions)

    @property
    def face_count(self):
        return len(self.faces)


def _chunk_id(raw):
    return raw.split(b"\0", 1)[0].decode("latin-1")[:8]


def _srgb_lut():
    c = np.arange(256, dtype=np.float64) / 255.0
    return np.where(c < 0.0031308, c * 12.92, 1.055 * np.power(np.maximum(c, 0.0), 1.0 / 2.4) - 0.055).astype(np.float32)


_SRGB = None


def read_psk(path, scale_down=True, to_srgb=True):
    with open(path, "rb") as f:
        data = f.read()
    return parse_psk(data, scale_down, to_srgb)


def parse_psk(data, scale_down=True, to_srgb=True):
    n = len(data)
    pos = 0
    chunks = {}
    extra = []
    first = True
    while pos + 32 <= n:
        raw_id, _type, size, count = HEADER.unpack_from(data, pos)
        cid = _chunk_id(raw_id)
        if first:
            if not cid.startswith("ACTRHEAD"):
                raise PskError("not a psk/pskx file (first chunk %r)" % cid)
            first = False
        body = pos + 32
        end = body + size * count
        if end > n:
            raise PskError("chunk %s is truncated" % cid)
        if cid == "EXTRAUVS":
            extra.append((body, size, count))
        else:
            chunks.setdefault(cid, (body, size, count))
        pos = end
    if first:
        raise PskError("empty file")

    def need(*names):
        for nm in names:
            if nm in chunks:
                return chunks[nm]
        raise PskError("missing %s chunk" % "/".join(names))

    # ---- points
    body, size, count = need("PNTS0000")
    pts = np.frombuffer(data, dtype="<f4", count=count * 3, offset=body).reshape(count, 3).astype(np.float32)
    if scale_down:
        pts = pts * np.float32(SCALE_DOWN)

    # ---- wedges
    body, size, count = need("VTXW0000", "VTXW3200")
    wdt = np.dtype({"names": ["p", "u", "v", "m"], "formats": ["<u4", "<f4", "<f4", "u1"],
                    "offsets": [0, 4, 8, 12], "itemsize": size})
    wedges = np.frombuffer(data, dtype=wdt, count=count, offset=body)
    w_point = wedges["p"].astype(np.int64)
    w_u = wedges["u"].astype(np.float32)
    w_v = np.float32(1.0) - wedges["v"].astype(np.float32)

    # ---- faces
    body, size, count = need("FACE0000", "FACE3200")
    idx_fmt = "<u4" if size >= 16 else "<u2"
    fdt = np.dtype({"names": ["a", "b", "c", "m"], "formats": [idx_fmt, idx_fmt, idx_fmt, "u1"],
                    "offsets": [0, np.dtype(idx_fmt).itemsize, 2 * np.dtype(idx_fmt).itemsize, 3 * np.dtype(idx_fmt).itemsize],
                    "itemsize": size})
    fc = np.frombuffer(data, dtype=fdt, count=count, offset=body)
    w1, w2, w3 = fc["a"].astype(np.int64), fc["b"].astype(np.int64), fc["c"].astype(np.int64)
    if count and (max(w1.max(), w2.max(), w3.max()) >= len(wedges)):
        raise PskError("face refers to a missing wedge")
    # corner order (wedge2, wedge1, wedge3) - reverses the winding for Blender
    corner_w = np.stack([w2, w1, w3], axis=1)                  # (F, 3) wedge indices
    faces = w_point[corner_w]                                  # (F, 3) point indices
    uvs = np.stack([w_u[corner_w], w_v[corner_w]], axis=2)     # (F, 3, 2)
    if count and faces.max() >= len(pts):
        raise PskError("face refers to a missing point")

    mesh = PskMesh()
    mesh.positions = pts
    mesh.faces = faces.astype(np.int32)
    mesh.uvs = uvs.reshape(-1, 2).astype(np.float32)
    mesh.material_index = fc["m"].astype(np.int32)

    # ---- materials
    mesh.materials = []
    if "MATT0000" in chunks:
        body, size, count = chunks["MATT0000"]
        for i in range(count):
            raw = data[body + i * size: body + i * size + 64]
            mesh.materials.append(raw.split(b"\0", 1)[0].decode("latin-1"))

    # ---- vertex normals (per point)
    mesh.normals = None
    if "VTXNORMS" in chunks:
        body, size, count = chunks["VTXNORMS"]
        if count == len(pts):
            mesh.normals = np.frombuffer(data, dtype="<f4", count=count * 3, offset=body).reshape(count, 3).astype(np.float32)

    # ---- vertex colours: wedge colour, last wedge of a point wins, expanded to face corners
    mesh.vertex_colors = None
    cid = next((k for k in chunks if k.startswith("VERTEXCO")), None)
    if cid:
        body, size, count = chunks[cid]
        cols = np.frombuffer(data, dtype="u1", count=count * 4, offset=body).reshape(count, 4)
        if count == len(wedges):
            # the importer loops over wedges so the LAST wedge of a point wins; do that deterministically
            per_point = np.full((len(pts), 4), -1, dtype=np.int16)
            _, first_in_reversed = np.unique(w_point[::-1], return_index=True)
            last_wedge = len(w_point) - 1 - first_in_reversed
            per_point[np.unique(w_point)] = cols[last_wedge]
            corner_cols = per_point[faces.reshape(-1)]
            rgba = np.ones((len(corner_cols), 4), dtype=np.float32)
            have = corner_cols[:, 0] >= 0
            c = corner_cols[have].astype(np.int32)
            if to_srgb:
                global _SRGB
                if _SRGB is None:
                    _SRGB = _srgb_lut()
                rgba[have, :3] = _SRGB[c[:, :3]]
            else:
                rgba[have, :3] = c[:, :3] / 255.0
            rgba[have, 3] = c[:, 3] / 255.0
            mesh.vertex_colors = rgba

    # ---- extra UV sets (indexed by wedge)
    mesh.extra_uvs = []
    for body, size, count in extra:
        if count != len(wedges):
            continue
        e = np.frombuffer(data, dtype="<f4", count=count * 2, offset=body).reshape(count, 2)
        eu, ev = e[:, 0].astype(np.float32), np.float32(1.0) - e[:, 1].astype(np.float32)
        mesh.extra_uvs.append(np.stack([eu[corner_w], ev[corner_w]], axis=2).reshape(-1, 2).astype(np.float32))
    mesh.name = ""
    return mesh
