"""
Dead by Daylight's procedural map generation, from the exported game data.

A Python port of the procedural map code in CUE4Parse (GameTypes/DBD/Objects/ProceduralMaps, https://github.com/FabianFG/CUE4Parse, Apache License 2.0),
whose authors worked the rules out from the game.  The original names are kept so the two can be compared.  One seed feeds a separate random stream
per job, as in the game.

plan_map() needs the game's tables in the export (LevelGen_ThemePropertiesDB and GameTypeModifierDefaults) and raises Unavailable without them; Script 4
then uses dbd_map.plan_map, the add-on's own planner.
"""
import json
import math
import os
import re
import struct

from . import dbd_core
from . import dbd_map

# EProceduralRandomStream: which job a stream belongs to
STREAM_DEFAULT, STREAM_TILE_SELECTION, STREAM_QUADRANT_SELECTION = 0, 4, 7

TILE_NONE, TILE_BLOCKER, TILE_ANY = 0, 1, 2
TILE_TYPES = {"None": 0, "Blocker": 1, "Any": 2, "Forest": 3, "Building": 4, "Maze": 5, "Landmark": 6, "Signature": 7, "Basement": 8}
PATH_TYPES = {"None": 0, "Straight": 1, "DeadEnd": 2, "Corner": 3, "Crossroads": 4, "TJunction": 5, "OrientationOnly": 6, "Unspecified": 7, "OrientedCrossroads": 8}
DENSITIES = {"Unspecified": 0, "Light": 1, "Moderate": 2, "Heavy": 3, "Empty": 4, "Count": 5}

FLIP_DIAGONAL, FLIP_VERTICAL, FLIP_HORIZONTAL = 1, 2, 4
QUARTER_TURN_FLAGS = FLIP_DIAGONAL | FLIP_VERTICAL
OUTWARD_FLAGS = (0, 6, 3, 5)


class Unavailable(Exception):
    """The export does not hold what the game's generator needs."""


class RandomStream(object):
    """Unreal's FRandomStream, advanced 200 steps per stream index: DBD's way of getting several streams from one seed."""

    def __init__(self, seed, stream):
        self.seed = seed & 0xFFFFFFFF
        for _ in range(stream * 200):
            self.next_uint32()

    def next_uint32(self):
        self.seed = (196314165 * self.seed + 907633515) & 0xFFFFFFFF
        return self.seed

    def next_float(self):
        return (self.next_uint32() >> 9) / 8388608.0            # the 23 mantissa bits of a float in [1, 2), minus one


# ---------------------------------------------------------------------------------------------------------------------------------
# What is in the export
# ---------------------------------------------------------------------------------------------------------------------------------

TABLES = ("LevelGen_ThemePropertiesDB", "GameTypeModifierDefaults", "ProceduralGenerationData", "LevelGenerator", "ProceduralMaps", "ItemCamperCount")
SKIPPED_FOLDERS = {"textures", "meshes", "materials", "characters", "effects", "audio", "animations", "ui"}
_SCANS = {}
_TILES = {}


def asset_key(path):
    """The asset's place in the game, from 'DeadByDaylight/' on: the same asset exported twice has one key, and the keys sort like the game's own paths."""
    path = path.replace("\\", "/")
    at = path.find("DeadByDaylight/")
    return path[at:] if at >= 0 else path


def package_path(key):
    """DeadByDaylight/Content/Data/X.json -> /Game/Data/X,  .../Plugins/Realms/Realm_26Liminal/Content/Data/X.json -> /Realm_26Liminal/Data/X"""
    stem = key[:-5] if key.lower().endswith(".json") else key
    m = re.search(r"/Plugins/(?:.*/)?([^/]+)/Content/(.*)$", stem)
    if m:
        return "/%s/%s" % (m.group(1), m.group(2))
    m = re.search(r"/Content/(.*)$", stem)
    return "/Game/" + m.group(1) if m else stem


def scan(base):
    """{key: [paths]} of the tile blueprints and the generator's tables under the export folder."""
    base = os.path.abspath(base)
    if base not in _SCANS:
        tiles, tables = {}, {}
        for dirpath, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if d.lower() not in SKIPPED_FOLDERS]
            in_tiles = "/blueprints/tiles" in dirpath.replace("\\", "/").lower()
            for f in files:
                if not f.endswith(".json") or not (in_tiles or f[:-5] in TABLES):
                    continue
                path = os.path.join(dirpath, f)
                key = asset_key(path)
                if f[:-5] in TABLES:
                    tables.setdefault(f[:-5], {}).setdefault(key, []).append(path)
                if in_tiles:
                    tiles.setdefault(key, []).append(path)
        _SCANS[base] = (tiles, tables)
    return _SCANS[base]


# What the game's generator reads, and the folder of the export each comes from
REQUIRED_TABLES = (("LevelGen_ThemePropertiesDB", "Content/Data"), ("GameTypeModifierDefaults", "Content/Data"), ("ProceduralMaps", "Content/Data"),
                   ("ProceduralGenerationData", "Content/ProceduralLevelGeneration"), ("LevelGenerator", "Content/ProceduralLevelGeneration"),
                   ("ItemCamperCount", "Content/ProceduralLevelGeneration"))


def missing_tables(base):
    """[(table, folder)] of the generator's tables the export lacks.  The base game's own copy counts: a realm plugin's copy (Liminal has its own
    LevelGen_ThemePropertiesDB) does not stand in for it."""
    _tiles, tables = scan(base)
    missing = []
    for name, folder in REQUIRED_TABLES:
        game = [k for k in tables.get(name, {}) if "/plugins/" not in k.lower()]
        if not game:
            missing.append((name, folder))
    return missing


def read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def best_export(paths):
    return dbd_core.choose_export(paths) or paths[0]


def table_rows(tables, name):
    """Rows of every copy of a data table in /Data of the game and its plugins, in the game's order."""
    for key in sorted(tables.get(name, {})):
        pkg = package_path(key)
        if not re.match(r"/[^/]+/Data/", pkg):
            continue
        items = read_json(best_export(tables[name][key]))
        for item in items if isinstance(items, list) else [items]:
            rows = item.get("Rows") if isinstance(item, dict) else None
            if isinstance(rows, dict):
                yield from rows.items()


def resolve_tile_path(tables, map_package):
    """The realm's tile folder: the theme whose MapPath is part of the map's package path."""
    for _key, row in table_rows(tables, "LevelGen_ThemePropertiesDB"):
        map_path = row.get("MapPath") or ""
        if map_path and map_path.lower() in map_package.lower():
            return row.get("TilePath") or ""
    raise Unavailable("no theme in LevelGen_ThemePropertiesDB for %s" % map_package)


def escape_door_count(tables):
    for key in sorted(tables.get("GameTypeModifierDefaults", {})):
        for item in read_json(best_export(tables["GameTypeModifierDefaults"][key])):
            for entry in (item.get("Properties") or {}).get("Modifiers") or []:
                if entry.get("Key") == "EGameTypeModifierName::EscapeDoorCount":
                    return max(0, int((entry.get("Value") or {}).get("_intValue", 0)))
    raise Unavailable("GameTypeModifierDefaults is not in the export")


def class_super(text):
    """Name of the parent blueprint class ('BP_BaseEscapeTile_C') from a blueprint's raw JSON, or ''.  A native parent has no Super in the export."""
    m = re.search(r"\"Super\":\s*\{\s*\"ObjectName\":\s*\"BlueprintGeneratedClass'([^']+)'", text)
    return m.group(1) if m else ""


def is_escape_tile(text, tiles_by_name, depth=0):
    """True when the class or a parent up the chain derives from the game's native EscapeTile, which only shows as a reference in the export."""
    if "Class'EscapeTile'" in text:
        return True
    name = class_super(text)
    parent = tiles_by_name.get(name[:-2].lower()) if name.endswith("_C") and depth < 8 else None
    if not parent:
        return False
    with open(best_export(parent), "r", encoding="utf-8") as f:
        return is_escape_tile(f.read(), tiles_by_name, depth + 1)


def load_tile(key, paths, tiles_by_name):
    """A dbd_map.Tile with the fields the generator reads from the class defaults, or None when it is no tile."""
    path = best_export(paths)
    cached = _TILES.get(path)
    stamp = os.path.getmtime(path)
    if cached and cached[0] == stamp:
        return cached[1]
    stem = os.path.splitext(os.path.basename(path))[0]
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    items = json.loads(text)
    tile = None
    if isinstance(items, list):
        cdo = next((i for i in items if isinstance(i, dict) and i.get("Name") == "Default__%s_C" % stem), None)
        p = (cdo or {}).get("Properties") or {}
        kind = TILE_TYPES.get(str(p.get("Type", "None")).replace("ETileType::", ""), TILE_NONE)
        if cdo is not None and kind != TILE_NONE:
            dim = p.get("Dimension") or {}
            width, height = max(1, int(dim.get("X", 1))), max(1, int(dim.get("Y", 1)))
            type_name = str(p.get("Type")).replace("ETileType::", "")
            path_name = str(p.get("Path", "None")).replace("EPathType::", "")
            tile = dbd_map.Tile(stem, path, int(p.get("Number", 0) or 0), (width, height), type_name, path_name, int(p.get("MaximumCount", 0) or 0))
            tile.asset_key, tile.kind, tile.path_kind = key, kind, PATH_TYPES.get(path_name, 0)
            tile.width, tile.height = width, height
            tile.density = DENSITIES.get(str(p.get("Density", "Unspecified")).replace("EDensity::", ""), 0)
            tile.minimum_spacing = int(p.get("MinimumSpacing", 0) or 0)
            tile.weight = float(p.get("Weight", 1.0))
            tile.replacement = bool(p.get("Replacement", False))
            tile.is_escape = is_escape_tile(text, tiles_by_name)
    _TILES[path] = (stamp, tile)
    return tile


def load_tiles(all_tiles, tile_path):
    """Every tile blueprint under Blueprints/Tiles whose package path holds the theme's TilePath, in the game's order."""
    by_name = {}
    for key, paths in all_tiles.items():
        by_name[os.path.splitext(os.path.basename(key))[0].lower()] = paths
    tiles = []
    for key in sorted(all_tiles):
        if "/blueprints/tiles/" in key.lower() and tile_path.lower() in package_path(key).lower():
            tile = load_tile(key, all_tiles[key], by_name)
            if tile is not None:
                tiles.append(tile)
    return tiles


# ---------------------------------------------------------------------------------------------------------------------------------
# The map's cells
# ---------------------------------------------------------------------------------------------------------------------------------

class Cell(object):
    """FProceduralTileCell.  The numbers are one above the tile set index: 0 means empty."""
    __slots__ = ("type", "density", "path", "number", "flags", "tag", "quadrant_rotation")

    def __init__(self):
        self.type = self.density = self.path = self.number = self.flags = self.tag = self.quadrant_rotation = 0

    @property
    def rotation(self):
        return {3: 270, 5: 90, 6: 180}.get(self.flags, 0)


def load_cells(tilemap):
    layers = {name.lower(): grid for name, grid in tilemap.layers.items()}
    base = layers.get("base")
    if base is None:
        raise Unavailable("the map has no Base layer")
    height, width = len(base), len(base[0])
    cells = []
    # DBD reads room orientation from the optional sixth layer, whatever its name
    order = getattr(tilemap, "layer_order", None) or []
    rotations = tilemap.layers.get(order[5]) if len(order) > 5 else None

    def at(name, x, y):
        grid = layers.get(name)
        if grid is None or y >= len(grid) or x >= len(grid[y]):
            return None, 0
        return grid[y][x]

    for y in range(height):
        for x in range(width):
            cell = Cell()
            index, flags = at("base", x, y)
            if index is not None:
                cell.type, cell.flags = index + 1, flags >> 29
            index, flags = at("paths", x, y)
            if index is not None:
                cell.path, cell.flags = index + 1, flags >> 29
            index, _ = at("numbers", x, y)
            if index is not None:
                cell.number = index + 1
            index, _ = at("tags", x, y)
            if index is not None:
                cell.tag = index + 1
            index, _ = at("types", x, y)
            if index is not None:
                cell.density = index + 1
            if rotations is not None and y < len(rotations) and x < len(rotations[y]) and rotations[y][x][0] is not None:
                cell.quadrant_rotation = rotations[y][x][0] + 1
            cells.append(cell)
    return cells, width, height


# ---------------------------------------------------------------------------------------------------------------------------------
# Tiles
# ---------------------------------------------------------------------------------------------------------------------------------

class TilePlacement(object):
    """FProceduralTilePlacement"""
    __slots__ = ("tile", "x", "y", "flags")

    def __init__(self, tile, x, y, flags):
        self.tile, self.x, self.y, self.flags = tile, x, y, flags

    @property
    def width(self):
        return self.tile.height if self.flags & FLIP_DIAGONAL else self.tile.width

    @property
    def height(self):
        return self.tile.width if self.flags & FLIP_DIAGONAL else self.tile.height


def matches_density(tile, density):
    return density == 0 or tile.density == 0 or tile.density == density


def usable(tile):
    return tile.weight > 0.0 and tile.weight != float("inf")


class EscapeLayout(object):
    """FProceduralEscapeLayout"""

    def __init__(self, cells, width, height):
        self.cells, self.width, self.height = cells, width, height

    def kind(self, x, y):
        return self.cells[y * self.width + x].type if 0 <= x < self.width and 0 <= y < self.height else TILE_NONE

    def outward_flags(self, x, y):
        """The flags that face an exit out of the map, or None where no exit fits."""
        left, right = self.kind(x - 1, y), self.kind(x + 1, y)
        up, down = self.kind(x, y - 1), self.kind(x, y + 1)
        if left == TILE_BLOCKER and right == TILE_BLOCKER:
            if down > TILE_BLOCKER and up == TILE_NONE:
                return 0
            if up > TILE_BLOCKER and down == TILE_NONE:
                return 6
        elif up == TILE_BLOCKER and down == TILE_BLOCKER:
            if right > TILE_BLOCKER and left == TILE_NONE:
                return 3
            if left > TILE_BLOCKER and right == TILE_NONE:
                return 5
        return None

    def can_spawn(self, placement):
        if placement.x + placement.width > self.width or placement.y + placement.height > self.height:
            return False
        for y in range(placement.y, placement.y + placement.height):
            for x in range(placement.x, placement.x + placement.width):
                if self.outward_flags(x, y) == placement.flags:
                    return True
        return False

    def build(self, tiles, seed, count, existing):
        if count <= 0:
            return []
        escape_tiles = sorted((t for t in tiles if t.is_escape and t.width == 1 and t.height == 1 and usable(t)), key=lambda t: t.asset_key)
        candidates = []
        for y in range(self.height):
            for x in range(self.width):
                cell = self.cells[y * self.width + x]
                flags = self.outward_flags(x, y) if cell.type == TILE_BLOCKER else None
                if flags is None:
                    continue
                for tile in escape_tiles:
                    if (cell.number == 0 or tile.number == 0 or cell.number == tile.number) and cell.path == tile.path_kind and matches_density(tile, cell.density):
                        candidates.append(TilePlacement(tile, x, y, flags))

        def near(a, b):
            return max(abs(a.x - b.x), abs(a.y - b.y)) <= max(b.tile.minimum_spacing, a.tile.minimum_spacing)

        def inside(c, e):
            return e.x <= c.x < e.x + e.width and e.y <= c.y < e.y + e.height

        def over_limit(c, placed):
            return c.tile.max_count > 0 and sum(1 for p in placed if p.tile is c.tile) >= c.tile.max_count

        candidates = [c for c in candidates if not any(inside(c, e) or near(c, e) for e in existing) and not over_limit(c, existing)]
        random = RandomStream(seed, STREAM_TILE_SELECTION)
        result = []
        while len(result) < count and candidates:
            weight = random.next_float() * sum(c.tile.weight for c in candidates)
            selected = candidates[-1]
            for candidate in candidates:
                weight -= candidate.tile.weight
                if weight >= 0:
                    continue
                selected = candidate
                break
            result.append(selected)
            candidates = [c for c in candidates if not near(c, selected) and not over_limit(c, result + list(existing))]
        return result


class TileLayout(object):
    """FProceduralTileLayout: a greedy pass over the grid, each cell taking a weighted pick from the tiles that fit best."""

    def __init__(self, cells, width, height, tiles, seed, escape_doors):
        self.cells, self.width, self.height, self.tiles = cells, width, height, tiles
        self.seed, self.escape_doors = seed, escape_doors
        self.random = RandomStream(seed, STREAM_TILE_SELECTION)
        self.occupied = [False] * len(cells)
        self.placements = []
        self.by_tile = {}
        self.escapes = EscapeLayout(cells, width, height)

    def build(self):
        for y in range(self.height):
            for x in range(self.width):
                index = y * self.width + x
                cell = self.cells[index]
                if self.occupied[index] or cell.type == TILE_NONE:
                    continue
                placement = self.select_placement(cell, x, y)
                if placement is None:
                    raise Unavailable("no tile fits cell (%d, %d): type %d, path %d, number %d, density %d" % (x, y, cell.type, cell.path, cell.number, cell.density))
                self.add_placement(placement)

        # Escape generation replaces border tiles after the regular layout is selected
        missing = max(0, self.escape_doors - sum(1 for p in self.placements if p.tile.is_escape))
        for index, current in enumerate(self.placements):
            if missing <= 0:
                break
            if current.tile.is_escape:
                continue
            cell = self.cells[current.y * self.width + current.x]
            replacements = []
            for tile in self.tiles:
                if (tile.is_escape and tile.width * tile.height > 1 and tile.kind == current.tile.kind and tile.path_kind == current.tile.path_kind
                        and tile.number == current.tile.number and matches_density(tile, cell.density) and usable(tile)
                        and (tile.max_count <= 0 or sum(1 for p in self.placements if p.tile is tile) < tile.max_count)):
                    p = TilePlacement(tile, current.x, current.y, current.flags)
                    if p.width == current.width and p.height == current.height and self.escapes.can_spawn(p):
                        replacements.append(p)
            if replacements:
                replacements.sort(key=lambda p: p.tile.asset_key)
                self.placements[index] = self.select_weighted(replacements)
                missing -= 1

        existing = [p for p in self.placements if p.tile.is_escape]
        for escape in self.escapes.build(self.tiles, self.seed, max(0, self.escape_doors - len(existing)), existing):
            for index, p in enumerate(self.placements):
                if p.x == escape.x and p.y == escape.y and p.width == 1 and p.height == 1:
                    self.placements[index] = escape
                    break
        return self.placements

    def select_placement(self, cell, x, y):
        groups = {}
        for p in self.candidates(cell, x, y):
            key = (-p.width * p.height, p.tile.is_escape, p.tile.replacement, self.reached_count(p.tile), self.violates_spacing(p))
            groups.setdefault(key, []).append(p)
        if not groups:
            return None
        return self.select_weighted(sorted(groups[min(groups)], key=lambda p: p.tile.asset_key))

    def select_weighted(self, candidates):
        remaining = self.random.next_float() * sum(p.tile.weight for p in candidates)
        for candidate in candidates:
            if remaining < candidate.tile.weight:
                return candidate
            remaining -= candidate.tile.weight
        return candidates[-1]

    def candidates(self, cell, x, y):
        for tile in self.tiles:
            if tile.is_escape and (tile.path_kind == 0 or tile.number == 0):
                continue
            if not usable(tile) or (cell.type != TILE_ANY and tile.kind != cell.type) or not matches_density(tile, cell.density):
                continue
            if (cell.number != 0 and tile.number != cell.number) or tile.path_kind != cell.path:
                continue
            if tile.is_escape:
                for flags in OUTWARD_FLAGS:
                    escape = TilePlacement(tile, x, y, flags)
                    if self.escapes.can_spawn(escape) and self.can_place(escape, cell):
                        yield escape
                continue
            placement = TilePlacement(tile, x, y, cell.flags)
            if self.can_place(placement, cell):
                yield placement
            # An unoriented rectangular tile can also fit across the other grid axis
            if cell.path != 0 or cell.flags != 0 or tile.width == tile.height:
                continue
            rotated = TilePlacement(tile, x, y, QUARTER_TURN_FLAGS)
            if self.can_place(rotated, cell):
                yield rotated

    def can_place(self, placement, source):
        end_x, end_y = placement.x + placement.width, placement.y + placement.height
        if end_x > self.width or end_y > self.height:
            return False
        for y in range(placement.y, end_y):
            for x in range(placement.x, end_x):
                index = y * self.width + x
                if self.occupied[index]:
                    return False
                cell = self.cells[index]
                if (cell.type != source.type or not matches_density(placement.tile, cell.density) or cell.path != source.path
                        or cell.number != source.number or cell.flags != source.flags):
                    return False
        return True

    def reached_count(self, tile):
        return tile.max_count > 0 and len(self.by_tile.get(id(tile), ())) >= tile.max_count

    def violates_spacing(self, placement):
        return any(max(abs(p.x - placement.x), abs(p.y - placement.y)) <= placement.tile.minimum_spacing for p in self.by_tile.get(id(placement.tile), ()))

    def add_placement(self, placement):
        self.placements.append(placement)
        self.by_tile.setdefault(id(placement.tile), []).append(placement)
        for y in range(placement.y, placement.y + placement.height):
            for x in range(placement.x, placement.x + placement.width):
                self.occupied[y * self.width + x] = True


# ---------------------------------------------------------------------------------------------------------------------------------
# The add-on's plan
# ---------------------------------------------------------------------------------------------------------------------------------

def plan_map(tilemap, base, seed=1):
    """A dbd_map.Plan from the game's own rules.  Raises Unavailable when the export lacks what they need."""
    all_tiles, tables = scan(base)
    if not tables.get("LevelGen_ThemePropertiesDB") or not tables.get("GameTypeModifierDefaults"):
        raise Unavailable("the export has no LevelGen_ThemePropertiesDB / GameTypeModifierDefaults")
    tile_path = resolve_tile_path(tables, tilemap.package or tilemap.name)
    tiles = load_tiles(all_tiles, tile_path)
    if not tiles:
        raise Unavailable("no tile blueprints for theme path '%s'" % tile_path)
    cells, width, height = load_cells(tilemap)
    layout = TileLayout(cells, width, height, tiles, seed, escape_door_count(tables))
    placements = layout.build()
    placed = []
    for p in placements:
        yaw = dbd_map.yaw_from_flags(p.flags << 29)
        placed.append(dbd_map.Placed(p.tile, p.x, p.y, p.width, p.height, 0 if yaw is None else yaw, "border" if p.tile.kind == TILE_BLOCKER else "solved"))
    filled = [(x, y) for y in range(height) for x in range(width) if cells[y * width + x].type != TILE_NONE]
    bbox = (min(c[0] for c in filled), min(c[1] for c in filled), max(c[0] for c in filled), max(c[1] for c in filled))
    plan = dbd_map.Plan(tilemap, placed, [], bbox, "the game's generator, %d tiles available" % len(tiles))
    plan.game = GameMap(base, cells, width, height, placements, seed, tables)
    return plan


TILE_VARIATIONS = {1: "BlueTag", 2: "PinkTag", 3: "YellowTag", 4: "GreenTag", 5: "Empty"}


def cell_tag(plan, index):
    """The colour tag on the first cell of the plan's placement `index`: 'BlueTag', or None."""
    game = plan.game
    placement = game.placements[index]
    return TILE_VARIATIONS.get(game.cells[placement.y * game.width + placement.x].tag)


def tile_variations(blueprint, tag):
    """{component name: blueprint path} of what `tag` swaps in this tile."""
    out = {}
    for p in blueprint.placements:
        if p.type != "ActorVariationSpawner":
            continue
        for variation in p.props.get("Variations") or []:
            path = (variation.get("Element") or {}).get("AssetPathName") or ""
            if enum_tail(variation.get("Type")) == tag and path:
                out[p.name] = path
                break
    return out


class GameMap(object):
    """What the later stages of the generator need, kept on the Plan."""

    def __init__(self, base, cells, width, height, placements, seed, tables):
        self.base, self.cells, self.width, self.height = base, cells, width, height
        self.placements, self.seed, self.tables = placements, seed, tables


# ---------------------------------------------------------------------------------------------------------------------------------
# Rooms
# ---------------------------------------------------------------------------------------------------------------------------------

CORNER_TAGS = ("quadrant_bottomright", "quadrant_bottomleft", "quadrant_topleft", "quadrant_topright")
BOTTOM_RIGHT, BOTTOM_LEFT, TOP_LEFT, TOP_RIGHT = 0, 1, 2, 3
PATH_STRAIGHT, PATH_DEAD_END, PATH_CORNER, PATH_CROSSROADS, PATH_T_JUNCTION, PATH_ORIENTED_CROSSROADS = 1, 2, 3, 4, 5, 8
TILE_BUILDING = 4
SIDES = {0: "Up", 90: "Right", 180: "Down", 270: "Left"}


def f32(value):
    """The value as Unreal's single precision float: a weighted pick can turn on the rounding."""
    return struct.unpack("f", struct.pack("f", value))[0]


class Corner(object):
    __slots__ = ("x", "y", "index", "rotation_offset")

    def __init__(self, x, y, index, rotation_offset=0):
        self.x, self.y, self.index, self.rotation_offset = x, y, index, rotation_offset

    @property
    def next(self):
        return (self.index + 1) & 3

    @property
    def previous(self):
        return (self.index + 3) & 3

    @property
    def direction(self):
        return ((self.index + 1) & 3) * 90


class QuadrantLayout(object):
    """FProceduralQuadrantLayout: walks the path network around each block of cells to find the shape of the room that fits inside it."""

    def __init__(self, cells, width, height):
        self.cells, self.width, self.height = cells, width, height
        self.processed = [False] * (len(cells) * 4)

    def build(self, shapes):
        quadrants = []
        for y in range(self.height):
            for x in range(self.width):
                for i in range(4):
                    q = self.find_quadrant(Corner(x, y, i), shapes)
                    if q:
                        quadrants.append(q)
        return quadrants

    def cell(self, x, y):
        return self.cells[y * self.width + x]

    def in_bounds(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    @staticmethod
    def neighbor(x, y, direction):
        return {0: (x, y - 1), 90: (x + 1, y), 180: (x, y + 1)}.get(direction, (x - 1, y))

    @staticmethod
    def shared_corners(corner):
        """The four cell corners that meet at this corner's grid vertex."""
        vx = corner.x + (1 if corner.index in (BOTTOM_RIGHT, TOP_RIGHT) else 0)
        vy = corner.y + (1 if corner.index in (BOTTOM_RIGHT, BOTTOM_LEFT) else 0)
        out = []
        for i in range(4):
            index = (corner.index + i) & 3
            out.append(Corner(vx - (1 if index in (BOTTOM_RIGHT, TOP_RIGHT) else 0), vy - (1 if index in (BOTTOM_RIGHT, BOTTOM_LEFT) else 0), index, -90 * i))
        return out

    def corner_index(self, corner):
        return ((corner.y * self.width + corner.x) << 2) + corner.index

    def has_path(self, x, y, direction):
        cell = self.cell(x, y)
        local = (direction - cell.rotation + 360) % 360
        if cell.path == PATH_STRAIGHT:
            return local in (0, 180)
        if cell.path == PATH_DEAD_END:
            return local == 270
        if cell.path == PATH_CORNER:
            return local in (0, 270)
        if cell.path in (PATH_CROSSROADS, PATH_ORIENTED_CROSSROADS):
            return True
        if cell.path == PATH_T_JUNCTION:
            return local in (90, 180, 270)
        return False

    def is_available(self, corner):
        for current in self.shared_corners(corner):
            if not self.in_bounds(current.x, current.y) or self.processed[self.corner_index(current)]:
                return False
        return self.has_path(corner.x, corner.y, corner.direction) and self.has_path(corner.x, corner.y, (corner.direction + 90) % 360)

    def mark_processed(self, corner):
        if self.in_bounds(corner.x, corner.y) and self.cell(corner.x, corner.y).type != TILE_BUILDING:
            self.processed[self.corner_index(corner)] = True

    def trace_boundary(self, origin):
        x, y = origin.x, origin.y
        heading, next_corner = origin.direction, origin.next
        turns, sides = [], {}
        for _ in range(len(self.cells) * 4):
            x, y = self.neighbor(x, y, heading)
            if not self.in_bounds(x, y):
                return None
            corner = Corner(x, y, next_corner)
            can_turn = self.is_available(corner)
            if not can_turn and not (self.has_path(x, y, heading) and self.has_path(x, y, (heading + 180) % 360)):
                return None
            side = SIDES[heading]
            sides[side] = sides.get(side, 0) + 1
            if not can_turn:
                continue
            turns.append(corner)
            heading = (heading + 90) % 360
            next_corner = corner.next
            if x == origin.x and y == origin.y:
                return turns, sides
        return None

    def try_l_shape(self, origin):
        if self.cell(origin.x, origin.y).type == TILE_BUILDING:
            return None
        fx, fy = self.neighbor(origin.x, origin.y, origin.direction)
        sx, sy = self.neighbor(origin.x, origin.y, (origin.direction + 90) % 360)
        first, second = Corner(fx, fy, origin.next), Corner(sx, sy, origin.previous)
        if not self.is_available(first) or not self.is_available(second):
            return None
        self.mark_processed(first)
        self.mark_processed(second)
        self.mark_processed(origin)
        return origin.x, origin.y, origin.index, "L_Shape", 0

    def find_quadrant(self, origin, shapes):
        if not self.is_available(origin):
            return None
        boundary = self.trace_boundary(origin)
        if boundary is None:
            return self.try_l_shape(origin)
        turns, sides = boundary
        for turn in turns:
            for corner in self.shared_corners(turn):
                self.mark_processed(corner)
        shape = next((s for s in shapes if all(sides.get(d, 0) == n for d, n in s[1])), None)
        if shape is None:
            return None
        for corner in self.shared_corners(origin):
            if self.cell(corner.x, corner.y).type != TILE_BUILDING:
                return corner.x, corner.y, corner.index, shape[0], corner.rotation_offset
        return None


def enum_tail(value):
    return str(value).rsplit("::", 1)[-1]


def generation_data(tables):
    entry = tables.get("ProceduralGenerationData")
    if not entry:
        raise Unavailable("ProceduralGenerationData is not in the export")
    for item in read_json(best_export(entry[sorted(entry)[0]])):
        if isinstance(item, dict) and item.get("Properties"):
            return item["Properties"]
    raise Unavailable("ProceduralGenerationData is empty")


def level_generator(tables):
    """The defaults of the LevelGenerator blueprint."""
    entry = tables.get("LevelGenerator")
    if not entry:
        raise Unavailable("LevelGenerator is not in the export")
    for item in read_json(best_export(entry[sorted(entry)[0]])):
        if isinstance(item, dict) and item.get("Name") == "Default__LevelGenerator_C":
            return item.get("Properties") or {}
    raise Unavailable("LevelGenerator has no defaults")


class WeightedItem(object):
    __slots__ = ("path", "weight")

    def __init__(self, path, weight):
        self.path, self.weight = path, weight


def select_room(items, random_value, decay):
    """FProceduralQuadrantPlacementBuilder.Select: a picked room gets less likely for the rest of the map."""
    total = f32(sum(max(0.0, item.weight) for item in items))
    if total <= 0:
        return None
    remaining = f32(((random_value >> 9) / 8388608.0) * total)
    for item in items:
        if item.weight <= 0:
            continue
        if remaining <= item.weight:
            path = item.path
            item.weight = f32(item.weight * decay)
            return path
        remaining = f32(remaining - item.weight)
    return None


def tile_matrix(placement, tile_size, width, height):
    """FProceduralTilePlacement.Transform, as a 4x4 in the frame centred on the whole grid."""
    x = (placement.x + placement.width / 2.0 - width / 2.0) * tile_size
    y = (placement.y + placement.height / 2.0 - height / 2.0) * tile_size
    yaw = dbd_map.yaw_from_flags(placement.flags << 29) or 0
    return dbd_core.compose_trs((x, y, 0.0), dbd_core.rotator_matrix(0.0, yaw, 0.0), (1.0, 1.0, 1.0))


def orient_room(matrix, definition, cells, width, height, tile_size):
    """FProceduralQuadrantPlacementBuilder.OrientRoom: returns the room's 4x4."""
    _x, _y, _corner, kind, rotation_offset = definition
    yaw = (int(round(math.degrees(math.atan2(matrix[1][0], matrix[0][0])))) + rotation_offset) % 360
    if (kind == "Rect_X" and yaw % 180 != 0) or (kind == "Rect_Y" and yaw % 180 == 0):
        yaw = (yaw + 90) % 360
    px, py = matrix[0][3], matrix[1][3]
    grid_x = px - (1 - width) * tile_size / 2.0
    grid_y = py - (1 - height) * tile_size / 2.0
    cell_x, cell_y = int(grid_x / tile_size), int(grid_y / tile_size)          # truncates toward zero, as the C# cast does
    if 0 <= cell_x < width and 0 <= cell_y < height:
        forced = {1: 0, 2: 180, 3: 270, 4: 90}.get(cells[cell_y * width + cell_x].quadrant_rotation, -1)
        compatible = forced % 180 == 0 if kind == "Rect_X" else (forced % 180 == 90 if kind == "Rect_Y" else True)
        if forced >= 0 and compatible and forced != yaw:
            if kind == "Rect_X":
                px += -tile_size if forced == 0 else tile_size
            elif kind == "Rect_Y":
                py += -tile_size if forced == 90 else tile_size
            yaw = forced
    return dbd_core.compose_trs((px, py, matrix[2][3]), dbd_core.rotator_matrix(0.0, yaw, 0.0), (1.0, 1.0, 1.0))


def plan_rooms(plan, blueprint_of):
    """
    The rooms of a planned map: [(class_name, object_path, 4x4 matrix in the Plan's frame)].  blueprint_of(tile) -> dbd_core.Blueprint or None.
    Raises Unavailable when the export has no ProceduralGenerationData.
    """
    game = plan.game
    data = generation_data(game.tables)
    tile_size = float(data.get("ProceduralTileWidth", 1600.0))
    decay = float(level_generator(game.tables).get("QuadTileWeightRateOfDecay", 0.01))
    shapes = [(enum_tail(s.get("QuadrantSpawnType")), [(enum_tail(d.get("Direction")), int(d.get("Length", 0))) for d in s.get("SectionLenghts") or []])
              for s in data.get("QuadrantSpawnTypeProperties") or []]
    categories = {}
    for category in data.get("QuadrantSpawnCategories") or []:
        pools = {}
        for item in category.get("Items") or []:
            pools[enum_tail(item.get("Type"))] = [WeightedItem((e.get("Element") or {}).get("AssetPathName") or "", float(e.get("Weight", 0.0))) for e in item.get("Elements") or []]
        categories[str(category.get("QuadrantSpawnTag")).lower()] = pools

    cells, width, height = game.cells, game.width, game.height
    by_cell = {}
    for tile in game.placements:
        for y in range(tile.y, tile.y + tile.height):
            for x in range(tile.x, tile.x + tile.width):
                by_cell[(x, y)] = tile
    spawners = {}

    def spawners_of(tile):
        if tile.name not in spawners:
            bp = blueprint_of(tile)
            spawners[tile.name] = [p for p in (bp.placements if bp else []) if p.type == "ActorSpawner" and enum_tail(p.props.get("Type")) == "QuadrantSpawn"
                                   and dbd_core.safe_float(p.props.get("Weight"), 1.0) > 0]
        return spawners[tile.name]

    c0, r0, c1, r1 = plan.bbox
    shift_x = ((width - 1) / 2.0 - (c0 + c1) / 2.0) * tile_size
    shift_y = ((height - 1) / 2.0 - (r0 + r1) / 2.0) * tile_size
    random = RandomStream(game.seed, STREAM_QUADRANT_SELECTION)
    rooms = []
    game.rooms = []
    for definition in QuadrantLayout(cells, width, height).build(shapes):
        x, y, corner, kind, _offset = definition
        tile = by_cell.get((x, y))
        if tile is None:
            continue
        local_corner = (corner - cells[y * width + x].rotation // 90 + 4) % 4
        for spawner in spawners_of(tile.tile):
            tags = [str(t).lower() for t in spawner.props.get("ComponentTags") or []]
            if CORNER_TAGS[local_corner] not in tags:
                continue
            tag = next((t for t in tags if t in categories), None)
            if tag is None:
                continue
            pool = categories[tag].get("Rect" if kind in ("Rect_X", "Rect_Y") else kind)
            if pool is None:
                continue
            path = select_room(pool, random.next_uint32(), decay)
            if path is None:
                continue
            for _ in range(10):                      # native advances this stream ten times when preparing the selected room's content
                random.next_uint32()
            if not path:
                continue
            matrix = orient_room(dbd_core.mat_mul(tile_matrix(tile, tile_size, width, height), spawner.world), definition, cells, width, height, tile_size)
            placed = tuple(tuple(v + (shift_x if r == 0 and c == 3 else shift_y if r == 1 and c == 3 else 0.0) for c, v in enumerate(row)) for r, row in enumerate(matrix))
            rooms.append((path.rsplit(".", 1)[-1], path, placed))
            game.rooms.append((path.rsplit(".", 1)[-1], path, matrix))
            break
    return rooms


# ---------------------------------------------------------------------------------------------------------------------------------
# Gameplay objects
# ---------------------------------------------------------------------------------------------------------------------------------

STREAM_HATCH_SELECTION, STREAM_BASEMENT_SELECTION, STREAM_ACTOR_SELECTION, STREAM_CHEST_COUNT, STREAM_GAMEPLAY_POPULATION = 15, 16, 20, 11, 21
ELEMENT_TYPES = ("Generic", "MeatLocker_Small", "TileLights", "MeatLocker_Big", "Searchable", "EdgeObjects", "LivingWorldObjects", "Hatch", "Bookshelves", "Totems",
                 "QuadrantSpawn", "EdgeObjectsBlocker", "BreakableWalls", "Escape", "ThemeSpawner", "Basement_Attachments", "SteamPipe", "SteamPipeButton", "EventSpawner",
                 "BasementSeance", "RealmSpawner", "Cage", "VoidSpawner")
SPAWNER_TYPES = ("ActorSpawner", "TileSpawnPoint")
RANDOMIZER_TYPES = ("ObjectRandomizer", "ActorSpawnerRandomizer")
PLAIN_HOOK = "BP_SmallMeatLocker_C"
CHESTS_NOT_IN_THE_DATA = 1


def element_stream(seed, element):
    return RandomStream(seed, STREAM_GAMEPLAY_POPULATION + ELEMENT_TYPES.index(element))


def ref_leaf(ref):
    """'Type'Outer:Name'' -> Name"""
    name = (ref or {}).get("ObjectName") or ""
    m = re.search(r"'([^']*)'", name)
    return re.split(r"[:.]", m.group(1) if m else name)[-1]


class ClassData(object):
    """One blueprint class's export."""

    def __init__(self, path, class_name):
        self.name = class_name
        self.path = path
        self.items = [i for i in read_json(path) if isinstance(i, dict)]
        self.by_name = {}
        for item in self.items:
            self.by_name.setdefault(item.get("Name"), item)
        cls = next((i for i in self.items if i.get("Type") == "BlueprintGeneratedClass" and i.get("Name") == class_name), None) or {}
        self.super_name = ref_leaf(cls.get("Super")) if cls.get("Super") else ""
        props = cls.get("Properties") or {}
        self.scs = self.by_name.get(ref_leaf(props.get("SimpleConstructionScript")))
        self.handler = self.by_name.get(ref_leaf(props.get("InheritableComponentHandler")))


class Library(object):
    """Reads blueprints the way FProceduralComponentReader does: base class first, in construction script order, so a weighted pick walks them in the game's order."""

    def __init__(self, find):
        self.find, self.classes, self.components = find, {}, {}

    def load(self, class_name, object_path=None):
        if class_name not in self.classes:
            path = self.find(class_name, object_path)
            data = None
            if path:
                try:
                    data = ClassData(path, class_name)
                except (OSError, ValueError):
                    data = None
            self.classes[class_name] = data
        return self.classes[class_name]

    def preload(self, class_name, path):
        """
        Read `class_name` from this file, not by looking the name up: several realms share tile names (BP_TL_St_MainBuilding is in Quantum,
        Umbra and Wormhole), and the lookup took Wormhole's for Umbra, whose lockers, generators and totem then hung 3 m up in Umbra's building.
        """
        if class_name not in self.classes and path:
            try:
                self.classes[class_name] = ClassData(path, class_name)
            except (OSError, ValueError):
                pass

    def chain(self, class_name):
        """The class and its parents, the class itself first."""
        out, seen = [], set()
        current = class_name
        while current and current not in seen:
            seen.add(current)
            data = self.load(current)
            if data is None:
                break
            out.append(data)
            current = data.super_name
        return out

    def read(self, class_name):
        """[(variable name, component export, 4x4 in the actor's frame)]"""
        if class_name in self.components:
            return self.components[class_name]
        classes = self.chain(class_name)
        by_guid, by_name = {}, {}
        for data in classes:
            for record in ((data.handler or {}).get("Properties") or {}).get("Records") or []:
                template = data.by_name.get(ref_leaf(record.get("ComponentTemplate")))
                if template is None:
                    continue
                key = record.get("ComponentKey") or {}
                guid = key.get("AssociatedGuid")
                if guid and guid.strip("0-"):
                    by_guid.setdefault(guid, template)
                if key.get("OwnerClass"):
                    by_name.setdefault((ref_leaf(key["OwnerClass"]), key.get("SCSVariableName")), template)
        components, transforms, visited = [], {}, set()
        state = {"root": False}

        def visit(ref, data, parent):
            node = data.by_name.get(ref_leaf(ref))
            if node is None or (data.name, node.get("Name")) in visited:
                return
            visited.add((data.name, node.get("Name")))
            props = node.get("Properties") or {}
            variable = props.get("InternalVariableName")
            template = data.by_name.get(ref_leaf(props.get("ComponentTemplate")))
            override = by_guid.get(props.get("VariableGUID")) or by_name.get((data.name, variable))
            if override is not None and override is not template:
                # an override only stores what it changes: the spawner's Type and lists stay on the parent's copy
                merged = dict(override)
                merged["Properties"] = dict((template or {}).get("Properties") or {}, **(override.get("Properties") or {}))
                template = merged
            inherited = props.get("ParentComponentOrVariableName")
            if inherited and inherited != "None" and inherited in transforms:
                parent = transforms[inherited]
            matrix = parent
            if template is not None:
                local = dbd_core.local_matrix_ue(template.get("Properties"), [])
                matrix = dbd_core.mat_mul(parent, local) if state["root"] else dbd_core.IDENTITY
                state["root"] = True
                transforms[variable] = matrix
                components.append((variable, template, matrix))
            for child in props.get("ChildNodes") or []:
                visit(child, data, matrix)

        for data in reversed(classes):
            for root in ((data.scs or {}).get("Properties") or {}).get("RootNodes") or []:
                visit(root, data, dbd_core.IDENTITY)
        self.components[class_name] = components
        return components

    def script(self, data, function):
        item = next((i for i in data.items if i.get("Name") == function and i.get("ScriptBytecode")), None)
        return item.get("ScriptBytecode") if item else None


def scene_elements(component, key="ActivatedSceneElement"):
    return (component.get("Properties") or {}).get(key) or []


def num(props, key, default):
    return dbd_core.safe_float(props.get(key), default)


class SpawnPoint(object):
    """FProceduralSpawnPoint"""

    def __init__(self, name, variable, component, matrix, active=None, elements=None):
        self.name, self.variable, self.component, self.matrix, self.elements = name, variable, component, matrix, elements
        p = component.get("Properties") or {}
        spawner = component.get("Type") == "ActorSpawner"
        self.props = p
        self.is_spawner = spawner
        self.element = enum_tail(p.get("Type", "EGameplayElementType::Generic")) if spawner else ""
        self.is_active = active if active is not None else not (spawner and p.get("ActivatedByDefault") is False)
        self.weight = num(p, "Weight", 1.0)
        self.priority = int(num(p, "SpawnPriorityTier" if spawner else "_spawnPriorityTier", 1))
        self.cost = num(p, "Cost", 1.0) if spawner else 1.0
        self.spawn_count_max = int(num(p, "SpawnCountMax", 1)) if spawner else 1
        self.influenceable = p.get("WeightInfluenceable" if spawner else "_weightInfluenceable") is not False
        self.influencer = p.get("WeightInfluencer" if spawner else "_weightInfluencer") is not False

    @property
    def translation(self):
        return self.matrix[0][3], self.matrix[1][3], self.matrix[2][3]


class Actor(object):
    """FProceduralActorPlacement"""

    def __init__(self, name, class_name, path, matrix):
        self.name, self.class_name, self.path, self.matrix = name, class_name, path, matrix
        self.activation, self.variations, self.elements = {}, {}, {}


class Settings(object):
    """FProceduralPopulationSettings"""

    def __init__(self, generator=None, tile_size=1600.0, map_width=0):
        g = generator or {}
        self.tile_size, self.map_width = tile_size, map_width
        self.generators = float(g.get("MinProximityBetweenGenerators", 0.5))
        self.chests = float(g.get("MinProximityBetweenChests", 1.0))
        self.totems = float(g.get("MinProximityBetweenTotems", 1.0))
        self.hatches = float(g.get("MinProximityBetweenHatches", 1.0))
        self.killer_lair = float(g.get("SmallMeatLockerMinProximityFromKillerLair", 1.5))
        self.adjust_factor = float(g.get("FactorToAdjustToWhenOutOfProximity", 0.0))
        self.height_amplifier = float(g.get("HeightAmplifier", 3.0))
        self.height_activation = float(g.get("HeightAmplifierActivationHeight", 350.0))


class Population(object):
    """FProceduralPopulation: weighted picks where each chosen object pushes the next ones away."""

    def __init__(self, points, settings=None):
        self.settings = settings or Settings()
        self.weights = {}
        for point in points:
            if point.weight == point.weight and abs(point.weight) != float("inf"):
                self.weights.setdefault(point, max(0.0, point.weight))

    def distance_squared(self, first, second):
        dx, dy, dz = first[0] - second[0], first[1] - second[1], first[2] - second[2]
        if abs(dz) > self.settings.height_activation:
            dz *= self.settings.height_amplifier
        return f32(dx * dx + dy * dy + dz * dz)

    def adjust_weights(self, position, proximity, falloff, minimum_factor):
        area = self.settings.tile_size * self.settings.tile_size or 1600.0 * 1600.0
        falloff = falloff if falloff > 0 else 10
        for point in self.weights:
            if not point.influenceable:
                continue
            distance = f32(self.distance_squared(point.translation, position) / area)
            factor = minimum_factor if distance < proximity * proximity else max(max(minimum_factor, 0.01), min(distance / falloff, 1.0))
            self.weights[point] *= factor

    def select(self, minimum, maximum, min_distance, random):
        return self._select(minimum, maximum, min_distance, min_distance / self.settings.tile_size, self.settings.map_width - 1, random, True)

    def select_count(self, count, proximity, random):
        return self._select(count, count, 0.0, proximity, self.settings.map_width, random, False)

    def _select(self, minimum, maximum, min_distance, proximity, falloff, random, use_cost):
        def cost_of(point):
            return point.cost if use_cost else 1.0

        remaining = [p for p in self.weights if cost_of(p) >= 0 and cost_of(p) != float("inf")]
        selected, rejected = [], []
        cost = 0.0
        min_squared = f32(min_distance * min_distance)
        while remaining:
            live = [max(1, p.priority) for p in remaining if self.weights[p] > 0]
            if not live:
                break
            priority = max(live)
            total = sum(self.weights[p] for p in remaining if max(1, p.priority) == priority)
            weight = random.next_float() * total
            index = max(i for i, p in enumerate(remaining) if max(1, p.priority) == priority and self.weights[p] > 0)
            for i, point in enumerate(remaining):
                if max(1, point.priority) != priority:
                    continue
                if weight < self.weights[point]:
                    index = i
                    break
                weight -= self.weights[point]
            point = remaining.pop(index)
            if cost + cost_of(point) > maximum:
                continue
            if point.influenceable and any(o.influencer and self.distance_squared(point.translation, o.translation) < min_squared for o in selected):
                rejected.append(point)
                continue
            selected.append(point)
            cost += cost_of(point)
            if proximity > 0 and point.influencer:
                self.adjust_weights(point.translation, proximity, falloff, self.settings.adjust_factor)
        rejected += remaining
        while cost < minimum and rejected:
            def rank(c):
                return max(1, c.priority) * 0 + c.priority, (min(self.distance_squared(c.translation, o.translation) for o in selected) if selected else 0)
            point = max(rejected, key=rank)
            rejected.remove(point)
            if cost + cost_of(point) > maximum:
                continue
            selected.append(point)
            cost += cost_of(point)
        return selected


def generator_class(props):
    """The generator blueprint of an InteractableObject spawn point: the export names only an editor marker for most of them."""
    names = [path_class((e or {}).get("AssetPathName") or "") for e in props.get("ObjectSpawnModifier") or []]
    names.append(path_class((props.get("Visualization") or {}).get("AssetPathName") or ""))
    for name in names:
        if name.startswith("Generator"):
            return name
        if name.startswith("BP_Editor_Generator"):
            return "GeneratorNoPole_C" if "NoPole" in name else "GeneratorStandard_C"
    return "GeneratorStandard_C"


def select_element(elements, fallback, random):
    """FProceduralGameplayLayout.SelectBlueprint: a weighted pick from a spawner's list, or `fallback` when it has no choice."""
    candidates = [e for e in elements if num(e, "Weight", 1.0) > 0]
    remaining = random.next_float() * sum(num(e, "Weight", 1.0) for e in candidates)
    for element in candidates:
        fallback = (element.get("SceneElement") or {}).get("AssetPathName") or ""
        if remaining < num(element, "Weight", 1.0):
            break
        remaining -= num(element, "Weight", 1.0)
    return fallback


def path_class(path):
    return path.rsplit(".", 1)[-1] if path else ""


def variable_name(expression):
    """The name of a bytecode variable reference."""
    v = (expression or {}).get("Variable") or {}
    prop = v.get("Property") or {}
    if prop.get("Name"):
        return prop["Name"]
    path = v.get("Path") or []
    return path[-1] if path else ""


def randomizer_bindings(library, class_name, random):
    """
    FProceduralRandomizerReader: {randomizer: [spawner variables]}.  Most tiles fill the lists in their construction script, branching on the tile's shared random
    stream: that script is followed here on a copy of the stream, so it does not advance the real one.
    """
    components = library.read(class_name)
    variables = {c.get("Name"): v for v, c, _m in components if c.get("Type") == "ActorSpawner"}
    bindings = {}
    for variable, component, _m in components:
        if component.get("Type") in RANDOMIZER_TYPES:
            refs = (component.get("Properties") or {}).get("Spawners") or []
            bindings[variable] = [variables.get(ref_leaf(r), ref_leaf(r)) for r in refs]
    if not bindings:
        return bindings
    copy = RandomStream(0, 0)
    copy.seed = random.seed
    for data in reversed(library.chain(class_name)):
        script = library.script(data, "UserConstructionScript")
        if not script:
            continue
        random_bools = set()
        for s in script:
            target, expression = s.get("Variable") or {}, s.get("Expression") or {}
            if (s.get("Token") == "EX_LetBool" and target.get("Token") == "EX_LocalVariable" and expression.get("Token") == "EX_CallMath"
                    and "RandomBoolFromStream" in ((expression.get("Function") or {}).get("ObjectName") or "")):
                params = expression.get("Parameters") or []
                if len(params) == 1 and params[0].get("Token") == "EX_InstanceVariable" and variable_name(params[0]) == "SharedTileRandomizer":
                    random_bools.add(variable_name(target))
        jumps = [s for s in script if s.get("Token") == "EX_JumpIfNot"]
        follow = bool(random_bools) and all((j.get("BooleanExpression") or {}).get("Token") == "EX_LocalVariable" and variable_name(j["BooleanExpression"]) in random_bools for j in jumps)
        by_statement = {s.get("StatementIndex"): i for i, s in enumerate(script)}
        booleans, arrays = {}, {}
        index = 0
        while index < len(script):
            s = script[index]
            token = s.get("Token")
            target = s.get("Variable") or {}
            if token == "EX_LetBool" and follow and target.get("Token") == "EX_LocalVariable" and variable_name(target) in random_bools:
                booleans[variable_name(target)] = copy.next_float() >= 0.5
            elif token == "EX_JumpIfNot" and follow and (s.get("BooleanExpression") or {}).get("Token") == "EX_LocalVariable" and variable_name(s["BooleanExpression"]) in booleans:
                if not booleans[variable_name(s["BooleanExpression"])]:
                    index = by_statement.get(s.get("CodeOffset"), len(script))
                    continue
            elif token == "EX_Jump" and follow:
                index = by_statement.get(s.get("CodeOffset"), len(script))
                continue
            elif token == "EX_SetArray" and (s.get("AssigningProperty") or {}).get("Token") == "EX_LocalVariable":
                arrays[variable_name(s["AssigningProperty"])] = [variable_name(e) for e in s.get("Elements") or [] if e.get("Token") == "EX_InstanceVariable"]
            elif token == "EX_Let" and target.get("Token") == "EX_Context" and (s.get("Expression") or {}).get("Token") == "EX_LocalVariable":
                owner, member = target.get("ObjectExpression") or {}, target.get("ContextExpression") or {}
                source = variable_name(s["Expression"])
                if owner.get("Token") == "EX_InstanceVariable" and variable_name(member) == "Spawners" and variable_name(owner) in bindings and source in arrays:
                    bindings[variable_name(owner)] = arrays[source]
            index += 1
    return bindings


def collect_points(library, hosts):
    """FProceduralSpawnPoint.Collect: every spawner in the hosts and in what they contain."""
    result = []
    ancestry = set()

    def child_class(component, active):
        p = component.get("Properties") or {}
        kind = component.get("Type")
        if kind == "ChildActorComponent":
            if p.get("ChildActorClass"):
                return ref_leaf(p["ChildActorClass"])
            # an inherited child actor has no ChildActorClass: the template's type is the class
            m = re.match(r"([^']+)'", (p.get("ChildActorTemplate") or {}).get("ObjectName") or "")
            return m.group(1) if m else None
        if kind == "ActorVariationSpawner":
            path = (p.get("Visualization") or {}).get("AssetPathName") or ""
            return path_class(path) if path and "/specialevents/" not in path.lower() and library.load(path_class(path)) else None
        if kind == "ActorSpawner" and enum_tail(p.get("Type", "EGameplayElementType::Generic")) == "Generic":
            on = p.get("ActivatedByDefault") is not False if active is None else active
            if not on or any(str(t).startswith("Quadrant_") for t in p.get("ComponentTags") or []):
                return None
            paths = [(p.get("Visualization") or {}).get("AssetPathName") or ""]
            paths += [(e.get("SceneElement") or {}).get("AssetPathName") or "" for e in p.get("ActivatedSceneElement") or [] if num(e, "Weight", 1.0) > 0]
            for path in paths:
                if path and library.load(path_class(path)):
                    return None if "/specialevents/" in path.lower() else path_class(path)
        return None

    def visit(class_name, name, parent, activation, variations, elements):
        if len(ancestry) >= 8 or class_name in ancestry:
            return
        ancestry.add(class_name)
        for variable, component, relative in library.read(class_name):
            if activation.get(variable, True) is False:
                continue
            active = activation.get(variable)
            matrix = dbd_core.mat_mul(parent, relative)
            component_name = "%s_%s" % (name, variable)
            if component.get("Type") in SPAWNER_TYPES:
                result.append(SpawnPoint(component_name, variable, component, matrix, active, elements.get(variable)))
            child = variations.get(variable) or child_class(component, active)
            if child:
                visit(child, component_name, matrix, {}, {}, {})
        ancestry.discard(class_name)

    for host in hosts:
        visit(host.class_name, host.name, host.matrix, host.activation, host.variations, host.elements)
    return result


def build_basement(library, hosts, seed):
    """FProceduralBasementLayout"""
    candidates = []
    for index, host in enumerate(hosts):
        for variable, component, matrix in library.read(host.class_name):
            p = component.get("Properties") or {}
            if (component.get("Type") == "ActorSpawner" and enum_tail(p.get("Type", "")) == "MeatLocker_Big" and int(num(p, "SpawnCountMax", 1)) != 0
                    and any(num(e, "Weight", 1.0) > 0 and (e.get("SceneElement") or {}).get("AssetPathName") for e in p.get("ActivatedSceneElement") or [])):
                candidates.append((index, SpawnPoint("%s_%s" % (host.name, variable), variable, component, dbd_core.mat_mul(host.matrix, matrix))))
    random = RandomStream(seed, STREAM_BASEMENT_SELECTION)
    chosen = Population([c[1] for c in candidates]).select(1, 1, 0.0, random)
    basement = chosen[0] if chosen else None
    basement_host = next((c[0] for c in candidates if c[1] is basement), -1)
    variation = RandomStream(seed, STREAM_ACTOR_SELECTION)
    result = []

    def add(name, elements, matrix):
        path = select_element(elements, "", variation)
        if path and library.load(path_class(path)):
            result.append(Actor(name, path_class(path), path, matrix))

    if basement is not None:
        add("Basement", basement.props.get("ActivatedSceneElement") or [], basement.matrix)
    for index, host in enumerate(hosts):
        for variable, component, matrix in library.read(host.class_name):
            p = component.get("Properties") or {}
            if component.get("Type") == "ActorSpawner" and enum_tail(p.get("Type", "")) == "Basement_Attachments":
                add("%s_%s" % (host.name, variable), scene_elements(component, "ActivatedSceneElement" if index == basement_host else "DeactivatedSceneElement"), dbd_core.mat_mul(host.matrix, matrix))
    return result


def build_randomizers(library, hosts, seed):
    """FProceduralRandomizerLayout: returns the objects the groups place, and the points they switched off."""
    result, removed = [], []
    random = RandomStream(seed, STREAM_ACTOR_SELECTION)
    for host in hosts:
        bindings = randomizer_bindings(library, host.class_name, random)
        if not bindings:
            continue
        components = library.read(host.class_name)
        spawners = {v: (c, m) for v, c, m in components if c.get("Type") == "ActorSpawner"}
        contents = {}
        for name, randomizer, _m in components:
            if randomizer.get("Type") not in RANDOMIZER_TYPES or name not in bindings:
                continue
            p = randomizer.get("Properties") or {}
            low, high = int(p.get("MinPopulation", 0)), int(p.get("MaxPopulation", 0))
            if high <= 0 or high < low:
                continue
            points = [SpawnPoint(n, n, spawners[n][0], dbd_core.mat_mul(host.matrix, spawners[n][1])) for n in bindings[name] if n in spawners]
            minimum = min(max(low, 0), len(points))
            maximum = min(max(high, minimum), len(points))
            count = minimum + int(random.next_float() * (maximum - minimum + 1))
            selected = set(Population(points).select_count(count, 0.0, random)) if points else set()
            active_index = inactive_index = 0

            def listed(lists, index):
                return (lists[min(index, len(lists) - 1)].get("ObjectsToBeSpawned") or []) if lists else None

            for point in points:
                is_active = point in selected
                elements = None
                if randomizer.get("Type") == "ActorSpawnerRandomizer":
                    if is_active:
                        elements = listed(p.get("ActivatedSpawnerContentLists") or [], active_index)
                        active_index += 1
                    else:
                        elements = listed(p.get("DeactivatedSpawnerContentLists") or [], inactive_index)
                        inactive_index += 1
                if point.element != "Generic":
                    host.activation[point.name] = is_active
                    if elements is not None:
                        host.elements[point.name] = elements
                    continue
                host.activation[point.name] = False
                removed.append(point.matrix)
                if elements is None:
                    elements = point.props.get("ActivatedSceneElement" if is_active else "DeactivatedSceneElement") or []
                contents[point.name] = (point, elements)
        for point, elements in contents.values():
            path = select_element(elements, "", random)
            if path and library.load(path_class(path)):
                result.append(Actor("%s_%s" % (host.name, point.name), path_class(path), path, point.matrix))
    return result, removed


def eval_curve(keys, time):
    """The value of a float curve at `time`."""
    if not keys:
        return 0.0
    if time <= keys[0].get("Time", 0.0) or len(keys) == 1:
        return float(keys[0].get("Value", 0.0))
    for a, b in zip(keys, keys[1:]):
        t0, t1 = a.get("Time", 0.0), b.get("Time", 0.0)
        if t0 <= time < t1:
            if enum_tail(a.get("InterpMode", "RCIM_Linear")) == "RCIM_Constant" or t1 == t0:
                return float(a.get("Value", 0.0))
            return a["Value"] + (b["Value"] - a["Value"]) * (time - t0) / (t1 - t0)
    return float(keys[-1].get("Value", 0.0))


def int_modifier(tables, name, default):
    for key in sorted(tables.get("GameTypeModifierDefaults", {})):
        for item in read_json(best_export(tables["GameTypeModifierDefaults"][key])):
            for entry in (item.get("Properties") or {}).get("Modifiers") or []:
                value = entry.get("Value") or {}
                if entry.get("Key") == "EGameTypeModifierName::" + name and enum_tail(value.get("SetType")) == "IntTunable":
                    return int(value.get("_intValue", default))
    return default


def map_row(tables, name):
    """The map's row in ProceduralMaps: its hook and pallet counts."""
    for key, row in table_rows(tables, "ProceduralMaps"):
        if key.lower() == name.lower():
            return row
    return {}


def can_populate(plan):
    """True when the export holds everything plan_gameplay needs."""
    game = getattr(plan, "game", None)
    return bool(game and game.tables.get("ProceduralGenerationData") and game.tables.get("LevelGenerator"))


STREAM_EDGE_OBJECTS = 59
MESH_COMPONENTS = ("StaticMeshComponent", "HierarchicalInstancedStaticMeshComponent", "InstancedStaticMeshComponent", "FoliageInstancedStaticMeshComponent")
KINDA_SMALL_NUMBER = 1e-4


def box_transform(box, matrix):
    """The axis-aligned box around a box's 8 corners moved by a 4x4."""
    (x0, y0, z0), (x1, y1, z1) = box
    pts = [dbd_core.mat_apply(matrix, (x, y, z)) for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)]
    return (tuple(min(p[i] for p in pts) for i in range(3)), tuple(max(p[i] for p in pts) for i in range(3)))


def boxes_overlap(a, b):
    return all(min(a[1][i], b[1][i]) - max(a[0][i], b[0][i]) > KINDA_SMALL_NUMBER for i in range(3))


def build_edges(library, hosts, points, seed, shapes):
    """
    FProceduralEdgeLayout: the objects along tile edges (Kenya's trees, door frames) that the game keeps.  Shuffled with the seed and taken by priority, each is
    kept only when its collision misses every other tile's and every edge object already kept on another tile.  shapes(object_path, mesh_name) gives a mesh's
    collision boxes in its own space: the game reads the meshes' collision, which the meshes the add-on reads do not carry, so the add-on stands in for it.
    """
    candidates = [p for p in points if p.is_spawner and p.is_active and p.element == "EdgeObjects" and p.weight > 0 and p.spawn_count_max != 0]
    if not candidates:
        return []
    geometry, ancestry = {}, set()

    def child_blueprint(component):
        p = component.get("Properties") or {}
        kind = component.get("Type")
        if kind == "ChildActorComponent":
            return ref_leaf(p["ChildActorClass"]) if p.get("ChildActorClass") else None
        if kind == "ActorVariationSpawner":
            path = (p.get("Visualization") or {}).get("AssetPathName") or ""
            return path_class(path) if path and "/specialevents/" not in path.lower() and library.load(path_class(path)) else None
        if kind == "ActorSpawner" and enum_tail(p.get("Type", "EGameplayElementType::Generic")) == "Generic":
            if p.get("ActivatedByDefault") is False or any(str(t).startswith("Quadrant_") for t in p.get("ComponentTags") or []):
                return None
            paths = [(p.get("Visualization") or {}).get("AssetPathName") or ""]
            paths += [(e.get("SceneElement") or {}).get("AssetPathName") or "" for e in p.get("ActivatedSceneElement") or [] if num(e, "Weight", 1.0) > 0]
            for path in paths:
                if path and library.load(path_class(path)):
                    return None if "/specialevents/" in path.lower() else path_class(path)
        return None

    def get_geometry(class_name):
        if class_name in geometry:
            return geometry[class_name]
        if len(ancestry) >= 8 or class_name in ancestry:
            return []
        ancestry.add(class_name)
        boxes = []
        for _variable, component, matrix in library.read(class_name):
            p = component.get("Properties") or {}
            if component.get("Type") in MESH_COMPONENTS and p.get("bVisible", True) is not False and not p.get("bHiddenInGame", False):
                body = p.get("BodyInstance") or {}
                if body.get("CollisionProfileName") != "NoCollision" and enum_tail(body.get("CollisionEnabled", "")) != "NoCollision":
                    mesh = p.get("StaticMesh") or {}
                    local = shapes(mesh.get("ObjectPath"), ref_leaf(mesh)) if isinstance(mesh, dict) and mesh else []
                    instances = component.get("PerInstanceSMData") or []
                    if instances:
                        for e in instances:
                            m = dbd_core.mat_mul(matrix, dbd_core.instance_matrix_ue(e))
                            boxes += [box_transform(b, m) for b in local]
                    else:
                        boxes += [box_transform(b, matrix) for b in local]
            child = child_blueprint(component)
            if child:
                boxes += [box_transform(b, matrix) for b in get_geometry(child)]
        ancestry.discard(class_name)
        geometry[class_name] = boxes
        return boxes

    def outline(boxes):
        return (tuple(min(b[0][i] for b in boxes) for i in range(3)), tuple(max(b[1][i] for b in boxes) for i in range(3))) if boxes else None

    blockers = []
    for host in hosts:
        boxes = [box_transform(b, host.matrix) for b in get_geometry(host.class_name)]
        blockers.append((host.name, boxes, outline(boxes)))
    random = RandomStream(seed, STREAM_EDGE_OBJECTS)
    for index in range(len(candidates) - 1, -1, -1):        # the native pass shuffles the whole list before its priority sort
        other = int(random.next_float() * len(candidates))
        candidates[index], candidates[other] = candidates[other], candidates[index]
    result = []
    for point in sorted(candidates, key=lambda c: -c.priority):
        selection = RandomStream((random.next_uint32() + 1) & 0xFFFFFFFF, STREAM_DEFAULT)
        own = point.elements if point.elements is not None else point.props.get("ActivatedSceneElement") or []
        fallback = ((point.props.get("Visualization") or {}).get("AssetPathName") or "") if point.elements is None else ""
        path = select_element(own, fallback, selection)
        cls = path_class(path)
        if not path or not library.load(cls):
            continue
        bounds = [box_transform(b, point.matrix) for b in get_geometry(cls)]
        whole = outline(bounds)
        host = next((h.name for h in hosts if point.name.startswith(h.name + "_")), None)
        blocked = whole is not None and any(name != host and edge is not None and boxes_overlap(whole, edge) and any(boxes_overlap(a, b) for a in bounds for b in others)
                                             for name, others, edge in blockers)
        if blocked:
            continue
        result.append(Actor(point.name, cls, path, point.matrix))
        blockers.append((host or point.name, bounds, whole))
    return result


def plan_gameplay(plan, find, shapes=None):
    """
    The map's gameplay objects from the game's rules.  find(class_name, object_path) -> a blueprint JSON path or None.
    Returns (actors, removed): [(name, class_name, path, 4x4 in the Plan's frame)] and the 4x4s of the spawn points randomizer groups replaced.  With `shapes`
    (see build_edges) the edge objects are picked too; the tiles must then leave their EdgeObjects spawners out.
    """
    game = plan.game
    tables, seed, width, height = game.tables, game.seed, game.width, game.height
    data = generation_data(tables)
    tile_size = float(data.get("ProceduralTileWidth", 1600.0))
    generator = level_generator(tables)
    settings = Settings(generator, tile_size, width)
    library = Library(find)
    for p in game.placements:
        library.preload(p.tile.class_name, getattr(p.tile, "json_path", None))

    hosts = []
    blockers = {(x, y) for y in range(height) for x in range(width) if game.cells[y * width + x].type == TILE_BLOCKER}
    for p in game.placements:
        host = Actor("Tile_%d_%d" % (p.x, p.y), p.tile.class_name, "", tile_matrix(p, tile_size, width, height))
        if p.tile.kind == TILE_BLOCKER:
            yaw = dbd_map.yaw_from_flags(p.flags << 29) or 0
            for variable, component, _m in library.read(p.tile.class_name):
                m = dbd_core.DIRECTION_NAME.search(variable or "")
                if component.get("Type") == "ActorSpawner" and m and (component.get("Properties") or {}).get("ActivatedByDefault") is False:
                    dx, dy = dbd_core.rotate_direction({"Up": "U", "Right": "R", "Down": "D", "Left": "L"}[m.group(2)], yaw)
                    host.activation[variable] = (p.x + dx, p.y + dy) in blockers
        tag = TILE_VARIATIONS.get(game.cells[p.y * width + p.x].tag)
        if tag:
            for variable, component, _m in library.read(p.tile.class_name):
                if component.get("Type") == "ActorVariationSpawner":
                    for v in (component.get("Properties") or {}).get("Variations") or []:
                        path = (v.get("Element") or {}).get("AssetPathName") or ""
                        if enum_tail(v.get("Type")) == tag and path and library.load(path_class(path)):
                            host.variations[variable] = path_class(path)
                            break
        hosts.append(host)
    for i, (cls, path, matrix) in enumerate(getattr(game, "rooms", None) or []):
        if library.load(cls):
            hosts.append(Actor("Quadrant_%d" % i, cls, path, matrix))

    basement_actors = build_basement(library, hosts, seed)
    randomized, removed = build_randomizers(library, hosts, seed)
    points = collect_points(library, hosts + basement_actors + randomized)

    def spawners(element):
        return [p for p in points if p.is_spawner and p.element == element and p.spawn_count_max != 0]

    actors = []
    variation = RandomStream(seed, STREAM_ACTOR_SELECTION)

    def add(point, fallback=""):
        if point.is_spawner:
            own = point.elements if point.elements is not None else point.props.get("ActivatedSceneElement") or []
            path = select_element(own, fallback if point.elements is None else "", variation)
        elif enum_tail(point.props.get("TileSpawnPointType", "")) == "InteractableObject":
            cls = generator_class(point.props)
            path = "/Game/Blueprints/GameplayElements/Interactable/Generator/%s.%s" % (cls[:-2], cls)
        else:
            path = (point.props.get("Visualization") or {}).get("AssetPathName") or ""
        if path:
            actors.append((point.name, path_class(path), path, point.matrix))

    for population in data.get("ElementsPopulation") or []:
        if enum_tail(population.get("Type")) == "Totems":
            random = element_stream(seed, "Totems")
            minimum = max(0, int(population.get("MinPopulation", 0)))
            maximum = max(minimum, int(population.get("MaxPopulation", 0)))
            count = minimum + int(random.next_float() * (maximum - minimum + 1))
            fallback = (population.get("GameplayElementBlueprint") or {}).get("AssetPathName") or ""
            for point in Population(spawners("Totems"), settings).select_count(count, settings.totems, random):
                add(point, fallback)

    row = map_row(tables, plan.tilemap.name)
    basement = next((a for a in basement_actors if a.name == "Basement"), None)
    for population in data.get("ManagedElementsPopulation") or []:
        element = enum_tail(population.get("Type"))
        if element not in ("MeatLocker_Small", "Bookshelves"):
            continue
        prefix = "Hook" if element == "MeatLocker_Small" else "BookShelves"
        distance, low, high = [row.get(prefix + s, -1) for s in ("MinDistance", "MinCount", "MaxCount")]
        distance = distance if distance >= 0 else population.get("MinDistance", 0.0)
        low = low if low >= 0 else population.get("MinPopulation", 0)
        high = high if high >= 0 else population.get("MaxPopulation", 0)
        random = element_stream(seed, element)
        minimum, maximum = max(0, int(low)), max(max(0, int(low)), int(high))
        candidates = Population([p for p in spawners(element) if p.is_active], settings)
        if element == "MeatLocker_Small" and basement is not None:
            # The native builder measures basement influence from this rotated offset, not its spawner origin
            candidates.adjust_weights(dbd_core.mat_apply(basement.matrix, (330.0, 210.0, 20.0)), settings.killer_lair, settings.map_width, 0.0)
        fallback = (population.get("GameplayElementBlueprint") or {}).get("AssetPathName") or ""
        for point in candidates.select(minimum, maximum, max(0.0, float(distance)) * tile_size, random):
            add(point, fallback)

    keys = (((read_json(best_export(next(iter(tables["ItemCamperCount"].values()))))[0].get("Properties") or {}).get("FloatCurve") or {}).get("Keys") or []) if tables.get("ItemCamperCount") else []
    # The curve (a flat 2) and the modifier (0) give two, but a match has three: something outside the export adds one
    chest_count = max(0, int(math.floor(abs(eval_curve(keys, RandomStream(seed, STREAM_CHEST_COUNT).next_float())) + 0.5)) + int_modifier(tables, "InGameChestCountModifier", 0)) + CHESTS_NOT_IN_THE_DATA
    random = element_stream(seed, "Searchable")
    random.next_float()
    for point in Population(spawners("Searchable"), settings).select_count(chest_count, settings.chests, random):
        add(point)

    for point in spawners("BreakableWalls"):
        if point.is_active and point.weight > 0:
            add(point)

    generators = [p for p in points if not p.is_spawner and enum_tail(p.props.get("TileSpawnPointType", "")) == "InteractableObject"]
    count = int_modifier(tables, "GeneratorCount", -1)
    count = count if count >= 0 else 7
    random = RandomStream(seed, STREAM_DEFAULT)
    chosen = []
    for _ in range(len(generators)):
        if len(chosen) >= count:
            break
        attempt = Population(generators, settings).select(0, count, tile_size * settings.generators, random)
        if len(attempt) > len(chosen):
            chosen = attempt
    for point in chosen:
        add(point)

    # Lockers and vaults outside a randomizer group are not picked: an active spawner just places its object
    for point in points:
        if point.is_spawner and point.element == "Generic" and point.is_active and point.spawn_count_max != 0:
            paths = [(point.props.get("Visualization") or {}).get("AssetPathName") or ""]
            paths += [(e.get("SceneElement") or {}).get("AssetPathName") or "" for e in (point.elements or point.props.get("ActivatedSceneElement") or []) if num(e, "Weight", 1.0) > 0]
            path = next((x for x in paths if dbd_core.gameplay_class_category(path_class(x)) in ("lockers", "vaults")), None)
            if path:
                actors.append((point.name, path_class(path), path, point.matrix))

    random = RandomStream(seed, STREAM_HATCH_SELECTION)
    hatches = max(0, int_modifier(tables, "EscapeHatchCount", 1))
    for point in Population(spawners("Hatch"), settings).select_count(hatches, settings.hatches, random):
        add(point)

    if shapes is not None:
        for actor in build_edges(library, hosts + basement_actors + randomized, points, seed, shapes):
            actors.append((actor.name, actor.class_name, actor.path, actor.matrix))

    hook = dbd_core.realm_hook_for(plan.placements[0].tile.json_path) if plan.placements else None
    c0, r0, c1, r1 = plan.bbox
    shift_x = ((width - 1) / 2.0 - (c0 + c1) / 2.0) * tile_size
    shift_y = ((height - 1) / 2.0 - (r0 + r1) / 2.0) * tile_size

    def to_plan(matrix):
        return tuple(tuple(v + (shift_x if r == 0 and c == 3 else shift_y if r == 1 and c == 3 else 0.0) for c, v in enumerate(row_)) for r, row_ in enumerate(matrix))

    out = []
    for name, cls, path, matrix in actors + [(a.name, a.class_name, a.path, a.matrix) for a in basement_actors + randomized]:
        if cls == PLAIN_HOOK and hook:
            cls, path = hook
        out.append((name, cls, path, to_plan(matrix)))
    return out, [to_plan(m) for m in removed]
