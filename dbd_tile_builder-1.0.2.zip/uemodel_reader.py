"""
.uemodel (UEFormat, https://github.com/halfuwu/UEFormat) -> the same PskMesh psk_reader produces, so the rest of the add-on needs no second path.
Reads the current attribute layout (file version 10 and up), the first LOD only.  Bones and weights are not read: the builder places meshes, it does not rig them.
"""
import gzip
import struct

import numpy as np

from . import psk_reader

SCALE_DOWN = 0.01
ATTRIBUTE_FORMAT = 10               # EUEFormatVersion.AttributeFormatRestructure


class UEModelError(Exception):
    pass


class Reader(object):
    def __init__(self, data, position=0, end=None):
        self.data, self.position = data, position
        self.end = len(data) if end is None else end

    def take(self, size):
        if size < 0 or self.position + size > self.end:
            raise UEModelError("the file is truncated")
        start = self.position
        self.position += size
        return start

    def int32(self):
        return struct.unpack_from("<i", self.data, self.take(4))[0]

    def string(self):
        size = self.int32()
        return self.data[self.take(size):self.position].rstrip(b"\0").decode("utf-8", "replace")

    def floats(self, count):
        return np.frombuffer(self.data, dtype="<f4", count=count, offset=self.take(count * 4))

    def attributes(self):
        """(name, reader over its payload) for each entry of an attribute set."""
        for _ in range(self.int32()):
            name = self.string()
            size = self.int32()
            yield name, Reader(self.data, self.take(size), self.position)


def read_uemodel(path):
    with open(path, "rb") as f:
        return parse_uemodel(f.read())


def parse_uemodel(data):
    if data[:8] != b"UEFORMAT":
        raise UEModelError("not a UEFormat file")
    r = Reader(data, 8)
    if r.string() != "UEMODEL":
        raise UEModelError("not a UEFormat model")
    version = data[r.take(1)]
    if version < ATTRIBUTE_FORMAT:
        raise UEModelError("UEFormat file version %d is too old: export it again with a current FModel" % version)
    name = r.string()
    r.string()                                 # object path
    if data[r.take(1)]:
        kind = r.string()
        size = r.int32()                       # uncompressed size
        r.int32()                              # compressed size
        if kind == "GZIP":
            r = Reader(gzip.decompress(data[r.position:]))
        elif kind == "ZSTD":
            try:
                import zstandard                   # bundled with Blender
            except ImportError:
                raise UEModelError("ZSTD compressed UEFormat needs the zstandard module, which this Blender does not have: export without compression, or with GZIP")
            r = Reader(zstandard.ZstdDecompressor().decompress(data[r.position:], max_output_size=max(size, 0)))
        else:
            raise UEModelError("%s compressed UEFormat is not supported: export without compression, or with GZIP or ZSTD" % kind)
    lods = None
    for attribute, payload in r.attributes():
        if attribute == "LODS":
            lods = payload
            break
    if lods is None or lods.int32() < 1:
        raise UEModelError("the file holds no LOD")
    lods.string()

    vertices = normals = indices = colors = None
    channels, slots = [], []
    for attribute, p in lods.attributes():
        if attribute == "VERTICES":
            count = p.int32()
            vertices = p.floats(count * 3).reshape(count, 3)
        elif attribute == "NORMALS":
            count = p.int32()
            normals = p.floats(count * 4).reshape(count, 4)[:, 1:]    # each starts with the binormal sign
        elif attribute == "TEXCOORDS":
            for _ in range(p.int32()):
                p.string()
                count = p.int32()
                channels.append(p.floats(count * 2).reshape(count, 2))
        elif attribute == "INDICES":
            count = p.int32()
            indices = np.frombuffer(data if p.data is data else p.data, dtype="<u4", count=count, offset=p.take(count * 4)).reshape(count // 3, 3)
        elif attribute == "VERTEXCOLORS":
            sets = p.int32()
            if sets:
                p.string()
                count = p.int32()
                colors = np.frombuffer(p.data, dtype="u1", count=count * 4, offset=p.take(count * 4)).reshape(count, 4)
        elif attribute == "MATERIALS":
            for _ in range(p.int32()):
                material = p.string()
                p.string()                     # path
                slots.append((material, p.int32(), p.int32()))
    if vertices is None or indices is None or not channels:
        raise UEModelError("the LOD has no geometry")

    # UEFormat keeps Unreal's handedness: mirror Y as the .psk export already has.  Unlike a .psk, its triangles then already face the right way
    mesh = psk_reader.PskMesh()
    mesh.name = name
    mesh.positions = (vertices * np.array((SCALE_DOWN, -SCALE_DOWN, SCALE_DOWN))).astype(np.float32)
    faces = indices.astype(np.int32)
    mesh.faces = faces

    def corners(uv):
        flipped = np.stack((uv[:, 0], 1.0 - uv[:, 1]), axis=1)[faces.reshape(-1)]
        return flipped.astype(np.float32)

    mesh.uvs = corners(channels[0])
    mesh.extra_uvs = [corners(uv) for uv in channels[1:]]
    mesh.materials = [s[0] for s in slots]
    mesh.material_index = np.zeros(len(faces), dtype=np.int32)
    for index, (_material, first, count) in enumerate(slots):
        mesh.material_index[first // 3:first // 3 + count] = index
    mesh.normals = None if normals is None else (normals * np.array((1.0, -1.0, 1.0))).astype(np.float32)
    mesh.vertex_colors = None
    if colors is not None:
        corner = colors[faces.reshape(-1)]
        rgba = corner.astype(np.float32) / 255.0
        rgba[:, :3] = psk_reader._srgb_lut()[corner[:, :3]]        # as the .psk reader does
        mesh.vertex_colors = rgba
    return mesh
