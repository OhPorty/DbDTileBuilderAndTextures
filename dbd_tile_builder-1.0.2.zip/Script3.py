"""
Script 3 - Build a level from its .umap export (lobbies, Paradise, tutorials, anything laid out by hand).

Every actor the level places is built where the level puts it, with the same code as tiles and maps: placed blueprints are built once and copied, and what the
level changes on a copy is applied to it.  Levels it streams in come along, unless Include Sub-Levels is off.
"""
import bpy

from . import dbd_blender


def main(context):
    props = context.scene.json_importer_gui_props
    json_path = bpy.path.abspath(props.json_file_path_3)
    if not json_path:
        print("Script 3: no uMap JSON selected.")
        return

    report = dbd_blender.Report()
    locator = dbd_blender.BlueprintLocator(props.model_base_path) if props.auto_build_children else None
    ctx = dbd_blender.BuildContext(props.model_base_path, report, props.hide_hidden_in_game, locator,
                                   **dbd_blender.options_from_props(props))
    # getattr: the setting only exists once the add-on has re-registered, and a pasted update may not have yet
    main_empty, owner, name = dbd_blender.build_level(json_path, ctx, getattr(props, "umap_sublevels", True))
    dbd_blender.organize_build(main_empty, owner, name)
    dbd_blender.match_game_exposure(context.scene, ctx)
    report.print_summary("uMap build: %s" % name)
    print("Script executed successfully.")
