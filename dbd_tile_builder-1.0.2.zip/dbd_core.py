"""
Pure-Python core for the DbD blueprint/tile builder (no bpy / mathutils imports).

Takes the FModel JSON of a blueprint and resolves, for every component, its transform in the
blueprint's actor space.  Kept free of Blender so it can be unit-tested on the example tiles.

Unreal -> Blender conversion
    Unreal is left-handed (X fwd, Y right, Z up, centimetres).  Blender is right-handed, metres.
    A transform M (built as T * R * S in Unreal space) becomes  C * M * C  with C = diag(1,-1,1),
    and the translation is divided by 100.  Compose in Unreal space first, convert once at the end.

Blueprint structure handled (all eras, Halloween 2023 .. Gelato and later)
    * SCS_Node -> component via ComponentTemplate (NOT via "<InternalVariableName>_GEN_VARIABLE",
      which is wrong for ChildActor<GUID>, SceneComponent_N, ActorSpawner_N, ... components).
    * Parenting through SCS ChildNodes, RootNodes, and ParentComponentOrVariableName
      (root nodes attached to a component inherited from TileBase01_C / BP_BaseEscapeTile_C).
    * InheritableComponentHandler records (inherited components overridden in this blueprint).
    * Duplicate component names under different Outers (child actor templates) are kept apart.
"""
import math
import random
import re

# --------------------------------------------------------------------------------------------
# 4x4 matrix helpers (row-major nested lists, column-vector convention: v' = M @ v)
# --------------------------------------------------------------------------------------------

IDENTITY = ((1.0, 0.0, 0.0, 0.0),
            (0.0, 1.0, 0.0, 0.0),
            (0.0, 0.0, 1.0, 0.0),
            (0.0, 0.0, 0.0, 1.0))


def mat_mul(a, b):
    return tuple(
        tuple(sum(a[i][k] * b[k][j] for k in range(4)) for j in range(4))
        for i in range(4)
    )


def mat_apply(m, v):
    """Transform point v=(x,y,z) by m."""
    return tuple(m[i][0] * v[0] + m[i][1] * v[1] + m[i][2] * v[2] + m[i][3] for i in range(3))


def safe_float(value, default=0.0):
    """float() that copes with FModel's 'Infinity' / '-Infinity' / 'NaN' strings and None."""
    try:
        if isinstance(value, str):
            v = value.strip().lower()
            if v in ("infinity", "inf"):
                return float("inf")
            if v in ("-infinity", "-inf"):
                return float("-inf")
        f = float(value)
        return default if f != f else f
    except (ValueError, TypeError):
        return default


def rotator_matrix(pitch, yaw, roll):
    """
    Unreal FRotator (degrees) -> 3x3 rotation, column-vector convention.
    Equivalent to FRotationMatrix: roll about X, then pitch about Y, then yaw about Z (all local
    to the result), i.e. the columns are the rotated X (forward), Y (right) and Z (up) axes.
    """
    sp, cp = math.sin(math.radians(pitch)), math.cos(math.radians(pitch))
    sy, cy = math.sin(math.radians(yaw)), math.cos(math.radians(yaw))
    sr, cr = math.sin(math.radians(roll)), math.cos(math.radians(roll))
    # Unreal stores row vectors (rows = rotated axes); transpose for column vectors.
    rows = (
        (cp * cy, cp * sy, sp),
        (sr * sp * cy - cr * sy, sr * sp * sy + cr * cy, -sr * cp),
        (-(cr * sp * cy + sr * sy), cy * sr - cr * sp * sy, cr * cp),
    )
    return tuple(tuple(rows[j][i] for j in range(3)) for i in range(3))


def quat_matrix(x, y, z, w):
    """Unreal FQuat (x, y, z, w) -> 3x3 rotation (same coordinate-wise formula Unreal uses)."""
    n = math.sqrt(x * x + y * y + z * z + w * w) or 1.0
    x, y, z, w = x / n, y / n, z / n, w / n
    return (
        (1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)),
        (2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)),
        (2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)),
    )


def compose_trs(loc, rot3, scale):
    """T * R * S as a 4x4 (Unreal space)."""
    sx, sy, sz = scale
    return (
        (rot3[0][0] * sx, rot3[0][1] * sy, rot3[0][2] * sz, loc[0]),
        (rot3[1][0] * sx, rot3[1][1] * sy, rot3[1][2] * sz, loc[1]),
        (rot3[2][0] * sx, rot3[2][1] * sy, rot3[2][2] * sz, loc[2]),
        (0.0, 0.0, 0.0, 1.0),
    )


def ue_to_blender(m_ue):
    """Unreal-space 4x4 (cm) -> Blender-space 4x4 (m).  Returns nested tuples."""
    c = (1.0, -1.0, 1.0)
    out = []
    for i in range(3):
        out.append(tuple(c[i] * c[j] * m_ue[i][j] for j in range(3)) + (c[i] * m_ue[i][3] / 100.0,))
    out.append((0.0, 0.0, 0.0, 1.0))
    return tuple(out)


# --------------------------------------------------------------------------------------------
# JSON helpers
# --------------------------------------------------------------------------------------------

_SPLIT_LEAF = re.compile(r"[:.]")


def parse_ref(ref):
    """
    Break an FModel object reference apart.
      "SCS_Node'BP_X_C:SimpleConstructionScript_1.SCS_Node_12'"  ->  ("SCS_Node", "BP_X_C:SimpleConstructionScript_1", "SCS_Node_12")
      "StaticMeshComponent'BP_X_C:SM_Crate_GEN_VARIABLE'"         ->  ("StaticMeshComponent", "BP_X_C", "SM_Crate_GEN_VARIABLE")
      "StaticMesh'SM_Foo'"                                        ->  ("StaticMesh", "", "SM_Foo")
    Accepts either the dict ({"ObjectName": ..., "ObjectPath": ...}) or the bare ObjectName string.
    """
    if isinstance(ref, dict):
        ref = ref.get("ObjectName")
    if not ref or not isinstance(ref, str):
        return "", "", ""
    kind = ""
    rest = ref
    if "'" in ref:
        kind, _, rest = ref.partition("'")
        rest = rest.rstrip("'")
    rest = rest.strip()
    idx = max(rest.rfind(":"), rest.rfind("."))
    if idx < 0:
        return kind, "", rest
    return kind, rest[:idx], rest[idx + 1:]


def export_path_candidates(object_path):
    """
    Relative file paths (no extension, '/'-separated) where an exported asset may live, given its Unreal
    path ("/Game/Meshes/X/SM_Y.2", "/Realm_26Liminal/Blueprints/BP_Z.1").  Exports differ in whether the
    mount point ("Game", a realm/plugin name) and the "Content" folder are kept, and which folder the user
    picked as the base, so every plausible layout is listed, most specific first.
    """
    rel = (object_path or "").split(".")[0].strip("/")
    if not rel:
        return []
    parts = rel.split("/")
    mount, tail = parts[0], "/".join(parts[1:])
    out = [rel]
    if tail:
        out += [mount + "/Content/" + tail, "Content/" + tail, tail]
        if mount == "Game":
            out.append("DeadByDaylight/Content/" + tail)
    seen = []
    for p in out:
        if p not in seen:
            seen.append(p)
    return seen


QUADRANT_TAG = re.compile(r"^Quadrant_(TopLeft|TopRight|BottomLeft|BottomRight)$")
DIRECTION_NAME = re.compile(r"(Fence|Edge)\w*?(Up|Down|Left|Right)$")

DIR_VECTOR = {"U": (0, -1), "R": (1, 0), "D": (0, 1), "L": (-1, 0)}


def rotate_direction(tag, yaw_degrees):
    """The cell offset a tile-frame direction points to once the tile is turned by `yaw_degrees` (multiples of 90)."""
    dx, dy = DIR_VECTOR[tag]
    q = int(round(yaw_degrees / 90.0)) % 4
    for _ in range(q):                    # a quarter turn clockwise on screen (rows grow downward): (x, y) -> (-y, x)
        dx, dy = -dy, dx
    return dx, dy


# A spawner weighted below this is switched off in all but name: leftovers such as EastWing's HexSpawner018, at the tile's origin against a wall with a weight of
# 0.0007.  A weighted pick all but never lands on them, so a build showing every spawn point leaves them out too.
SWITCHED_OFF_WEIGHT = 0.01

GAMEPLAY_CLASS_PATTERNS = {
    "lockers": re.compile(r"^Closet"),
    "vaults": re.compile(r"^Window"),
    "pallets": re.compile(r"Pallet"),          # BP_Pallet_C, BP_Pallet_175cm_C, BP_LH_LD01_DoublePallet_C ...
    "totems": re.compile(r"Totem"),            # BP_TotemBase_C
    "chests": re.compile(r"^BP_Chest"),        # BP_Chest_C (BP_FatherChest_C is a one-off set piece, not a spawn-pool chest)
    "hatch": re.compile(r"Hatch"),
    "hooks": re.compile(r"MeatLocker"),        # BP_SmallMeatLocker_C and its realm / event variants, BP_MeatLocker_Basement_C
}

def gameplay_class_category(class_name):
    """The panel's gameplay group of a blueprint class, or None for scenery."""
    if class_name.startswith("Generator"):
        return "generators"
    for category, pattern in GAMEPLAY_CLASS_PATTERNS.items():
        if pattern.search(class_name):
            return category
    return None


# The Outliner group of a mesh, from the folder BHVR keeps it in.  The first folder under Meshes with a meaning decides.
MESH_FOLDER_GROUPS = {
    "structures": "Structures",
    "blockers": "Blockers", "mapborders": "Blockers",
    "vegetation": "Trees and Plants", "vegetations": "Trees and Plants", "_foliage": "Trees and Plants", "nature": "Trees and Plants",
    "decals": "Decals",
    "tiles": "Ground", "industialtiles": "Ground", "hill": "Ground",
    "props": "Props", "propsmetric": "Props", "vehicules": "Props", "merged": "Props", "atlantamerge": "Props", "8thanniversary_merge": "Props",
    "corpses": "Props", "characters": "Props", "animated": "Props", "lighting": "Props", "entity": "Props", "lobby": "Props",
    "modularpipes": "Props", "killerswitches": "Props", "interactableobjects": "Props", "interactableobject": "Props",
}
# Plants filed with the structures or props.  "Tree" must start a word, so not Street, Entree or PoutreExt; not Planter or PowerPlant either.
PLANT_NAME = re.compile(r"Tree|(?<![A-Za-z])tree|(?i:bush|shrub|grass|fern|hedge|foliage|(?<!power)plant(?!er|ation))")


def mesh_group(path):
    """The Outliner group of a mesh file: its folder says, and a plant's name overrules Structures, Props and Blockers.  'Other' when neither does."""
    parts = path.replace("\\", "/").split("/")
    folders = [f.lower() for f in parts[:-1]]
    if "meshes" in folders:
        folders = folders[len(folders) - folders[::-1].index("meshes"):]
    group = next((MESH_FOLDER_GROUPS[f] for f in folders if f in MESH_FOLDER_GROUPS), "Other")
    if group in ("Structures", "Props", "Blockers", "Other") and PLANT_NAME.search(parts[-1]):
        return "Trees and Plants"
    return group


# Child actors that are never part of the level: BP_Entity is the Entity's sacrifice-animation actor every hook carries
NEVER_BUILT_CHILD_CLASSES = {"BP_Entity_C", "BP_SacrificeEnd_C"}


# Spawners switched on at random by the generator (gameplay objects).  Everything else an ActorSpawner names is level art:
# fence sections, edge decor, lights, store setups, floors ... and is built.
GAMEPLAY_SPAWN_TYPES = {"Hatch", "Bookshelves", "Totems", "MeatLocker_Small", "Searchable", "LivingWorldObjects", "BreakableWalls",
                        "Cage", "RealmSpawner", "Count", "SteamPipe", "SteamPipeButton", "Generic"}
GAMEPLAY_SPAWN_CLASSES = re.compile(r"^(Closet|Window|Bookshelf)|Pallet|Totem|Hatch|Chest|MeatLocker|Crow|Breakable|Generator", re.I)


def is_scene_spawn(placement, element):
    """True when the ActorSpawner places level art (built by default); False for gameplay objects (pallets, lockers, ...)."""
    spawn_type = (placement.props.get("Type") or "").replace("EGameplayElementType::", "")
    if spawn_type in GAMEPLAY_SPAWN_TYPES:
        return False
    return not GAMEPLAY_SPAWN_CLASSES.search(element[0])


BASEMENT_SPAWN_TYPES = ("MeatLocker_Big", "Basement_Attachments")
# BP_MeatLocker_Basement_C, the four-way hook every basement has, and the four BP_MeatLockerBasement01_C hangers it places
FIXED_HOOK = re.compile(r"MeatLocker_?Basement", re.I)
SPAWNING_TYPES = ("ActorSpawner", "TileSpawnPoint", "ActorVariationSpawner")


def _is_basement_spawn(placement):
    return (placement.props.get("Type") or "").replace("EGameplayElementType::", "") in BASEMENT_SPAWN_TYPES


def is_scene_blueprint_path(asset_path):
    """
    Spawners also place gameplay actors (pallets, lockers, chests, hatches ...) that live under /Game and are
    switched on at random by the generator.  Realm-specific scene blueprints (store setups, rides, exit gates,
    ...) and the basement floors are real level geometry.
    """
    p = "/" + (asset_path or "").strip("/")
    return p.split("/")[1:2] != ["Game"] or "/Blueprints/Floors/" in p


def strip_gen_variable(name):
    return name[: -len("_GEN_VARIABLE")] if name and name.endswith("_GEN_VARIABLE") else name


def _vec(d, keys, default, bad=None):
    """Read a vector/rotator dict.  Non-finite components ("Infinity"/"NaN" in broken exports) fall
    back to the default and are appended to `bad` so callers can warn."""
    if not isinstance(d, dict):
        return default
    out = []
    for k, dv in zip(keys, default):
        v = safe_float(d.get(k, dv), dv)
        if math.isinf(v):
            if bad is not None:
                bad.append(k)
            v = dv
        out.append(v)
    return tuple(out)


def local_matrix_ue(props, bad=None):
    """Relative transform of a component (Unreal space) from its RelativeLocation/Rotation/Scale3D."""
    props = props or {}
    loc = _vec(props.get("RelativeLocation"), ("X", "Y", "Z"), (0.0, 0.0, 0.0), bad)
    rot = _vec(props.get("RelativeRotation"), ("Pitch", "Yaw", "Roll"), (0.0, 0.0, 0.0), bad)
    scl = _vec(props.get("RelativeScale3D"), ("X", "Y", "Z"), (1.0, 1.0, 1.0), bad)
    return compose_trs(loc, rotator_matrix(*rot), scl)


def instance_matrix_ue(entry):
    """One PerInstanceSMData entry -> local 4x4 (Unreal space, relative to the instanced component)."""
    if "_matrix" in entry:                       # a foliage instance, already turned into a matrix (see Blueprint._foliage_placements)
        return entry["_matrix"]
    td = entry.get("TransformData", entry)
    t = _vec(td.get("Translation"), ("X", "Y", "Z"), (0.0, 0.0, 0.0))
    s = _vec(td.get("Scale3D"), ("X", "Y", "Z"), (1.0, 1.0, 1.0))
    r = _vec(td.get("Rotation"), ("X", "Y", "Z", "W"), (0.0, 0.0, 0.0, 1.0))
    return compose_trs(t, quat_matrix(*r), s)


MESH_TYPES = {"StaticMeshComponent"}
INSTANCED_TYPES = {"HierarchicalInstancedStaticMeshComponent", "InstancedStaticMeshComponent",
                   "FoliageInstancedStaticMeshComponent"}
CHILD_ACTOR_TYPES = {"ChildActorComponent"}
MARKER_TYPES = {"SceneComponent", "ActorSpawner"}
LIGHT_TYPES = {"PointLightComponent", "StationaryPointLightComponent", "SpotLightComponent", "RectLightComponent",
               "DirectionalLightComponent"}
AMBIENT_LIGHT_TYPES = {"SkyLightComponent"}      # ambient capture of the level: no Blender light object stands for it

ENGINE_SHAPES = {"Cube", "Plane", "Sphere", "Cylinder", "Cone", "Shape_Cube", "Shape_Plane",
                 "Shape_Sphere", "Shape_Cylinder", "Shape_Cone"}


# --------------------------------------------------------------------------------------------
# Lights
# --------------------------------------------------------------------------------------------
# Blender light objects look along local -Z (area lights too); Unreal lights shine along local +X.  In the Blender frame of a converted
# transform local x / z correspond to Unreal's x / z (y is mirrored), so the light is turned about Y by -90 degrees.
LIGHT_FRAME_FIX = ((0.0, 0.0, -1.0, 0.0),
                   (0.0, 1.0, 0.0, 0.0),
                   (1.0, 0.0, 0.0, 0.0),
                   (0.0, 0.0, 0.0, 1.0))

UNITLESS_PER_CANDELA = 625.0          # Unreal: 1 cd = 625 "unitless" (a default point light is 5000 unitless = 8 cd)
UNITLESS_FROM = 100.0                 # an export that omits IntensityUnits holds candelas, except for values this large (legacy unitless)
BLENDER_LUMINOUS_EFFICACY = 683.0     # lm per W at 555 nm


def srgb_to_linear(c8):
    c = max(0.0, min(255.0, float(c8))) / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def color_temperature_rgb(kelvin):
    """Linear sRGB (largest component 1.0) of a black body: Kim et al.'s fit of the Planckian locus, 1500 - 15000 K."""
    t = min(max(float(kelvin), 1500.0), 15000.0)
    if t <= 4000.0:
        x = -0.2661239e9 / t ** 3 - 0.2343589e6 / t ** 2 + 0.8776956e3 / t + 0.179910
    else:
        x = -3.0258469e9 / t ** 3 + 2.1070379e6 / t ** 2 + 0.2226347e3 / t + 0.240390
    if t <= 2222.0:
        y = -1.1063814 * x ** 3 - 1.34811020 * x ** 2 + 2.18555832 * x - 0.20219683
    elif t <= 4000.0:
        y = -0.9549476 * x ** 3 - 1.37418593 * x ** 2 + 2.09137015 * x - 0.16748867
    else:
        y = 3.0817580 * x ** 3 - 5.87338670 * x ** 2 + 3.75112997 * x - 0.37001483
    big_x, big_z = x / y, (1.0 - x - y) / y
    rgb = (3.2406 * big_x - 1.5372 - 0.4986 * big_z,
           -0.9689 * big_x + 1.8758 + 0.0415 * big_z,
           0.0557 * big_x - 0.2040 + 1.0570 * big_z)
    rgb = tuple(max(0.0, v) for v in rgb)
    top = max(rgb) or 1.0
    return tuple(v / top for v in rgb)


def light_candela(intensity, units, kind, outer_degrees=44.0):
    """Luminous intensity in candelas of an Unreal light: its Intensity in `units` ('Candelas' | 'Lumens' | 'Unitless')."""
    if units == "Lumens":
        if kind in ("POINT", "SPOT"):
            # Unreal spreads a spot light's lumens as a point light's, over the whole sphere: narrowing the cone does not brighten it.  Dividing by the
            # cone's solid angle made narrow spots tens of times too bright (Foundry's 350 lm spot came out at 11 kW).
            return intensity / (4.0 * math.pi)
        return intensity / math.pi                  # rect light: a flat Lambertian emitter, flux = pi * intensity
    if units == "Unitless":
        return intensity / UNITLESS_PER_CANDELA
    return intensity


def light_watts(candela, blender_type):
    """
    Blender 'Power' (W) giving the same intensity.  Blender's watts are not radiometric watts: a point or spot light of P W has the radiant
    intensity P / (4 pi^2) W/sr, an area light the normal-direction intensity P / pi^2 W/sr; 683 lm/W turns candelas into that.
    """
    factor = math.pi ** 2 if blender_type == "AREA" else 4.0 * math.pi ** 2
    return candela * factor / BLENDER_LUMINOUS_EFFICACY


MIN_TUBE_LENGTH_M = 0.05                # a point / spot light with a longer SourceLength is a tube (capsule) light
MIN_TUBE_THICKNESS_M = 0.02
# A light's size is what makes its shadows soft in Blender (a tiny one casts razor-sharp shadows), and the lights are not drawn to the camera, so
# the size is free to choose: at least MIN (42% of the exported lights have no source radius and Unreal filters its shadows), at most MAX (the
# export has radii up to 9 m, median 4 cm, 90% below 34 cm; a huge one blurs every shadow to nothing).
MIN_SOURCE_RADIUS_M = 0.1
MAX_SOURCE_RADIUS_M = 0.3


def soft_radius(radius_m, minimum=MIN_SOURCE_RADIUS_M):
    """The Blender light size (m) for an Unreal source radius: kept between `minimum` and MAX_SOURCE_RADIUS_M."""
    return min(max(radius_m, minimum), MAX_SOURCE_RADIUS_M)


def light_unmapped(props, comp_type):
    """Exported light settings that Blender has no equivalent for (they are listed on the light and in the build report)."""
    p = props or {}
    out = []
    if isinstance(p.get("IESTexture"), dict):
        out.append("IES profile")
    if isinstance(p.get("LightFunctionMaterial"), dict):
        out.append("light function material")
    if isinstance(p.get("LightingChannels"), dict):
        out.append("lighting channels")
    if p.get("bUseInverseSquaredFalloff") is False:
        out.append("non-inverse-square falloff")
    if comp_type == "RectLightComponent" and ("BarnDoorAngle" in p or "BarnDoorLength" in p):
        out.append("barn doors")
    if p.get("bAffectTranslucentLighting") is False:
        out.append("does not light translucent surfaces")
    if p.get("bCastVolumetricShadow") is False:
        out.append("no volumetric shadow")
    if any(k in p for k in ("ShadowBias", "ShadowSlopeBias", "ShadowSharpen", "ShadowResolutionScale", "ContactShadowLength")):
        out.append("shadow tuning (bias / sharpen / resolution / contact shadows)")
    if "MaxDrawDistance" in p:
        out.append("draw distance fade")
    return out


def light_off_reason(props, intensity_on):
    """Why a light does not shine in the export ('' when it does): hidden, not affecting the world (fog / translucency only), no intensity."""
    p = props or {}
    if p.get("bVisible") is False:
        return "bVisible false (off until a script switches it on)"
    if p.get("bAffectsWorld") is False:
        return "bAffectsWorld false (translucent / volumetric only)"
    if not intensity_on:
        return "intensity 0 (set at runtime)"
    return ""


def light_from_props(comp_type, props):
    """
    The values of an Unreal light component, converted for Blender and with Unreal's defaults for everything the export leaves out.
    Returns a dict: kind (Unreal's: 'POINT' | 'SPOT' | 'AREA' | 'SUN'), blender_type ('POINT' | 'SPOT' | 'AREA' | 'SUN': a point / spot light
    with a SourceLength is a tube and becomes an area light), color (linear rgb, temperature applied), candela, watts (sun: strength in
    W/m2), ue_intensity, ue_units, units_guessed, radius_m (attenuation), source_radius_m, outer_degrees, inner_degrees, width_m / height_m
    (rect), tube_length_m, thickness_m, source_angle_degrees (sun), temperature, cast_shadows, mobility, is_static, volume_factor,
    specular_scale, unmapped, switched_off, off_reason.
    """
    kind = ("SPOT" if comp_type == "SpotLightComponent" else "AREA" if comp_type == "RectLightComponent"
            else "SUN" if comp_type == "DirectionalLightComponent" else "POINT")
    p = props or {}
    intensity = safe_float(p.get("Intensity"), 10.0 if kind == "SUN" else 5000.0)
    if not math.isfinite(intensity):
        intensity = 0.0
    units = str(p.get("IntensityUnits") or "").replace("ELightUnits::", "")
    guessed = units not in ("Candelas", "Lumens", "Unitless")
    if kind == "SUN":
        units, guessed = "Lux", False
    elif guessed:
        units = "Unitless" if intensity >= UNITLESS_FROM else "Candelas"
    outer = safe_float(p.get("OuterConeAngle"), 44.0)
    inner = safe_float(p.get("InnerConeAngle"), 0.0)
    col = p.get("LightColor")
    if isinstance(col, dict):
        rgb = tuple(srgb_to_linear(safe_float(col.get(k), 255.0)) for k in ("R", "G", "B"))
    else:
        rgb = (1.0, 1.0, 1.0)
    temp = safe_float(p.get("Temperature"), 6500.0)
    if p.get("bUseTemperature") is True:
        tint = color_temperature_rgb(temp)
        rgb = tuple(a * b for a, b in zip(rgb, tint))
    cd = max(0.0, intensity if kind == "SUN" else light_candela(intensity, units, kind, outer))
    tube = (max(0.0, safe_float(p.get("SourceLength"), 0.0)) / 100.0) if kind in ("POINT", "SPOT") else 0.0
    # Unreal: SourceRadius is the light's shape for specular highlights, SoftSourceRadius the one that softens the diffuse light and shadows,
    # which is what a Blender light's size does - so the soft radius is used when the export has one.
    radius_ue = max(0.0, safe_float(p.get("SoftSourceRadius") if "SoftSourceRadius" in p else p.get("SourceRadius"), 0.0)) / 100.0
    radius = min(radius_ue, MAX_SOURCE_RADIUS_M)          # the builder raises it to the panel's minimum softness
    blender_type = "AREA" if (kind == "AREA" or tube >= MIN_TUBE_LENGTH_M) else kind
    reason = light_off_reason(p, cd > 0.0)
    return {
        "kind": kind, "blender_type": blender_type, "color": rgb, "candela": cd,
        "watts": cd / BLENDER_LUMINOUS_EFFICACY if kind == "SUN" else light_watts(cd, blender_type),
        "tube_length_m": tube if blender_type == "AREA" and kind != "AREA" else 0.0,
        "thickness_m": max(2.0 * radius, MIN_TUBE_THICKNESS_M),
        "source_angle_degrees": safe_float(p.get("LightSourceAngle"), 0.5357),
        "ue_intensity": intensity, "ue_units": units, "units_guessed": guessed,
        "radius_m": max(0.0, safe_float(p.get("AttenuationRadius"), 1000.0)) / 100.0,
        "source_radius_m": radius, "source_radius_ue_m": radius_ue,
        "outer_degrees": outer, "inner_degrees": inner,
        "width_m": max(0.0, safe_float(p.get("SourceWidth"), 64.0)) / 100.0,
        "height_m": max(0.0, safe_float(p.get("SourceHeight"), 64.0)) / 100.0,
        "temperature": temp if p.get("bUseTemperature") is True else None,
        "cast_shadows": p.get("CastShadows") is not False,
        "mobility": str(p.get("Mobility") or "omitted").replace("EComponentMobility::", ""),          # Static | Stationary | Movable | omitted
        "is_static": p.get("Mobility") == "EComponentMobility::Static",         # only an explicit Static: an omitted value is the engine default
        "volume_factor": max(0.0, safe_float(p.get("VolumetricScatteringIntensity"), 1.0)),     # fog scattering, Unreal default 1
        "specular_scale": max(0.0, safe_float(p.get("SpecularScale"), 1.0)),
        "unmapped": light_unmapped(p, comp_type),
        "switched_off": bool(reason), "off_reason": reason,
    }


# --------------------------------------------------------------------------------------------
# Blueprint model
# --------------------------------------------------------------------------------------------

class Placement(object):
    """A component with its resolved actor-space transform."""
    __slots__ = ("name", "var", "item", "type", "world", "source", "parent", "class_override")

    def __init__(self, name, var, item, world, source, parent):
        self.name = name          # Blender-friendly name (variable name, else cleaned component name)
        self.var = var            # SCS InternalVariableName / ICH SCSVariableName (may be None)
        self.item = item          # the component's JSON entry
        self.type = item.get("Type", "")
        self.world = world        # Unreal-space 4x4, cm, actor space
        self.source = source      # 'scs' | 'inherited' | 'loose'
        self.parent = parent      # name of the parent placement / inherited container (diagnostics)
        self.class_override = None   # (class_name, asset_path, weight) that replaces what the spawner names (realm hook variants)

    @property
    def props(self):
        return self.item.get("Properties") or {}

    # ---- classification -------------------------------------------------------------------
    @property
    def is_mesh(self):
        return self.type in MESH_TYPES or "SkeletalMeshComponent" in self.type

    @property
    def is_instanced(self):
        return self.type in INSTANCED_TYPES

    @property
    def is_child_actor(self):
        return self.type in CHILD_ACTOR_TYPES

    @property
    def is_marker(self):
        return self.type in MARKER_TYPES

    @property
    def is_light(self):
        return self.type in LIGHT_TYPES

    def light_info(self):
        """Blender-ready light data for a light component (see `light_from_props`), or None for anything else."""
        return light_from_props(self.type, self.props) if self.is_light else None

    # ---- data accessors -------------------------------------------------------------------
    def mesh(self):
        """(mesh_name, object_path) or (None, None)."""
        sm = self.props.get("StaticMesh")
        if not isinstance(sm, dict):
            # skeletal meshes (lockers, rigs) are built in their reference pose
            sm = self.props.get("SkeletalMesh") or self.props.get("SkinnedAsset")
        if not isinstance(sm, dict):
            return None, None
        _, _, name = parse_ref(sm)
        return (name or None), sm.get("ObjectPath")

    def is_engine_shape(self):
        name, path = self.mesh()
        return bool(name) and (name in ENGINE_SHAPES or (path or "").startswith("/Engine/"))

    @property
    def hidden_in_game(self):
        p = self.props
        # bRenderInMainPass off: navigation and shadow proxies, outlines and effect shells, which the game never draws as a surface
        return bool(p.get("bHiddenInGame")) or p.get("bVisible") is False or p.get("bRenderInMainPass") is False

    def child_actor_class(self):
        """Class name of a ChildActorComponent, e.g. 'BP_GLO_FrozenCorpse_04_C' (or None)."""
        p = self.props
        _, _, leaf = parse_ref(p.get("ChildActorClass"))
        if leaf:
            return leaf
        # Inherited child actors carry no ChildActorClass; the template's type prefix is the class:
        #   "BP_Effect_Mist_C'BP_TL_Fr_HD231_C:BP_Effect_MistXXXX.BP_Effect_MistXXXX_BP_Effect_Mist_C_CAT'"
        kind, _, _ = parse_ref(p.get("ChildActorTemplate"))
        return kind or None

    def scene_element(self):
        """
        (class_name, asset_path, weight) of the blueprint an ActorSpawner spawns at runtime
        (ActivatedSceneElement), highest weight first, or None.
        """
        els = self.props.get("ActivatedSceneElement")
        if not isinstance(els, list):
            return None
        best = None
        for e in els:
            ref = (e or {}).get("SceneElement") or {}
            path = ref.get("AssetPathName") or ""
            if not path:
                continue
            weight = safe_float((e or {}).get("Weight"), 1.0)
            if best is None or weight > best[2]:
                best = (path.rsplit(".", 1)[-1], path, weight)
        return best

    @property
    def is_generator_spawn(self):
        """TileSpawnPoint where the generator-type interactable goes (the tiles' InteractableSpawn points)."""
        return self.type == "TileSpawnPoint" and (
            self.props.get("TileSpawnPointType") == "ETileSpawnPointType::InteractableObject"
            or (self.name or "").startswith("InteractableSpawn"))

    def _generator_class(self):
        names = []
        for e in (self.props.get("ObjectSpawnModifier") or []):
            names.append(((e or {}).get("AssetPathName") or "").rsplit(".", 1)[-1])
        names.append(((self.props.get("Visualization") or {}).get("AssetPathName") or "").rsplit(".", 1)[-1])
        for n in names:
            if n.startswith("Generator"):
                return n
            if n.startswith("BP_Editor_Generator"):
                return "GeneratorNoPole_C" if "NoPole" in n else "GeneratorStandard_C"
        return "GeneratorStandard_C"

    def spawn_target(self):
        """(class_name, asset_path, weight) of what this spawner/spawn point places at runtime, or None."""
        if self.class_override:
            return self.class_override
        if self.type == "ActorSpawner":
            return self.scene_element()
        if self.type == "ActorVariationSpawner":
            path = (self.props.get("Visualization") or {}).get("AssetPathName") or ""
            return (path.rsplit(".", 1)[-1], path, 1.0) if path and "/specialevents/" not in path.lower() else None
        if self.is_generator_spawn:
            cls = self._generator_class()
            return (cls, "/Game/Blueprints/GameplayElements/Interactable/Generator/%s.%s" % (cls[:-2], cls), 1.0)
        return None

    def class_path_hint(self):
        """Unreal object path of the class this component spawns (for locating its JSON)."""
        if self.type in SPAWNING_TYPES:
            el = self.spawn_target()
            return el[1].rsplit(".", 1)[0] + ".0" if el else None
        ref = self.props.get("ChildActorClass")
        return ref.get("ObjectPath") if isinstance(ref, dict) else None

    def gameplay_category(self):
        """'generators' / 'hooks' / 'lockers' / 'vaults' / 'pallets' / 'totems' for a gameplay spawn point, else None."""
        if self.is_generator_spawn:
            return "generators"
        if self.type != "ActorSpawner":
            return None
        el = self.scene_element()
        if not el or is_scene_spawn(self, el):
            return None
        if (self.props.get("Type") or "").replace("EGameplayElementType::", "") == "MeatLocker_Small":
            return "hooks"
        for cat, rx in GAMEPLAY_CLASS_PATTERNS.items():
            if rx.search(el[0]):
                return cat
        return None

    @property
    def is_optional_spawner(self):
        return self.props.get("ActivatedByDefault") is False

    def quadrant(self):
        """
        (class_name, object_path) of the room this tile corner can hold ((None, None) when the slot names none), or None when it is no room slot.  Tiles (TileBase01) have four 'Quadrant_*' ActorSpawners at their
        corners; the generator fills each grid vertex where four tiles meet with ONE room blueprint (the InterTile quads, e.g. BP_Qat_Quad_Square_Lab_01).
        The spawner's Visualization is the room the editor shows.  FakeQuad / IntraTileQuad spawners only reserve space the building tile fills itself.
        """
        if self.type != "ActorSpawner":
            return None
        tags = self.props.get("ComponentTags") or []
        if not any(QUADRANT_TAG.match(str(t)) for t in tags):
            return None
        if "IntraTileQuad" in tags or "fakequad" in (self.name or "").lower():
            return None
        vis = self.props.get("Visualization")
        path = (vis or {}).get("AssetPathName") if isinstance(vis, dict) else None
        if not path or not path.rsplit(".", 1)[-1].startswith("BP_"):
            return (None, None)                 # a slot without a Visualization: the realm's room pool decides (see `quadrant_realm`)
        return path.rsplit(".", 1)[-1], path

    def quadrant_realm(self):
        """The 'QCT_<Realm>' tag of a room slot (which realm's rooms fit), or ''."""
        for t in self.props.get("ComponentTags") or []:
            if str(t).startswith("QCT_"):
                return str(t)
        return ""

    def direction_tag(self):
        """
        'U' / 'R' / 'D' / 'L' for the optional directional edge spawners of border tiles (ActorSpawnerFenceLeft, ActorSpawnerEdgeUp ...):
        a fence spoke from the tile centre toward that edge, or a pillar on that edge.  Directions are in the tile's own frame
        (Left = -X, Right = +X, Up = -Y, Down = +Y).  The generator switches them on where the fence line continues to a neighbouring
        border tile.  None for every other spawner.
        """
        if self.type != "ActorSpawner" or not self.is_optional_spawner:
            return None
        m = DIRECTION_NAME.search(self.name or "")
        return {"Up": "U", "Right": "R", "Down": "D", "Left": "L"}[m.group(2)] if m else None

    @property
    def world_yaw(self):
        """Yaw (degrees, Unreal) of this component in actor space."""
        return math.degrees(math.atan2(self.world[1][0], self.world[0][0]))

    def override_materials(self):
        """List (index = slot) of material names or None."""
        out = []
        for m in self.props.get("OverrideMaterials") or []:
            _, _, leaf = parse_ref(m)
            out.append(leaf or None)
        return out

    def instances(self):
        """Instance transforms (Unreal space, actor space) for ISM/HISM components."""
        data = self.item.get("PerInstanceSMData") or []
        return [mat_mul(self.world, instance_matrix_ue(e)) for e in data]

    def expected_instance_count(self):
        p = self.props
        for k in ("NumBuiltInstances", "InstanceCountToRender"):
            if isinstance(p.get(k), (int, float)):
                return int(p[k])
        return len(self.item.get("PerInstanceSMData") or [])

    def blender_matrix(self):
        return ue_to_blender(self.world)


def scatter_count(items):
    """
    How many meshes a scatter blueprint places (BP_KNY_Random_Grass1 and its kind): its construction script drops 'Number of meshes' clumps at random in a radius
    when the game runs.  The export also holds the instances left over from the editor, 45 to 50 of them, and building those made grass five times too dense.
    None for anything else.
    """
    for it in items:
        if isinstance(it, dict) and str(it.get("Name", "")).startswith("Default__"):
            n = (it.get("Properties") or {}).get("Number of meshes")
            if isinstance(n, (int, float)) and n > 0:
                return int(n)
    return None


def _normalize_items(items):
    """
    Newer FModel exports write "Outer" as an object reference ({"ObjectName": "...'BP_X_C'", ...}) instead of
    the plain name string older exports use.  Reduce it to the leaf name so lookups behave the same.
    """
    for it in items:
        outer = it.get("Outer")
        if isinstance(outer, dict):
            it["Outer"] = parse_ref(outer)[2] or None


class _Node(object):
    __slots__ = ("key", "name", "var", "comp", "children_keys", "parent_key", "inh_parent", "owner_class")


# Every realm has its own hook look: a BP_SmallMeatLocker_<Name> subclass that swaps the mesh.  Most tiles still name the plain BP_SmallMeatLocker_C and
# the game substitutes the realm's hook at runtime (the exports hold no table for it), so the build works it out from where the tile's JSON sits:
#   Realm plugin (Plugins/Realms/Realm_26Liminal/...): the hook blueprint inside the plugin (BP_SmallMeatLocker_Waffle), found by looking, so a new realm works
#                                                      as soon as it is exported.  The name is the realm's code name: it never matches the folder.
#   Classic realm (Blueprints/Tiles/16-Wales/..., InterTile/14-Qatar_Quads/...): REALM_HOOKS.  Hospital, Qatar and Eclipse tiles name their hook themselves;
#                   England's and Kenya's tiles name Sandman and Legion in places; Boreal's hook mesh is BRL-prefixed and Swamp's carries swamp mushrooms; the
#                   other killer-named hooks are paired with the killer's home realm.  
# Only the plain hook is replaced: a tile that names a variant itself keeps it.  Realms not listed have no known hook of their own and keep the plain one.
HOOK_PLAIN = "BP_SmallMeatLocker_C"
HOOK_FOLDER = "/Game/Blueprints/GameplayElements/Interactable/MeatLocker/"
REALM_HOOKS = {"Hospital": "Doctor", "Qatar": "Qatar", "Wales": "Wales", "Eclipse": "Eclipse", "Ion": "Ion", "Meteor": "Meteor",
               "Quantum": "Quantum", "Umbra": "Umbra", "Wormhole": "Wormhole", "Gelato": "Gelato", "Quiche": "Quiche",
               "Farm": "HillBilly", "Asylum": "Nurse", "Suburbs": "MM", "Swamp": "Witch", "Boreal": "Huntress", "England": "Sandman",
               "Finland": "Pig", "Haiti": "Spirit", "Kenya": "Legion", "Ukraine": "Gunslinger"}
_REALM_FOLDER = re.compile(r"[/\\]\d\d-([A-Za-z]+)(?:_Quads)?[/\\]")
_REALM_PLUGIN = re.compile(r"^(.*[/\\](Realm_[^/\\]+))[/\\]")
_PLUGIN_HOOKS = {}


def realm_of_path(path):
    """'Wales' for .../Blueprints/Tiles/16-Wales/BP_TL_....json, else ''."""
    m = _REALM_FOLDER.search(path or "")
    return m.group(1) if m else ""


def plugin_hook(root, mount):
    """(class_name, asset_path) of the hook blueprint inside a realm plugin's Content/Blueprints, or None."""
    import os
    if root not in _PLUGIN_HOOKS:
        found = None
        content = os.path.join(root, "Content")
        for dirpath, dirs, files in os.walk(os.path.join(content, "Blueprints")):
            dirs.sort()
            for f in sorted(files):
                if f.startswith("BP_SmallMeatLocker_") and f.endswith(".json"):
                    name = f[:-5]
                    rel = os.path.relpath(dirpath, content).replace(os.sep, "/")
                    found = (name + "_C", "/%s/%s/%s.%s_C" % (mount, rel, name, name))
                    break
            if found:
                break
        _PLUGIN_HOOKS[root] = found
    return _PLUGIN_HOOKS[root]


def realm_hook_for(json_path):
    """(class_name, asset_path) of the hook of the realm this blueprint's JSON belongs to, or None."""
    m = _REALM_PLUGIN.search(json_path or "")
    if m:
        return plugin_hook(m.group(1), m.group(2))
    name = REALM_HOOKS.get(realm_of_path(json_path))
    if not name:
        return None
    cls = "BP_SmallMeatLocker_%s" % name
    return cls + "_C", "%s%s.%s_C" % (HOOK_FOLDER, cls, cls)


class Blueprint(object):
    """
    Parsed blueprint JSON.  After construction:
        .class_name      e.g. 'BP_TL_Fr_HD231_C'
        .placements      list[Placement]  (SCS nodes, then inherited overrides, then loose components)
        .warnings        list[str]        (things that could not be resolved exactly)
    """

    def __init__(self, items, name_hint="", parent_loader=None):
        if not isinstance(items, list):
            raise ValueError("not a blueprint export (expected a JSON list of objects)")
        items = [i for i in items if isinstance(i, dict)]
        self.items = items
        _normalize_items(items)
        self.name_hint = name_hint
        self.realm_hook = None      # (class_name, asset_path) of the tile's realm hook, set by load_blueprint
        self.parent_loader = parent_loader      # (class_name, object_path) -> Blueprint | None, for inherited components
        self._parent = False
        self.warnings = []
        self.class_name = self._find_class_name()
        self.scatter_count = scatter_count(items)
        self._index()
        self._parse_scs()
        self.placements = []
        self._resolve()
        self._check_transform_data()

    # ---- indexing -------------------------------------------------------------------------
    def _find_class_name(self):
        classes = [it["Name"] for it in self.items if it.get("Type") == "BlueprintGeneratedClass" and it.get("Name")]
        scs_outer = next((it["Outer"] for it in self.items
                          if it.get("Type") == "SimpleConstructionScript" and it.get("Outer")), None)
        want = (self.name_hint + "_C") if self.name_hint else None
        # A JSON can carry more than one class (e.g. an exported parent): prefer the one the file is named
        # after, then the one that owns the SCS, then the first.
        for cand in (want, scs_outer):
            if cand and (cand in classes or cand == scs_outer):
                return cand
        if classes:
            return classes[0]
        return scs_outer or want or ""

    def _index(self):
        self.by_outer_name = {}      # (outer, name) -> item
        self.by_name = {}            # name -> first item whose Outer is this class, else first seen
        self.scs_nodes = {}          # (scs_name, node_name) -> item
        self.scs_nodes_by_name = {}  # node_name -> item (first)
        self.scs = None
        self.ich_records = {}        # SCSVariableName -> record
        for it in self.items:
            t, name, outer = it.get("Type"), it.get("Name"), it.get("Outer")
            if name is None:
                continue
            if t == "SCS_Node":
                self.scs_nodes[(outer, name)] = it
                self.scs_nodes_by_name.setdefault(name, it)
                continue
            if t == "SimpleConstructionScript":
                if self.scs is None:
                    self.scs = it
                continue
            if t == "InheritableComponentHandler":
                for rec in (it.get("Properties") or {}).get("Records", []):
                    var = (rec.get("ComponentKey") or {}).get("SCSVariableName")
                    if var:
                        self.ich_records.setdefault(var, rec)
                continue
            self.by_outer_name.setdefault((outer, name), it)
            current = self.by_name.get(name)
            if current is None or (outer == self.class_name and current.get("Outer") != self.class_name):
                self.by_name[name] = it

    def find_component(self, ref):
        """Resolve a ComponentTemplate-style reference to the component's JSON entry."""
        kind, outer, leaf = parse_ref(ref)
        if not leaf:
            return None
        outer_leaf = re.split(r"[:.]", outer)[-1] if outer else ""
        for key in ((outer_leaf, leaf), (self.class_name, leaf)):
            it = self.by_outer_name.get(key)
            if it is not None:
                return it
        return self.by_name.get(leaf)

    # ---- SCS ------------------------------------------------------------------------------
    def _scs_key_from_ref(self, ref):
        _, outer, leaf = parse_ref(ref)
        scs_name = re.split(r"[:.]", outer)[-1] if outer else None
        if (scs_name, leaf) in self.scs_nodes:
            return (scs_name, leaf)
        for key in self.scs_nodes:
            if key[1] == leaf:
                return key
        return None

    def _parse_scs(self):
        self.nodes = {}
        for key, it in self.scs_nodes.items():
            p = it.get("Properties") or {}
            n = _Node()
            n.key = key
            n.name = key[1]
            n.var = p.get("InternalVariableName")
            n.comp = self.find_component(p.get("ComponentTemplate"))
            n.children_keys = []
            n.parent_key = None
            n.inh_parent = p.get("ParentComponentOrVariableName") or None
            n.owner_class = p.get("ParentComponentOwnerClassName") or None
            if p.get("ComponentTemplate") and n.comp is None:
                self.warnings.append("SCS node %s: component template %s not found" % (n.name, p["ComponentTemplate"].get("ObjectName")))
            self.nodes[key] = n
        for key, it in self.scs_nodes.items():
            for ref in (it.get("Properties") or {}).get("ChildNodes", []):
                ckey = self._scs_key_from_ref(ref)
                if ckey is None or ckey == key:
                    continue
                child = self.nodes[ckey]
                if child.parent_key is None:
                    child.parent_key = key
        self.var_to_node = {}
        for n in self.nodes.values():
            if n.var and n.var not in self.var_to_node:
                self.var_to_node[n.var] = n
        # The actor's root component: the first RootNode that is not attached to an inherited component.  Unreal replaces its relative
        # transform with the spawn transform, so a stale offset on it (e.g. 'Root' at (-180, 600) in BP_HAD_ExitGate_01, left over from
        # when it was a child of DefaultSceneRoot) is NOT applied.  Blueprints that inherit their root (tiles) have none.
        self.actor_root_key = None
        if self.scs is not None:
            for ref in (self.scs.get("Properties") or {}).get("RootNodes", []):
                key = self._scs_key_from_ref(ref)
                if key is not None and key in self.nodes and self.nodes[key].inh_parent is None:
                    self.actor_root_key = key
                    break

    # ---- parent class ---------------------------------------------------------------------
    def _super_ref(self):
        for it in self.items:
            if it.get("Type") == "BlueprintGeneratedClass" and it.get("Name") == self.class_name:
                ref = it.get("Super")
                if isinstance(ref, dict):
                    _, _, leaf = parse_ref(ref)
                    return leaf, ref.get("ObjectPath")
        return None, None

    def parent_blueprint(self):
        """The parent class's Blueprint (TileBase01_C for tiles), or None when it can't be found."""
        if self._parent is False:
            self._parent = None
            name, path = self._super_ref()
            if name and self.parent_loader is not None:
                try:
                    self._parent = self.parent_loader(name, path)
                except Exception as exc:
                    self.warnings.append("parent class %s could not be read: %s" % (name, exc))
                if self._parent is None:
                    self.warnings.append("parent class %s not found - inherited components keep only the values this blueprint overrides" % name)
        return self._parent

    def component_props(self, var):
        """Properties of the component `var` as this class has them: the parent class's values with this class's own on top."""
        merged = {}
        par = self.parent_blueprint()
        if par is not None:
            merged.update(par.component_props(var))
        node = self.var_to_node.get(var)
        comp = node.comp if node is not None else None
        if comp is None and var in self.ich_records:
            comp = self.find_component(self.ich_records[var].get("ComponentTemplate"))
        if comp is not None:
            merged.update(comp.get("Properties") or {})
        return merged

    def _effective_component(self, var, comp):
        """An overriding record lists only the properties that differ from the parent's: fill in the rest (location, spawner type ...)."""
        par = self.parent_blueprint()
        if par is None:
            return comp
        base = par.component_props(var)
        if not base:
            return comp
        merged = dict(base)
        merged.update(comp.get("Properties") or {})
        eff = dict(comp)
        eff["Properties"] = merged
        return eff

    # ---- resolution -----------------------------------------------------------------------
    def _is_inherited_root(self, var):
        """
        True when `var` is the actor root of a parent class.  Unreal replaces the root's relative transform with the spawn transform, so an override of
        it means nothing: Hawkins' two escape tiles override BP_BaseEscapeTile's Root with (0, -1590), which threw the whole exit one cell out of the map.
        """
        par = self.parent_blueprint()
        if par is None:
            return var == "Root"                 # the parent class was not exported: 'Root' is what the tile base classes call it
        while par is not None:
            if par.actor_root_key is not None and par.nodes[par.actor_root_key].var == var:
                return True
            par = par.parent_blueprint()
        return False

    def _inherited_world(self, var):
        """World matrix of a component inherited from the parent class (identity unless overridden here)."""
        if self._is_inherited_root(var):
            return IDENTITY
        rec = self.ich_records.get(var)
        if rec:
            comp = self.find_component(rec.get("ComponentTemplate"))
            if comp is not None:
                return self._local(self._effective_component(var, comp))
        return IDENTITY

    def _local(self, comp):
        if comp is None:
            return IDENTITY
        bad = []
        m = local_matrix_ue(comp.get("Properties"), bad)
        if bad:
            self.warnings.append("%s: non-finite %s in transform (export bug) - treated as default"
                                 % (comp.get("Name"), "/".join(bad)))
        return m

    def _resolve(self):
        memo = {}
        in_progress = set()

        def world_of(node):
            if node.key in memo:
                return memo[node.key]
            if node.key in in_progress:
                self.warnings.append("Cycle in SCS hierarchy at %s" % node.name)
                return IDENTITY
            in_progress.add(node.key)
            local = IDENTITY if node.key == self.actor_root_key else self._local(node.comp)
            if node.parent_key is not None:
                base = world_of(self.nodes[node.parent_key])
            elif node.inh_parent:
                owner = self.var_to_node.get(node.inh_parent)
                if owner is not None and owner is not node and node.owner_class in (None, self.class_name):
                    base = world_of(owner)
                else:
                    base = self._inherited_world(node.inh_parent)
            else:
                base = IDENTITY
            in_progress.discard(node.key)
            memo[node.key] = mat_mul(base, local)
            return memo[node.key]

        used = set()

        def parent_label(node):
            if node.parent_key is not None:
                return self.nodes[node.parent_key].var or self.nodes[node.parent_key].name
            return node.inh_parent

        for key in sorted(self.nodes, key=lambda k: self._node_order(k)):
            node = self.nodes[key]
            world = world_of(node)
            if node.comp is None:
                continue
            used.add(id(node.comp))
            self.placements.append(Placement(
                self._display_name(node.var, node.comp), node.var, node.comp, world, "scs", parent_label(node)))

        for var, rec in self.ich_records.items():
            comp = self.find_component(rec.get("ComponentTemplate"))
            if comp is None or id(comp) in used:
                continue
            used.add(id(comp))
            comp = self._effective_component(var, comp)
            self.placements.append(Placement(
                self._display_name(var, comp), var, comp, self._local(comp), "inherited", None))

        # The parent class's meshes this class leaves as they are, where the parent puts them.  Each Quiche shop's floor and its front walls (the
        # storefront openings cut into them) are only in the shop's master in the mesh folder, and were never built.  Only meshes: the tile base
        # classes add no geometry, and their spawners and markers are handled by the game's rules.
        par = self.parent_blueprint()
        if par is not None:
            own = set(self.ich_records) | {n.var for n in self.nodes.values() if n.var}
            for pp in par.placements:
                if pp.var in own or not (pp.is_mesh or pp.is_instanced):
                    continue
                self.placements.append(Placement(pp.name, pp.var, pp.item, pp.world, "parent", pp.parent))
        self.placements.extend(self._foliage_placements())

    def _foliage_placements(self):
        """
        Painted foliage: a DBDInstancedFoliageComponent keeps, per FoliageType, the instances' Location / Rotation / DrawScale3D in the actor's
        space.  The newer realms keep all their tile grass and plants here (Meteor, Quantum, Boreal, Apple Pie, Umbra, Ion, Wormhole, Quiche:
        about 22,000 instances), and none of it was built.  Each FoliageType becomes an instanced mesh placement the builder already handles.
        """
        out = []
        for p in list(self.placements):
            if p.type != "DBDInstancedFoliageComponent":
                continue
            for k, entry in enumerate(p.props.get("Foliage") or []):
                if not isinstance(entry, dict):
                    continue
                ftype = self.find_component(entry.get("FoliageType"))
                mesh = ((ftype or {}).get("Properties") or {}).get("Mesh")
                instances = entry.get("Instances") or []
                if not isinstance(mesh, dict) or not instances:
                    continue
                data = []
                for inst in instances:
                    local = local_matrix_ue({"RelativeLocation": inst.get("Location"), "RelativeRotation": inst.get("Rotation"),
                                             "RelativeScale3D": inst.get("DrawScale3D")})
                    data.append({"_matrix": local})
                _, _, mesh_name = parse_ref(mesh)
                item = {"Type": "FoliageInstancedStaticMeshComponent", "Name": "%s_%s" % (p.name, mesh_name or k),
                        "Properties": {"StaticMesh": mesh}, "PerInstanceSMData": data}
                out.append(Placement("%s_%s" % (p.name, mesh_name or k), None, item, p.world, "foliage", p.name))
        return out

        # Anything buildable that belongs to this class but nothing referenced (older/odd exports).
        buildable = MESH_TYPES | INSTANCED_TYPES | CHILD_ACTOR_TYPES | MARKER_TYPES | LIGHT_TYPES
        for it in self.items:
            if it.get("Type") in buildable and it.get("Outer") == self.class_name and id(it) not in used:
                used.add(id(it))
                self.placements.append(Placement(
                    self._display_name(None, it), None, it, self._local(it), "loose", None))

    def _check_transform_data(self):
        """Some exports (seen in Realm 26) drop RelativeLocation/Rotation from StaticMeshComponents entirely."""
        meshes = [p for p in self.placements if p.is_mesh and p.mesh()[0] and not p.is_engine_shape()]
        if len(meshes) < 10:
            return
        bare = [p for p in meshes if not any(k in p.props for k in ("RelativeLocation", "RelativeRotation"))]
        self.transforms_missing = len(bare) >= 0.9 * len(meshes)
        if self.transforms_missing:
            self.warnings.append(
                "%d of %d mesh components have NO RelativeLocation/RelativeRotation in this JSON - the export is missing "
                "their transforms, so they cannot be positioned (they will all sit at their parent's origin). "
                "Re-export with a matching FModel version / .usmap." % (len(bare), len(meshes)))

    transforms_missing = False

    def _node_order(self, key):
        m = re.search(r"(\d+)$", key[1])
        return (key[0] or "", int(m.group(1)) if m else 0, key[1])

    @staticmethod
    def _display_name(var, comp):
        return var or strip_gen_variable(comp.get("Name") or "Unnamed")

    # ---- convenience ----------------------------------------------------------------------
    def scene_spawn_placements(self, seed=1, include_optional=True, include_edges=True):
        """
        ActorSpawners that spawn scene blueprints.  Spawners stacked on (nearly) the same spot are alternatives of
        one slot (e.g. HallSetup3/4/5, StoreSetup01/02/03): one is chosen, seeded and stable per blueprint.
        `include_optional` also takes spawners that are off by default (basement floors and their attachments).
        """
        cands = []
        always = []
        for p in self.placements:
            if p.type != "ActorSpawner":
                continue
            el = p.scene_element()
            if not el or not is_scene_spawn(p, el):
                continue
            if p.is_optional_spawner and not include_optional:
                continue
            if not include_edges and "EdgeObjects" in str(p.props.get("Type") or ""):
                continue                                # a full map takes the ones the game keeps (dbd_procgen.build_edges)
            if _is_basement_spawn(p):                  # the basement and its floor / door / rail share the basement's spot (and
                always.append(p)                       # each other's): they are parts of one thing, never alternatives of each other
                continue
            cands.append((p, mat_apply(p.world, (0.0, 0.0, 0.0))))
        clusters = []
        for p, pos in cands:
            for cl in clusters:
                q = cl[0][1]
                dyaw = abs((p.world_yaw - cl[0][0].world_yaw + 180.0) % 360.0 - 180.0)
                if (pos[0] - q[0]) ** 2 + (pos[1] - q[1]) ** 2 + (pos[2] - q[2]) ** 2 < 60.0 ** 2 and dyaw < 5.0:
                    cl.append((p, pos))
                    break
            else:
                clusters.append([(p, pos)])
        chosen = list(always)
        for cl in clusters:
            cl.sort(key=lambda t: t[0].name)
            classes = {t[0].scene_element()[0] for t in cl}
            if len(classes) > 1:
                rng = random.Random("%s|%d|%.0f|%.0f" % (self.class_name, seed, cl[0][1][0], cl[0][1][1]))
                chosen.append(rng.choice(cl)[0])
            else:
                chosen.append(cl[0][0])
        return chosen

    def gameplay_spawn_placements(self, categories):
        """
        Gameplay actors the generator switches on at random, one placement per candidate spawn point:
        'lockers' (ClosetStandard...), 'vaults' (WindowStandard...), 'pallets', 'totems', 'hooks' (the MeatLocker spawners, the
        basement's hook included) and 'generators' (InteractableSpawn points).
        """
        out = []
        for p in self.placements:
            cat = p.gameplay_category()
            if cat not in categories:
                continue
            if safe_float(p.props.get("Weight", 1.0), 1.0) < SWITCHED_OFF_WEIGHT:
                continue
            if cat == "hooks":                  # whatever hook variant the realm uses
                el = p.scene_element()
                if self.realm_hook and el[0] == HOOK_PLAIN:
                    p.class_override = self.realm_hook + (el[2],)
            out.append(p)
        return out

    def fixed_hook_placements(self):
        """
        The basement's own hook (BP_TL_ST_Basement's Hook spawner: no spawn type, one choice, BP_MeatLocker_Basement_C).  The game's rules place the
        random hooks (MeatLocker_Small) and the basement itself, never this one: the basement always has its four-way hook.
        """
        out = []
        for p in self.placements:
            if p.type != "ActorSpawner" or p.gameplay_category() != "hooks":
                continue
            if (p.props.get("Type") or "").replace("EGameplayElementType::", "") == "MeatLocker_Small":
                continue
            el = p.scene_element()
            if el and FIXED_HOOK.search(el[0]) and safe_float(p.props.get("Weight", 1.0), 1.0) >= SWITCHED_OFF_WEIGHT:
                out.append(p)
        return out

    def variation_placements(self):
        """ActorVariationSpawners: an object the map's colour tags can swap for another, and a default one otherwise."""
        return [p for p in self.placements if p.type == "ActorVariationSpawner" and p.spawn_target()]

    def quadrant_placements(self):
        """The tile's room slots (see `Placement.quadrant`)."""
        return [p for p in self.placements if p.quadrant()]

    def child_actor_placements(self):
        def never_built(p):
            ref = p.props.get("ChildActorClass")
            name = (ref.get("ObjectName") if isinstance(ref, dict) else "") or ""
            return any(("'%s'" % c) in name or name == c for c in NEVER_BUILT_CHILD_CLASSES)
        return [p for p in self.placements if p.is_child_actor and not never_built(p)]


_NON_FINITE = re.compile(rb"(?<![A-Za-z])-?(?:Infinity|NaN)(?![A-Za-z])")
_QUALITY_CACHE = {}


def export_defects(path):
    """Number of non-finite values (Infinity / NaN) in an export: the signature of a damaged / outdated FModel export."""
    import os
    try:
        st = os.stat(path)
    except OSError:
        return 1 << 30
    key = (os.path.abspath(path), st.st_size, st.st_mtime)
    if key not in _QUALITY_CACHE:
        try:
            with open(path, "rb") as f:
                _QUALITY_CACHE[key] = len(_NON_FINITE.findall(f.read()))
        except OSError:
            _QUALITY_CACHE[key] = 1 << 30
    return _QUALITY_CACHE[key]


def choose_export(paths):
    """
    Which of several exports of the same asset to use (None for an empty list).  Exports often hold a blueprint twice (an old copy and a newer
    one, in different folders) and the old one can still have non-finite transforms or generator spawn points at their base-class defaults.
    Order: fewest non-finite values, then the most recently modified, then the path (so the choice never depends on listing order).  It looks
    at the data and only then at file dates, because copying or unzipping an export resets dates.
    """
    import os
    paths = [p for p in paths if p]
    if not paths:
        return None

    def mtime(p):
        try:
            return os.path.getmtime(p)
        except OSError:
            return 0.0
    return min(paths, key=lambda p: (export_defects(p), -mtime(p), os.path.normcase(p)))


_PARENT_CACHE = {}


def make_parent_loader(json_path, find=None):
    """
    Loader for a blueprint's parent class.  `find(class_name, object_path)` (e.g. BlueprintLocator.find) is tried first, then the export path
    of the parent under the folders above `json_path`, then the same file name in those folders.
    """
    import os

    def loader(class_name, object_path):
        path = find(class_name, object_path) if find else None
        if not path:
            leaf = (class_name[:-2] if class_name.endswith("_C") else class_name) + ".json"
            here = os.path.dirname(os.path.abspath(json_path))
            for depth in range(10):
                found = [os.path.join(here, t.replace("/", os.sep) + ".json") for t in export_path_candidates(object_path)]
                found = [c for c in found if os.path.isfile(c)]
                if not found and depth < 3 and os.path.isfile(os.path.join(here, leaf)):
                    found = [os.path.join(here, leaf)]
                if found:
                    path = choose_export(found)
                    break
                up = os.path.dirname(here)
                if up == here:
                    break
                here = up
        if not path:
            return None
        key = os.path.normcase(os.path.abspath(path))
        if key not in _PARENT_CACHE:
            _PARENT_CACHE[key] = None                # guards a class that names itself as parent
            _PARENT_CACHE[key] = load_blueprint(path, find=find)
        return _PARENT_CACHE[key]
    return loader


def load_blueprint(json_path, find=None, parent_loader=None):
    import json
    import os
    with open(json_path, "r", encoding="utf-8") as f:
        items = json.load(f)
    hint = os.path.splitext(os.path.basename(json_path))[0]
    bp = Blueprint(items, hint, parent_loader or make_parent_loader(json_path, find))
    bp.realm_hook = realm_hook_for(json_path)
    return bp
