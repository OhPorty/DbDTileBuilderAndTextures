"""
Pure-Python map planner (no bpy): turns a Paper2D tile map (e.g. LM_Liminal.json) plus the realm's tile
blueprints into a list of tile placements on the grid.

What the data tells us (verified on Realm 26 / Liminal)
    * Map layers are 9x9 grids of PackedTileIndex.  Base index 0 is the outer ring, the playable area is the
      cells that hold any tile (index >= 0).
    * Every tile blueprint's class defaults carry  Dimension {X,Y} (footprint in cells), Type, Path, Number,
      MaximumCount.  The map's "Numbers" layer uses the same Number: 250 = unconstrained, 251 = ordinary tile,
      252/253/254 = a specific tile (the escape tiles) must go in that cell.
    * Tile origins sit at the centre of their footprint; one cell = 16 m (1600 uu).
    * Border tiles are authored on their -Y edge (fence straight, escape exit); yaw 0/90/180/270 turns that to the
      top/right/bottom/left edge.  A corner piece's fence runs from the cell centre toward -X and -Y, so it joins its two
      neighbours at yaw 180/270/0/90 on the NW/NE/SE/SW corner (checked on the real meshes; the Paths layer paints the same).

What the data does NOT tell us
    * The meaning of the Base (2..5), Paths and Types indices lives in tileset assets that aren't exported, and
      the real generator picks tiles randomly under those rules.  Interior cells are therefore filled by a
      seeded random pick of tiles that fit (respecting MaximumCount), with the unlimited filler tile
      (MaximumCount >= 100, Number 253) used for leftover cells.  Change the seed for another layout.
"""
import json
import os
import random
import re
import time

CELL_SIZE_UU = 1600.0
FLAG_MASK = 0xE0000000          # Paper2D flip / rotate flag bits
INDEX_MASK = 0x1FFFFFFF
# How strictly a tile's Path must agree with the cell's Paths value (non-border tiles; border tiles stay lenient):
#   "tile"  - a tile that has a Path needs a cell with exactly that Path
#   "both"  - additionally a cell without a Path only takes tiles without one
PATH_STRICTNESS = "tile"

# Multiplies the planner's per-level search time and step limits (raise it for maps that fall back to a looser level).
SEARCH_SCALE = 1.0

UNCONSTRAINED_NUMBERS = (250, 251)
UNLIMITED = 100

# Decoded from the tileset sprite sheets (tiles.png / pathTiles.png) and checked against the maps and tiles:
#   Base layer  = the tile Type the cell must hold (blue brick = Blocker ring, trees = Forest, house = Building,
#                 maze = Maze, moai statue = Landmark).  Cell counts per type equal the tile footprints exactly.
#   Paths layer = the tile's Path type (dead end, corner, crossroads, T-junction, oriented crossroads icons).
BASE_TYPES = {0: "Blocker", 2: "Forest", 3: "Building", 4: "Maze", 5: "Landmark"}
PATH_TYPES = {0: "Straight", 1: "DeadEnd", 2: "Corner", 3: "Crossroads", 4: "TJunction", 7: "OrientedCrossroads"}

FLIP_H, FLIP_V, FLIP_D = 0x80000000, 0x40000000, 0x20000000

# The rotation painted into a Paths cell is the rotation of the path icon.  Interior tiles take it directly (offset 0).  For BORDER
# pieces the tile's native geometry is turned by a fixed amount relative to the icon (measured on ~700 border pieces: tile yaw = painted
# yaw - offset, offset TJunction 0 (95% of 434), Corner 180 (81% of 235), DeadEnd 180 (85% of 46), Straight 0); border pieces use the
# verified outward-facing rule instead.  Applying a non-zero offset to interior buildings is unverified, so it is not done.
PATH_ICON_OFFSET = {}


def yaw_from_flags(flags):
    """
    Paper2D flip flags -> tile yaw.  Diagonal + vertical turns the sprite 90 deg counter-clockwise on screen
    (yaw 270 in Unreal's clockwise-positive yaw with rows running toward +Y), diagonal + horizontal is 90 deg
    clockwise (yaw 90), horizontal + vertical is 180.  Plain mirrors have no rotation (returns None).
    """
    key = (bool(flags & FLIP_D), bool(flags & FLIP_H), bool(flags & FLIP_V))
    return {(False, False, False): 0, (True, True, False): 90, (False, True, True): 180, (True, False, True): 270}.get(key)


# --------------------------------------------------------------------------------------------
# Map file
# --------------------------------------------------------------------------------------------

class TileMap(object):
    def __init__(self, name, width, height, layers, package=""):
        self.name = name
        self.width = width
        self.height = height
        self.layers = layers          # layer name -> list[height][width] of (index or None, flags)
        self.package = package

    @property
    def realm_mount(self):
        parts = [p for p in (self.package or "").split("/") if p]
        return parts[0] if parts else ""

    def index(self, layer, col, row):
        grid = self.layers.get(layer)
        if grid is None:
            return None
        return grid[row][col][0]


def load_tilemap(path):
    with open(path, "r", encoding="utf-8") as f:
        items = json.load(f)
    if not isinstance(items, list):
        raise ValueError("not a Paper2D tile map export")
    tile_map = next((i for i in items if isinstance(i, dict) and i.get("Type") == "PaperTileMap"), None)
    if tile_map is None:
        raise ValueError("no PaperTileMap in %s" % path)
    props = tile_map.get("Properties") or {}
    # Unreal leaves properties at their default out of the export: a 4x4 map (Wales) has no MapWidth / MapHeight at all
    width, height = int(props.get("MapWidth", 4)), int(props.get("MapHeight", 4))
    layers = {}
    names = {}
    for it in items:
        if not (isinstance(it, dict) and it.get("Type") == "PaperTileLayer"):
            continue
        p = it.get("Properties") or {}
        lname = ((p.get("LayerName") or {}).get("SourceString")) or it.get("Name")
        names[it.get("Name")] = lname
        w, h = int(p.get("LayerWidth", width)), int(p.get("LayerHeight", height))
        cells = p.get("AllocatedCells") or []
        if cells and len(cells) != w * h and "LayerWidth" not in p:      # size not exported and not the default: infer it
            side = int(round(len(cells) ** 0.5))
            if side * side == len(cells):
                w = h = side
                width, height = max(width, w), max(height, h)
        grid = []
        for r in range(h):
            row = []
            for c in range(w):
                cell = cells[r * w + c] if r * w + c < len(cells) else {"PackedTileIndex": -1}
                # PackedTileIndex is a SIGNED int32 with the flip flags in the top three bits, so any cell flipped horizontally
                # (bit 31) is negative.  Only the all-ones value -1 means "empty".
                packed = int(cell.get("PackedTileIndex", -1)) & 0xFFFFFFFF
                if packed == 0xFFFFFFFF or ("TileSet" in cell and cell["TileSet"] is None):      # a cell with no tile set is empty, whatever its index says
                    row.append((None, 0))
                else:
                    row.append((packed & INDEX_MASK, packed & FLAG_MASK))
            grid.append(row)
        layers[lname] = grid
    result = TileMap(tile_map.get("Name") or os.path.splitext(os.path.basename(path))[0], width, height, layers, tile_map.get("Package", ""))
    result.layer_order = [names.get(re.split(r"[.:]", (ref or {}).get("ObjectName", "").rstrip("'"))[-1]) for ref in props.get("TileLayers") or []]
    return result


# --------------------------------------------------------------------------------------------
# Tile catalogue
# --------------------------------------------------------------------------------------------

class Tile(object):
    def __init__(self, name, json_path, number, dim, ttype, path_type, max_count):
        self.name = name                      # file stem, e.g. BP_TL_St_16x16_Bathroom
        self.class_name = name + "_C"
        self.json_path = json_path
        self.number = number
        self.dim = dim                        # (cells along X, cells along Y) at yaw 0
        self.type = ttype
        self.path_type = path_type
        self.max_count = max_count if max_count else UNLIMITED

    @property
    def is_border(self):
        return "_Bd_" in self.name

    @property
    def is_filler(self):
        return self.max_count >= UNLIMITED and not self.is_border

    def footprint(self, yaw):
        w, h = self.dim
        return (h, w) if int(round(yaw)) % 180 else (w, h)

    def __repr__(self):
        return "<Tile %s N%s %sx%s %s>" % (self.name, self.number, self.dim[0], self.dim[1], self.type)


def load_tile(json_path):
    stem = os.path.splitext(os.path.basename(json_path))[0]
    with open(json_path, "r", encoding="utf-8") as f:
        items = json.load(f)
    if not isinstance(items, list):
        return None
    cdo = next((i for i in items if isinstance(i, dict) and i.get("Name") == "Default__%s_C" % stem), None)
    if cdo is None:
        return None
    p = cdo.get("Properties") or {}
    dim = p.get("Dimension") or {}
    return Tile(
        stem, json_path,
        int(p["Number"]) if isinstance(p.get("Number"), (int, float)) else None,
        (max(1, int(dim.get("X", 1))), max(1, int(dim.get("Y", 1)))),
        str(p.get("Type", "")).replace("ETileType::", ""),
        str(p.get("Path", "")).replace("EPathType::", ""),
        int(p.get("MaximumCount", UNLIMITED)),
    )


def find_tile_jsons(map_path, search_root=None):
    """
    Tile blueprint JSONs of the realm the map belongs to.
      1. realm plugin export: the map sits in <Realm>/Content/ProceduralLevelGeneration/..., tiles in <Realm>/Content/Blueprints
      2. classic export: .../TiledMaps/Completed/<NN-Realm>/Map.json, tiles in .../Blueprints/Tiles/<NN-Realm>/ (searched
         under `search_root`)
      3. otherwise every BP_TL_*.json under `search_root` whose path contains the realm's mount name (not for 'Game')
    """
    out = []
    probe = os.path.abspath(map_path)
    while True:
        parent = os.path.dirname(probe)
        if parent == probe:
            probe = None
            break
        probe = parent
        if os.path.basename(probe).lower() == "content":
            break
    if probe:
        base = os.path.join(probe, "Blueprints")
        for dirpath, _d, files in os.walk(base):
            out += [os.path.join(dirpath, f) for f in files if f.startswith("BP_TL_") and f.endswith(".json")]
    if out or not (search_root and os.path.isdir(search_root)):
        return sorted(out)

    realm_dir = os.path.basename(os.path.dirname(os.path.abspath(map_path)))
    if realm_dir.lower() not in ("completed", "tiledmaps", ""):
        for dirpath, _d, _f in os.walk(search_root):
            parts = [x.lower() for x in dirpath.split(os.sep)]
            if os.path.basename(dirpath).lower() == realm_dir.lower() and "tiles" in parts and "blueprints" in parts:
                for dp, _dd, files in os.walk(dirpath):
                    out += [os.path.join(dp, f) for f in files if f.startswith("BP_TL_") and f.endswith(".json")]
    if out:
        return sorted(out)

    mount = load_tilemap(map_path).realm_mount
    if mount and mount.lower() not in ("game", "engine"):
        for dirpath, _d, files in os.walk(search_root):
            if mount.lower() in dirpath.lower():
                out += [os.path.join(dirpath, f) for f in files if f.startswith("BP_TL_") and f.endswith(".json")]
    return sorted(out)


def load_catalog(json_paths, notes=None):
    """
    Tile objects for the given JSONs, ONE per tile name.  Exports often hold the same tile twice (an old copy and a newer one in another
    folder); counting both would double every MaximumCount and let unique buildings appear twice.  `dbd_core.choose_export` picks the better
    copy (fewest non-finite values, then newest).  `notes`, if given, gets one line saying how many tiles had more than one copy.
    """
    from . import dbd_core
    by_stem = {}
    for path in json_paths:
        by_stem.setdefault(os.path.splitext(os.path.basename(path))[0], []).append(path)
    def retired(path):
        return any(part.lower() in ("backup", "backups") for part in os.path.normpath(path).split(os.sep))

    by_stem = {stem: [p for p in paths if not retired(p)] for stem, paths in by_stem.items()}     # the developers' Backups folders are not in the game
    by_stem = {stem: paths for stem, paths in by_stem.items() if paths}
    best = {stem: (None, dbd_core.choose_export(paths)) for stem, paths in by_stem.items()}
    dup = sum(1 for paths in by_stem.values() if len(set(paths)) > 1)
    if dup and notes is not None:
        notes.append("%d tiles exist in more than one export folder; used the copy with the fewest damaged values, then the newest" % dup)
    tiles = []
    for _stem, (_rank, path) in sorted(best.items()):
        try:
            t = load_tile(path)
        except Exception:
            t = None
        if t is not None:
            tiles.append(t)
    return tiles


# --------------------------------------------------------------------------------------------
# Planner
# --------------------------------------------------------------------------------------------

class Placed(object):
    def __init__(self, tile, col, row, w, h, yaw, role):
        self.tile, self.col, self.row, self.w, self.h, self.yaw, self.role = tile, col, row, w, h, yaw, role

    @property
    def center_cell(self):
        return (self.col + (self.w - 1) / 2.0, self.row + (self.h - 1) / 2.0)

    def cells(self):
        return [(self.col + dc, self.row + dr) for dr in range(self.h) for dc in range(self.w)]


class Plan(object):
    def __init__(self, tilemap, placements, warnings, bbox, mode=""):
        self.tilemap, self.placements, self.warnings, self.bbox, self.mode = tilemap, placements, warnings, bbox, mode

    def world_position_uu(self, placed, row_sign=1.0):
        """Unreal-space (x, y) of the tile origin, map centre at (0, 0)."""
        c0, r0, c1, r1 = self.bbox
        mc, mr = (c0 + c1) / 2.0, (r0 + r1) / 2.0
        cx, cy = placed.center_cell
        return ((cx - mc) * CELL_SIZE_UU, (cy - mr) * CELL_SIZE_UU * row_sign)

    def preview(self):
        letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        grid = [["." for _ in range(self.tilemap.width)] for _ in range(self.tilemap.height)]
        legend = []
        for i, pl in enumerate(self.placements):
            ch = letters[i % len(letters)]
            for c, r in pl.cells():
                grid[r][c] = ch
            legend.append("%s = %s (yaw %d, %s)" % (ch, pl.tile.name, pl.yaw % 360, pl.role))
        head = ("interior solved with: %s\n" % self.mode) if self.mode else ""
        return head + "\n".join(" ".join(row) for row in grid) + "\n" + "\n".join(legend)


def _is_path_tile(t):
    """Pt_* tiles are the road pieces of the classic realms; they belong only where the Paths layer draws a path."""
    return "_pt_" in t.name.lower()


MAX_ESCAPES = 2
STACK_RADIUS = 0.6              # metres: gameplay spawn points closer than this are alternatives of one spot
SPREAD_SAMPLES = 8              # choose_spawns: spots compared per pick (more = more even, less random)
GATE_ATTEMPTS = 6               # how many pairs of gate cells to try before leaving the gates to the search


def _is_escape_tile(t):
    return "scape" in t.name.lower()


def _is_corner_tile(t):
    return t.path_type == "Corner" or "corner" in t.name.lower()


def plan_map(tilemap, tiles, seed=1, base_layer="Base", numbers_layer="Numbers", border_index=0):
    """
    Lay the realm's tiles out on the map grid, ring included, as one exact-cover search.  Per cell the map says:
        Base    -> tile Type (0 Blocker ring ... 5 Landmark)
        Paths   -> tile Path type (0 Straight, 1 DeadEnd, 2 Corner, 3 Crossroads, 4 TJunction, 7 OrientedCrossroads);
                   Paper2D flip flags give the tile's rotation
        Numbers -> tile Number minus one  (the exports number tiles 1-based: tile.Number == cell Number + 1)
    A tile must match on every cell it covers, fit its Dimension footprint, and respect MaximumCount.  Border tiles are
    rotated by where they sit (outward on the outer edge, corner pieces on the corners).  If no tiling satisfies all
    rules the rules are relaxed step by step (see `Plan.mode`); ties are broken by the seed.
    """
    rng = random.Random(seed)
    warnings = []
    W, H = tilemap.width, tilemap.height
    base = tilemap.layers.get(base_layer)
    if base is None:
        raise ValueError("map has no '%s' layer (layers: %s)" % (base_layer, ", ".join(tilemap.layers)))
    playable = {(c, r) for r in range(H) for c in range(W) if base[r][c][0] is not None}
    if not playable:
        raise ValueError("the Base layer is empty")
    c0, c1 = min(c for c, _ in playable), max(c for c, _ in playable)
    r0, r1 = min(r for _, r in playable), max(r for _, r in playable)
    corners = {(c0, r0): 0, (c1, r0): 90, (c1, r1): 180, (c0, r1): 270}
    order = sorted(playable, key=lambda cr: (cr[1], cr[0]))

    type_at = lambda c, r: BASE_TYPES.get(tilemap.index(base_layer, c, r))
    path_at = lambda c, r: PATH_TYPES.get(tilemap.index("Paths", c, r))
    number_at = lambda c, r: tilemap.index(numbers_layer, c, r)

    def flags_at(c, r):
        grid = tilemap.layers.get("Paths")
        return grid[r][c][1] if grid else 0

    def flagged_yaw(c, r):
        """Rotation painted into the Paths layer at this cell (None when the cell has no rotation flags)."""
        fl = flags_at(c, r)
        return yaw_from_flags(fl) if fl else None

    def painted_tile_yaw(t, c, r):
        """
        The tile's yaw according to the Paths layer: the painted icon rotation (no flags = 0) minus the tile's fixed offset to
        its icon.  None when the cell carries no path at all.
        """
        idx = tilemap.index("Paths", c, r)
        if idx is None:
            return None
        icon_yaw = flagged_yaw(c, r) or 0
        ptype = t.path_type or PATH_TYPES.get(idx)
        return (icon_yaw - PATH_ICON_OFFSET.get(ptype, 0)) % 360

    border_tiles = [t for t in tiles if t.type == "Blocker"]
    has_corner_tiles = any(_is_corner_tile(t) for t in border_tiles)
    has_plain_border = any(not _is_corner_tile(t) for t in border_tiles)

    # Which sides of a cell face outside the map?  (works for any map shape, not just rectangles)
    edge_yaw = {"U": 0, "R": 90, "D": 180, "L": 270}
    corner_yaw = {frozenset("UL"): 0, frozenset("UR"): 90, frozenset("DR"): 180, frozenset("DL"): 270}
    sides = (("U", 0, -1), ("R", 1, 0), ("D", 0, 1), ("L", -1, 0))
    outside = {cell: {d for d, dc, dr in sides if (cell[0] + dc, cell[1] + dr) not in playable} for cell in playable}
    is_corner_cell = {cell: frozenset(o) in corner_yaw for cell, o in outside.items()}

    def border_yaws(t, c, r):
        o = outside[(c, r)]
        if len(o) == 1:
            pref = [edge_yaw[next(iter(o))]]
            if t.path_type == "Straight" and not _is_escape_tile(t) and path_at(c, r) == "Straight":
                pref = [painted_tile_yaw(t, c, r)]       # a corridor piece (Hawkins, Treatment Theatre): it runs along the edge the way the map paints it
        elif frozenset(o) in corner_yaw:
            # The rotation painted on the map, else a corner piece's arms must point at the two neighbouring ring cells, which is 180 degrees from
            # the outside corner.  (Top-down plots of the real meshes join only that way, and 294 of 313 painted corner cells say the same; the
            # other 19 are unpainted cells holding plain tiles, and Eclipse's Vista pieces, which the painted rotation covers.)
            painted = flagged_yaw(c, r)
            if painted is None:
                outward = corner_yaw[frozenset(o)]
                painted = (outward + 180) % 360 if (_is_corner_tile(t) or t.path_type == "DeadEnd") else outward
            pref = [painted]
        else:
            diag = {d for d, dc, dr in (("UL", -1, -1), ("UR", 1, -1), ("DR", 1, 1), ("DL", -1, 1))
                    if (c + dc, r + dr) not in playable}
            if len(o) == 0 and len(diag) == 1:           # inner step of a diagonal cut: the painted rotation (it equals the outside-diagonal
                painted = painted_tile_yaw(t, c, r)      # rotation in 88 of 97 cases), else the one outside diagonal
                pref = [painted if painted is not None else corner_yaw[frozenset(next(iter(diag)))]]
            else:
                return [0, 90, 180, 270]                 # a Blocker cell inside the map
        if t.dim[0] * t.dim[1] > 1:                      # a long piece may run along either edge that meets this cell
            return pref + [y for y in (0, 90, 180, 270) if y not in pref]
        return pref

    def orient_border(t, cells, yaw):
        """Face a placed multi-cell border piece outward: the side that is outside for every cell it covers."""
        outs = None
        for cell in cells:
            outs = set(outside[cell]) if outs is None else outs & outside[cell]
        if outs and len(outs) == 1:
            want = edge_yaw[next(iter(outs))]
            if want % 180 == yaw % 180:          # same footprint orientation, so only the facing flips
                return want
        return yaw

    def border_rank(t, c, r):
        """The chosen gate cells first, corner pieces on corner cells, straight pieces elsewhere (preference only - the Number rule decides)."""
        if t.name in escape_names:
            return -1 if (c, r) in gate_cells else 1
        if not (has_corner_tiles and has_plain_border):
            return 0
        wants_corner = is_corner_cell[(c, r)] or path_at(c, r) == "Corner"       # the steps of a diagonal edge are painted Corner too
        return 0 if wants_corner == _is_corner_tile(t) else 1

    # A cell's Number only constrains it when some tile of the cell's Type carries Number+1.  The exports have cells whose Number
    # matches nothing (Farm's corner cells say 26 -> 27, but the only Number-27 tile is the Barn), and one such cell must not make
    # the whole map unsolvable.
    sat_pairs = {(t.type, t.number) for t in tiles if t.number is not None}
    sat_numbers = {t.number for t in tiles if t.number is not None}

    def number_binds(cell, n):
        ty = type_at(*cell)
        return ((ty, n + 1) in sat_pairs) if ty is not None else ((n + 1) in sat_numbers)

    pool = list(tiles)
    rng.shuffle(pool)
    pool.sort(key=lambda t: t.is_filler)         # unlimited filler tiles are the last resort
    by_type = collections_defaultdict_list()
    for t in pool:
        by_type[t.type].append(t)

    # A map has two exit gates, on the straight outer edge - never on a corner or an inner step.  Several maps give every border cell the same
    # Number and make the escape tile unlimited, so without this cap the search fills the ring with escape tiles instead of fences / corners.
    escape_names = {t.name for t in tiles if _is_escape_tile(t)}

    def pick_gate_cells():
        """
        Where the single-cell gates go when the map does not pin them: two straight-edge cells far apart.  Without this the number of gates was
        down to luck (often one) and they could land side by side.  Maps that leave only two possible cells, or whose gates are longer pieces, stay
        as they are.
        """
        singles = [t for t in tiles if t.name in escape_names and t.dim == (1, 1) and t.type == "Blocker"]

        def fits(t, cell):
            n, pa = number_at(*cell), path_at(*cell)
            if t.number is not None and n is not None and t.number != n + 1 and number_binds(cell, n):
                return False
            return not (t.path_type and pa is not None and pa != t.path_type)

        eligible = [x for x in order if type_at(*x) == "Blocker" and len(outside[x]) == 1 and any(fits(t, x) for t in singles)]
        if len(eligible) <= MAX_ESCAPES:
            return set()

        def fillable(a, b):
            """Two gates can stand on these cells: different gate tiles, or one that may be used twice (Hawkins has one for tee and one for straight cells)."""
            return any(fits(x, a) and fits(y, b) and (x is not y or x.max_count >= MAX_ESCAPES) for x in singles for y in singles)

        first = rng.choice(eligible)
        far = [x for x in eligible if x != first and fillable(first, x)]
        if not far:
            return {first}
        apart = lambda x: abs(x[0] - first[0]) + abs(x[1] - first[1])
        widest = max(apart(x) for x in far)
        return {first, rng.choice([x for x in far if apart(x) >= widest - 1])}

    gate_cells = pick_gate_cells()

    def escape_ok(t, cells, count):
        """cells=None: only the count is checked (before the footprint is known)."""
        if t.name not in escape_names:
            return True
        if sum(count[n] for n in escape_names) >= MAX_ESCAPES:
            return False
        if cells is None:
            return True
        if gate_cells and len(cells) == 1 and cells[0] not in gate_cells:
            return False
        if len(cells) > 1:                      # long escape pieces (Wales, Eclipse) may run into a corner cell
            return all(outside[x] for x in cells)
        return len(outside[cells[0]]) == 1      # a single-cell gate: a straight outer edge (not a corner cell, not an inner step)

    class _Abort(Exception):
        pass

    def solve(path_budget, use_number, free_rotation, limit=60000, seconds=2.5):
        taken, count, steps, result = set(), collections_counter(), [0], []
        deadline = time.monotonic() + seconds
        mismatches = [0]

        def tile_ok(t, cells):
            for cell in cells:
                ty = type_at(*cell)
                if ty is not None and ty != t.type:
                    return False
                if path_budget is not None and t.type == "Blocker":
                    pa = path_at(*cell)                 # border tiles: only a conflicting Path counts against them
                    if t.path_type and pa is not None and pa != t.path_type:
                        return False
                if use_number and t.number is not None:
                    n = number_at(*cell)
                    if n is not None and t.number != n + 1 and number_binds(cell, n):
                        return False
            return True

        def path_penalty(t, cells):
            """
            1 when the Path rule is violated (only counted when the rule is on): a tile whose Path differs from a cell's
            Path, or a real path tile (Pt_*) on a cell without one.  Other tiles carry a Path tag as an attribute only
            (in Quiche every tile is 'TJunction'), so a cell without a Path value accepts them.
            """
            if path_budget is None or t.type == "Blocker" or not t.path_type:
                return 0
            for x in cells:
                pa = path_at(*x)
                if pa is None:
                    if _is_path_tile(t):
                        return 1
                elif pa != t.path_type:
                    return 1
            return 0

        def rec(i):
            steps[0] += 1
            if steps[0] > limit or (steps[0] % 128 == 0 and time.monotonic() > deadline):
                raise _Abort()
            while i < len(order) and order[i] in taken:
                i += 1
            if i == len(order):
                return True
            c, r = order[i]
            ty = type_at(c, r)
            cands = list(by_type.get(ty, ()) if ty is not None else pool)
            rng.shuffle(cands)                      # a different tile for neighbouring cells, not the first one that fits
            if ty == "Blocker":
                cands.sort(key=lambda t: (border_rank(t, c, r), count[t.name]))
            else:
                # even when the Path rule is relaxed, a path tile (Pt_*) is only a last resort on a cell that doesn't match it
                pa_here = path_at(c, r)
                cands.sort(key=lambda t: (1 if (t.path_type and t.path_type != pa_here) else 0, t.is_filler, count[t.name]))
            for t in cands:
                if count[t.name] >= t.max_count or not escape_ok(t, None, count):
                    continue
                want = painted_tile_yaw(t, c, r)             # rotation painted under this cell, if any
                if t.type == "Blocker":
                    yaws = border_yaws(t, c, r)           # border pieces face outward (verified on Liminal / Quiche)
                elif want is not None:
                    yaws = [want] if not free_rotation else [want] + [y for y in (0, 90, 180, 270) if y != want]
                else:
                    yaws = [0, 90, 180, 270] if free_rotation else [0]
                for yaw in yaws:
                    w, h = t.footprint(yaw)
                    cells = [(c + dc, r + dr) for dr in range(h) for dc in range(w)]
                    if any(x not in playable or x in taken for x in cells) or not tile_ok(t, cells) or not escape_ok(t, cells, count):
                        continue
                    pen = path_penalty(t, cells)
                    if pen and mismatches[0] + pen > path_budget:
                        continue
                    taken.update(cells)
                    count[t.name] += 1
                    mismatches[0] += pen
                    result.append((t, c, r, w, h, yaw))
                    if rec(i + 1):
                        return True
                    result.pop()
                    mismatches[0] -= pen
                    count[t.name] -= 1
                    taken.difference_update(cells)
            return False

        try:
            return result if rec(0) else None
        except _Abort:
            return None

    # (label, (path_budget, use_number, free_rotation), seconds).  path_budget: 0 strict, n = up to n path tiles may sit on
    # a cell that doesn't carry their Path (one odd cell no longer throws the whole Path rule away), None = ignore Path.
    ladder = [
        ("type + footprint + Path + Number, rotation from Paths flags", (0, True, False), 3.0),
        ("type + footprint + Path + Number, free rotation", (0, True, True), 9.0),
        ("type + footprint + Number, Path mostly (<= 3 mismatches)", (3, True, True), 1.5),
        ("type + footprint + Number, Path mostly (<= 8 mismatches)", (8, True, True), 1.5),
        ("type + footprint + Number", (None, True, True), 2.0),
        ("type + footprint + Path", (0, False, True), 1.5),
        ("type + footprint only", (None, False, True), 1.5),
    ]
    solved, mode = None, ""
    # The chosen gate cells must not cost layout quality: without a strict solution try other cells, and only then leave the gates to the search.
    for attempt in range(GATE_ATTEMPTS if gate_cells else 0):
        for label, args, seconds in ladder[:2]:
            solved = solve(*args, limit=int(60000 * SEARCH_SCALE), seconds=seconds * SEARCH_SCALE / (attempt + 1))
            if solved is not None:
                mode = label
                break
        if solved is not None:
            break
        gate_cells.clear()
        if attempt + 1 < GATE_ATTEMPTS:
            gate_cells.update(pick_gate_cells())
    for label, args, seconds in ladder:
        if solved is not None:
            break
        solved = solve(*args, limit=int(60000 * SEARCH_SCALE), seconds=seconds * SEARCH_SCALE)
        if solved is not None:
            mode = label
            break
    placements = []
    if solved is not None:
        for t, c, r, w, h, yaw in solved:
            if t.type == "Blocker" and w * h > 1:
                yaw = orient_border(t, [(c + dc, r + dr) for dr in range(h) for dc in range(w)], yaw)
            placements.append(Placed(t, c, r, w, h, yaw, "border" if t.type == "Blocker" else "solved"))
    else:
        mode = "greedy fill (no tiling satisfies the rules)"
        warnings.append("no consistent tiling found - filled greedily by type; some tiles may be repeated")
        taken, count = set(), collections_counter()
        for c, r in order:
            if (c, r) in taken:
                continue
            ty = type_at(c, r)
            cands = list(by_type.get(ty, ()) if ty is not None else pool)
            if ty == "Blocker":
                cands.sort(key=lambda t: border_rank(t, c, r))
            done = False
            for pass_no in (0, 1):                      # first respect MaximumCount, then ignore it
                for t in cands:
                    if pass_no == 0 and (count[t.name] >= t.max_count or not escape_ok(t, None, count)):
                        continue
                    wy = painted_tile_yaw(t, c, r)
                    yaws = (border_yaws(t, c, r) if t.type == "Blocker" else [0, 90]) if wy is None else [wy, 0, 90, 180, 270]
                    for yaw in yaws:
                        w, h = t.footprint(yaw)
                        cells = [(c + dc, r + dr) for dr in range(h) for dc in range(w)]
                        if any(x not in playable or x in taken or (type_at(*x) is not None and type_at(*x) != t.type) for x in cells):
                            continue
                        if pass_no == 0 and not escape_ok(t, cells, count):
                            continue
                        taken.update(cells)
                        count[t.name] += 1
                        placements.append(Placed(t, c, r, w, h, yaw, "border" if t.type == "Blocker" else "greedy"))
                        done = True
                        break
                    if done:
                        break
                if done:
                    break
            if not done:
                warnings.append("cell (%d,%d): no tile of type %s available" % (c, r, ty))
    return Plan(tilemap, placements, warnings, (c0, r0, c1, r1), mode)


def choose_spawns(candidates, wanted, seed=1, salt=""):
    """
    Which gameplay spawn points the map switches on.  The tiles offer far more than a match uses (19-51 generator points where a match has 7) and the
    game rolls them at match start; the exports hold neither its counts nor its rules, so this is a seeded pick that keeps the objects spread out.
    `candidates`: (category, key, (x, y, z)) in metres.  `wanted`: category -> how many (0 / missing = leave that category alone).
    Returns (keys to remove, {category: (kept, offered)}).
    """
    groups = {}
    for cat, key, pos in candidates:
        if not wanted.get(cat):
            continue
        for g in groups.setdefault(cat, []):
            if sum((a - b) ** 2 for a, b in zip(g[0][1], pos)) < STACK_RADIUS ** 2:
                g.append((key, pos))
                break
        else:
            groups[cat].append([(key, pos)])
    doomed, stats = set(), {}
    for cat in sorted(groups):
        rng = random.Random("%s|%s|%s" % (salt, seed, cat))
        spots = groups[cat]
        rng.shuffle(spots)
        chosen, rest = spots[:1], spots[1:]
        while rest and len(chosen) < wanted[cat]:
            # best-candidate sampling: of a few random spots take the one farthest from those already chosen (spread out, but still random)
            sample = rng.sample(range(len(rest)), min(SPREAD_SAMPLES, len(rest)))
            away = lambda i: min(sum((a - b) ** 2 for a, b in zip(rest[i][0][1], c[0][1])) for c in chosen)
            chosen.append(rest.pop(max(sample, key=away)))
        for spot in chosen:                 # one of the alternatives on the spot
            keep = rng.choice(spot)
            doomed.update(k for k, _ in spot if k != keep[0])
        for spot in rest:
            doomed.update(k for k, _ in spot)
        stats[cat] = (len(chosen), len(spots))
    return doomed, stats


def _is_rect_room(cls):
    """Rooms that span two grid vertices: BP_Qat_Quad_Rect_*, BP_Quad_Hos_Rec_* ..."""
    return re.search(r"_rect?_", cls.lower()) is not None


def plan_quadrants(plan, slots_of, seed=1, row_sign=1.0, square_for=None, pool_for=None):
    """
    The rooms (InterTile quads) of a planned map.  Tiles carry room slots on their corners (border tiles only on the side facing the map, building
    tiles on their outer corners); a room is centred on a grid vertex and fills the corners of every tile that meets there.  The data decides where:
    a vertex inside the map (all four cells around it hold a tile) gets a room when EVERY tile around it (a 2x2 building counts once) has a slot on it.  That puts rooms where corridors cross and leaves the
    vertices along a building's wall alone (the building does not declare a slot there).  The vertex gets ONE room, picked (seeded) from its slots'
    Visualization.  A 'Rect' room spans two vertices (from its own along its local +X to the next), so it only goes where the next vertex is a free room
    vertex too; otherwise a square room of the same family is used (`square_for(class, path, rng)` -> (class, path) or None).
        slots_of(tile) -> [(class_name or None, object_path or None, 4x4 matrix in the tile's frame, 'QCT_<Realm>' tag)]
        pool_for(qct_tag) -> [(class_name, object_path)] rooms of that realm: used where no slot at a vertex names a room itself
    Returns [(class_name, object_path, 4x4 Unreal-space matrix)].
    """
    from . import dbd_core
    c0, r0, c1, r1 = plan.bbox
    mc, mr = (c0 + c1) / 2.0, (r0 + r1) / 2.0
    cell_owner = {}
    for i, pl in enumerate(plan.placements):
        for cell in pl.cells():
            cell_owner[cell] = i
    declared = {}
    cache = {}
    for i, pl in enumerate(plan.placements):
        if pl.tile.name not in cache:
            cache[pl.tile.name] = list(slots_of(pl.tile))
        if not cache[pl.tile.name]:
            continue
        x, y = plan.world_position_uu(pl, row_sign)
        m_tile = dbd_core.compose_trs((x, y, 0.0), dbd_core.rotator_matrix(0.0, pl.yaw, 0.0), (1.0, 1.0, 1.0))
        for cls, path, local, qct in cache[pl.tile.name]:
            mw = dbd_core.mat_mul(m_tile, local)
            u = mw[0][3] / CELL_SIZE_UU + mc
            v = mw[1][3] / (CELL_SIZE_UU * row_sign) + mr
            if abs(2 * u - round(2 * u)) > 0.05 or abs(2 * v - round(2 * v)) > 0.05:
                continue                                      # not on a grid vertex
            declared.setdefault((int(round(2 * u)), int(round(2 * v))), {})[i] = (cls, path, mw, qct)

    eligible = {}
    for key, slots in declared.items():
        around = {cell_owner[c] for c in (((key[0] - 1) // 2, (key[1] - 1) // 2), ((key[0] + 1) // 2, (key[1] - 1) // 2),
                                          ((key[0] - 1) // 2, (key[1] + 1) // 2), ((key[0] + 1) // 2, (key[1] + 1) // 2)) if c in cell_owner}
        corners = (((key[0] - 1) // 2, (key[1] - 1) // 2), ((key[0] + 1) // 2, (key[1] - 1) // 2),
                   ((key[0] - 1) // 2, (key[1] + 1) // 2), ((key[0] + 1) // 2, (key[1] + 1) // 2))
        if all(c in cell_owner for c in corners) and len(around) >= 2 and around <= set(slots):      # strictly inside the playable area
            eligible[key] = [slots[i] for i in sorted(slots)]
    used, out = set(), []
    for key in sorted(eligible, key=lambda k: (k[1], k[0])):
        if key in used:
            continue
        rng = random.Random("%s|%d|%d|%d" % (plan.tilemap.name, seed, key[0], key[1]))
        cands = list(eligible[key])
        if not any(c[0] for c in cands) and pool_for is not None:        # no slot names a room: take one from the realm's pool, square ones first
            realm = next((c[3] for c in cands if c[3]), "")
            pool = [(cl, pa) for cl, pa in (pool_for(realm) or []) if realm and not _is_rect_room(cl)]
            if pool:
                cl, pa = rng.choice(pool)
                cands = [(cl, pa, cands[0][2], realm)]
        cands = [c for c in cands if c[0]]
        if not cands:
            used.add(key)
            continue
        rng.shuffle(cands)
        chosen = None
        for cls, path, mw, _qct in cands:
            if not _is_rect_room(cls):
                chosen = (cls, path, mw)
                break
            dx, dy = mw[0][0], mw[1][0] * row_sign                # a Rect room runs along its local +X: the next vertex must be a free room vertex
            nxt = (key[0] + 2 * int(round(dx)), key[1] + 2 * int(round(dy)))
            if nxt in eligible and nxt not in used and nxt != key:
                used.add(nxt)
                chosen = (cls, path, mw)
                break
        if chosen is None and square_for is not None:
            cls, path, mw, _qct = cands[0]
            sq = square_for(cls, path, rng)
            if sq:
                chosen = (sq[0], sq[1], mw)
        used.add(key)
        if chosen is not None:
            out.append(chosen)
    return out


def collections_defaultdict_list():
    import collections
    return collections.defaultdict(list)


def collections_counter():
    import collections
    return collections.Counter()
