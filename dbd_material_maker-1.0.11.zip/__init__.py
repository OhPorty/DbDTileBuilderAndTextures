bl_info = {
    "name": "OhPorty's DbD Material Maker",
    "author": "OhPorty",
    "version": (1, 0, 11),
    "blender": (5, 0, 0),
    "location": "3D Viewport > Sidebar (N) > Porty's Mats",
    "description": "Builds Dead by Daylight materials (layers, tiling, normals, alpha) from fModel material exports.",
    "category": "Object",
}

import importlib
import json
import os
import textwrap
import re
import sys
import traceback

import bpy

REPORT_NAME = "DbD Material Report"

# Two copies of this add-on can be enabled at once (the old zip install and the extension, say): they register the same panels, buttons
# and scene settings, so the copy registered last replaces the other's.  Each copy only removes what is its own, gives the other its
# classes back when it is turned off, and the panel warns while both are on.
SETTINGS_PROP = "json_importer_gui_props3"
ADDON_NAME = "OhPorty's DbD Material Maker"     # not bl_info["name"]: Blender deletes bl_info from an extension when it loads it
COPY_IDS = ("dbd_material_maker", "material builder", "material maker")


def _is_copy(key, module):
    if key == __package__:
        return False
    name = ((getattr(module, "bl_info", None) or {}).get("name") or "") if module else ""
    return name == ADDON_NAME or key.rsplit(".", 1)[-1].lower() in COPY_IDS


def other_copies(context):
    """Module names of the other enabled copies of this add-on."""
    return [key for key in context.preferences.addons.keys() if _is_copy(key, sys.modules.get(key))]


def copy_label(key):
    """('Extension', None) or ('Old add-on', its folder): short, so the sidebar doesn't cut it off."""
    parts = key.split(".")
    if len(parts) == 3 and parts[0] == "bl_ext":
        return "Extension", None
    return "Old add-on", key


def draw_copy_warning(layout, context):
    others = other_copies(context)
    if not others:
        return
    box = layout.box()
    box.alert = True
    col = box.column(align=True)
    col.label(text="Another copy of this add-on is on", icon='ERROR')
    for prefix, key in [("This one: ", __package__)] + [("Also on: ", k) for k in others]:
        kind, folder = copy_label(key)
        col.label(text=prefix + kind)
        if folder:
            col.label(text="    folder: " + folder)
    col.label(text="Remove one in Preferences > Add-ons,")
    col.label(text="then restart Blender.")


def _own_version():
    """This copy's version, from its blender_manifest.toml (an extension has no bl_info once loaded), else from bl_info."""
    try:
        with open(os.path.join(os.path.dirname(__file__), "blender_manifest.toml"), encoding="utf-8") as f:
            m = re.search(r'^version = "([^"]+)"', f.read(), re.M)
        if m:
            return m.group(1)
    except OSError:
        pass
    info = globals().get("bl_info") or {}
    return ".".join(str(n) for n in info.get("version", ())) or "?"


OWN_VERSION = _own_version()
VERSION_LINE = "Version %s · %s" % (OWN_VERSION, "Extension" if __package__.startswith("bl_ext.") else "Add-on (old install)")


def _version_tuple(text):
    try:
        return tuple(int(n) for n in str(text).split("."))
    except ValueError:
        return ()


_UPDATE_CHECK = {"mtime": None, "version": None}


def available_update():
    """
    The newer version Blender's own update check found for this extension, or None.  Blender keeps a copy of each repository's index.json in the
    repository's .blender_ext folder (it refreshes it when it checks for updates, which is what marks updates in Preferences): read that, no network.
    """
    if not __package__.startswith("bl_ext."):
        return None
    index = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".blender_ext", "index.json")
    try:
        mtime = os.path.getmtime(index)
    except OSError:
        return None
    if mtime != _UPDATE_CHECK["mtime"]:              # read again only when Blender has refreshed it
        _UPDATE_CHECK["mtime"], _UPDATE_CHECK["version"] = mtime, None
        own_id = __package__.rsplit(".", 1)[-1]
        try:
            with open(index, encoding="utf-8") as f:
                for item in json.load(f).get("data") or []:
                    if item.get("id") == own_id:
                        _UPDATE_CHECK["version"] = item.get("version")
        except (OSError, ValueError, AttributeError):
            pass
    newer = _UPDATE_CHECK["version"]
    return newer if newer and _version_tuple(newer) > _version_tuple(OWN_VERSION) else None


def draw_update(layout):
    newer = available_update()
    if not newer:
        return
    box = layout.box()
    col = box.column(align=True)
    col.label(text="Update available: %s" % newer, icon='COLLECTION_COLOR_03')     # yellow in every theme: ERROR draws white in Blender 5's default
    col.label(text="You have %s. To update, go to" % OWN_VERSION)
    col.label(text="Edit > Preferences > Get Extensions")


def draw_version(layout):
    """Shown by 1.0.2 and later only: a panel without this line is drawn by an older copy."""
    row = layout.row()
    row.enabled = False
    row.label(text=VERSION_LINE, icon='CHECKMARK')


class SettingsPanel(object):
    """Sub-panels: hidden while the settings are missing (another copy removed them)."""
    @classmethod
    def poll(cls, context):
        return hasattr(context.scene, SETTINGS_PROP)
DEFAULTS = {"paint_mode": "MAX", "detail": 0.5, "height_sharp": 4.0, "stain": 0.8, "grime_scale": 1.0, "leaves": 0.6, "moss_on": False, "moss": 0.6,
            "transition": 1.0, "edge_point": 0.5, "emissive": 0.9}


class JSONImporterGUIProperties3(bpy.types.PropertyGroup):
    # the class and property-group names are kept so .blend files that already hold the base path keep working
    base_path: bpy.props.StringProperty(
        name="Export Folder",
        description=("The folder you exported from fModel. Material (.json) and texture (.png) files are found anywhere underneath it, "
                     "whatever its folder layout"),
        default="",
        maxlen=1024,
        subtype='DIR_PATH',
    )
    last_result: bpy.props.StringProperty(default="")
    last_looks: bpy.props.StringProperty(default="")

    paint_mode: bpy.props.EnumProperty(
        name="Blend Texture + Vertex Colours",
        description=("How layers are blended when a material has BOTH a painted blend texture and vertex colours "
                     "(about 90 materials: some wall and brick materials). It needs vertex colours on the mesh to show"),
        items=[("MASK", "Blend texture only", "Ignore the vertex colours when there is a blend texture"),
               ("ADD", "Add", "Vertex colours add to the blend texture"),
               ("MULTIPLY", "Multiply", "A layer shows only where both are set"),
               ("MAX", "Maximum (recommended)", "Whichever is stronger")],
        default="MAX",
    )
    detail: bpy.props.FloatProperty(
        name="Wear Detail", description=("How strongly the grunge relief of the grime layers shows (0.5 = as authored). "
                                         "Only materials that have a grime layer: about 60"),
        default=0.5, min=0.0, max=1.0, subtype='FACTOR')
    height_sharp: bpy.props.FloatProperty(
        name="Height Blend Sharpness", description=("How hard a height blend separates two layers (about 190 layered materials "
                                                    "that turn height blending on)"),
        default=4.0, min=1.0, max=12.0)
    stain: bpy.props.FloatProperty(
        name="Grime", description="Strength of the dark soot / dirt patches (0 turns them off)",
        default=0.8, min=0.0, max=1.0, subtype='FACTOR')
    emissive: bpy.props.FloatProperty(
        name="Emissive Strength",
        description=("Multiplier on how strongly glowing materials emit light (screens, lamps, signs). 0.9 matches the game with Blender's "
                     "Exposure at 1 and the Tile Builder's Light Strength at 615; halve it for each stop of Exposure you add. 0 = no glow"),
        default=0.9, min=0.0)
    transition: bpy.props.FloatProperty(
        name="Layer Edge Sharpness",
        description=("How abrupt the change from one layer to the next is, e.g. plaster to brick. 1 = as the blend mask gives it, higher = starker "
                     "(applies to every layered material: wall plaster, blend-map and structure materials, bottom/top layers)"),
        default=1.0, min=1.0, max=20.0)
    edge_point: bpy.props.FloatProperty(
        name="Layer Edge Position",
        description=("Where the edge sits in the blend mask when Layer Edge Sharpness is above 1. Lower = the upper layer (plaster) covers more, "
                     "higher = less. Most masks are dark, so try 0.2 to 0.4"),
        default=0.5, min=0.05, max=0.95, subtype='FACTOR')
    leaves: bpy.props.FloatProperty(
        name="Leaves on Top", description="Strength of the leaf layer on top of the ~30 materials that have one (0 turns it off)",
        default=0.6, min=0.0, max=1.0, subtype='FACTOR')
    moss_on: bpy.props.BoolProperty(
        name="Crawling Moss", description=("Add the moss layer that many structure materials switch on. Where it grows is an approximation, "
                                            "so it is off by default"), default=False)
    moss: bpy.props.FloatProperty(
        name="Moss Strength", description="Strength of the crawling moss", default=0.6, min=0.0, max=1.0, subtype='FACTOR')
    grime_scale: bpy.props.FloatProperty(
        name="Grime Pattern Size (m)", description="Size in metres of one tile of the grime pattern: bigger gives larger, longer streaks",
        default=1.0, min=0.1, max=20.0)


# ---------------------------------------------------------------------------------------------------------------------------------
# Running the builder
# ---------------------------------------------------------------------------------------------------------------------------------

def valid_base_path(props):
    raw = props.base_path
    path = os.path.normpath(bpy.path.abspath(raw)) if raw else ""
    return path if path and os.path.isdir(path) else None


def write_report(lines):
    """The per-material decisions and the run summary go to a Text Editor datablock (works on every platform, no console needed)."""
    text = bpy.data.texts.get(REPORT_NAME) or bpy.data.texts.new(REPORT_NAME)
    text.clear()
    text.write("\n".join(lines) + "\n")
    return text


class OBJECT_OT_RunMatBuild(bpy.types.Operator):
    bl_idname = "object.run_matbuild"
    bl_label = "Build Materials"
    bl_description = "Build the materials of the selected objects from their fModel material files"
    bl_options = {'UNDO'}

    def execute(self, context):
        props = context.scene.json_importer_gui_props3
        base_path = valid_base_path(props)
        if not base_path:
            self.report({'ERROR'}, "Set the Export Folder first (the folder has to exist)")
            return {'CANCELLED'}
        if not any(o.type == 'MESH' for o in context.selected_objects):
            self.report({'ERROR'}, "Select the mesh objects whose materials you want to build")
            return {'CANCELLED'}

        try:
            helpers = importlib.reload(importlib.import_module(".dbd_matio", __package__))    # reloaded each run so updated files take effect
            module = importlib.reload(importlib.import_module(".dbd_matbuild", __package__))
        except ModuleNotFoundError as exc:
            self.report({'ERROR'}, "%s.py is missing from the add-on folder" % (exc.name or "a helper file"))
            return {'CANCELLED'}
        except Exception as exc:
            traceback.print_exc()
            self.report({'ERROR'}, "The builder could not be loaded: %s: %s" % (type(exc).__name__, exc))
            return {'CANCELLED'}

        module.OPTIONS.update({"paint_mode": props.paint_mode, "detail": props.detail, "height_sharp": props.height_sharp,
                               "stain": props.stain, "grime_scale": props.grime_scale, "leaves": props.leaves,
                               "moss_on": props.moss_on, "moss": props.moss,
                               "transition": props.transition, "edge_point": props.edge_point,
                               "emissive": props.emissive})
        try:
            result = module.main(context, base_path)
        except Exception as exc:
            traceback.print_exc()
            self.report({'ERROR'}, "Building failed: %s: %s (see the system console for details)" % (type(exc).__name__, exc))
            return {'CANCELLED'}

        if isinstance(result, dict):
            write_report(result.get("report") or [])
            props.last_result = "%d built, %d failed, %d without a material file, %d textures not found" % (
                result.get("built", 0), result.get("failed", 0), result.get("no_json", 0), result.get("missing_textures", 0))
            used = result.get("applied") or {}
            props.last_looks = ("Look settings used on: " + ", ".join("%s %d" % (k, v) for k, v in sorted(used.items()))) if used else \
                "Look settings: none of these materials use them"
            self.report({'WARNING'} if (result.get("failed") or result.get("no_json")) else {'INFO'}, props.last_result)
        return {'FINISHED'}


class OBJECT_OT_OpenMatReport(bpy.types.Operator):
    bl_idname = "object.open_matreport"
    bl_label = "Show Report"
    bl_description = "Open the report of the last build in a Text Editor (what was decided for each material, and anything missing)"

    @classmethod
    def poll(cls, context):
        return REPORT_NAME in bpy.data.texts

    def execute(self, context):
        text = bpy.data.texts[REPORT_NAME]
        for window in context.window_manager.windows:                # show it in a Text Editor if one is open, else in a new window
            for area in window.screen.areas:
                if area.type == 'TEXT_EDITOR':
                    area.spaces.active.text = text
                    return {'FINISHED'}
        bpy.ops.wm.window_new()
        area = context.window_manager.windows[-1].screen.areas[0]
        area.type = 'TEXT_EDITOR'
        area.spaces.active.text = text
        return {'FINISHED'}


class OBJECT_OT_TexscriRefreshIndex(bpy.types.Operator):
    bl_idname = "object.texscri_refresh_index"
    bl_label = "Rescan Export Folder"
    bl_description = ("The add-on remembers which files exist in the export folder for the whole Blender session. "
                      "Use this after exporting new materials or textures")

    def execute(self, context):
        try:
            importlib.reload(importlib.import_module(".dbd_matio", __package__)).refresh_indexes()
        except ModuleNotFoundError:
            self.report({'ERROR'}, "dbd_matio.py is missing from the add-on folder")
            return {'CANCELLED'}
        self.report({'INFO'}, "The export folder will be rescanned on the next build")
        return {'FINISHED'}


class OBJECT_OT_ResetMatSettings(bpy.types.Operator):
    bl_idname = "object.reset_matsettings"
    bl_label = "Reset to Defaults"
    bl_description = "Put the look settings back to their recommended values"

    def execute(self, context):
        props = context.scene.json_importer_gui_props3
        for key, value in DEFAULTS.items():
            setattr(props, key, value)
        return {'FINISHED'}


# ---------------------------------------------------------------------------------------------------------------------------------
# Panels
# ---------------------------------------------------------------------------------------------------------------------------------

class OBJECT_PT_JSONImporterGUIPanel3(bpy.types.Panel):
    bl_label = "Porty's Material Maker"
    bl_idname = "OBJECT_PT_json_importer_gui_panel3"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Porty's Mats"

    def draw(self, context):
        layout = self.layout
        draw_copy_warning(layout, context)
        draw_update(layout)
        draw_version(layout)
        if not hasattr(context.scene, SETTINGS_PROP):
            layout.label(text="Settings missing: restart Blender", icon='ERROR')
            return
        props = context.scene.json_importer_gui_props3

        layout.label(text="Export Folder")
        layout.prop(props, "base_path", text="")
        if not props.base_path:
            layout.label(text="Choose your fModel export folder", icon='INFO')
        elif not valid_base_path(props):
            layout.label(text="That folder does not exist", icon='ERROR')

        selected = [o for o in context.selected_objects if o.type == 'MESH']
        row = layout.row()
        row.scale_y = 1.6
        row.enabled = bool(valid_base_path(props)) and bool(selected)
        row.operator("object.run_matbuild", icon='MATERIAL')
        if valid_base_path(props) and not selected:
            layout.label(text="Select the objects to build first", icon='INFO')
        else:
            layout.label(text="%d object%s selected" % (len(selected), "" if len(selected) == 1 else "s"))

        if props.last_result:
            box = layout.box()
            box.label(text="Last build:", icon='CHECKMARK')
            box.label(text=props.last_result)
            if props.last_looks:
                box.label(text=props.last_looks)
            box.operator("object.open_matreport", icon='TEXT')


class OBJECT_PT_MatLook(SettingsPanel, bpy.types.Panel):
    bl_label = "Look Settings"
    bl_idname = "OBJECT_PT_matmaker_look"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Porty's Mats"
    bl_parent_id = "OBJECT_PT_json_importer_gui_panel3"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.json_importer_gui_props3
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(props, "paint_mode", text="Vertex Colours")
        layout.prop(props, "detail")
        layout.prop(props, "emissive", text="Emissive Strength")
        layout.prop(props, "transition", text="Edge Sharpness")
        layout.prop(props, "edge_point", text="Edge Position")
        layout.prop(props, "height_sharp", text="Height Blend")
        layout.prop(props, "stain")
        layout.prop(props, "grime_scale", text="Grime Size")
        layout.prop(props, "leaves")
        layout.prop(props, "moss_on")
        sub = layout.row()
        sub.enabled = props.moss_on
        sub.prop(props, "moss")
        layout.operator("object.reset_matsettings", icon='LOOP_BACK')
        layout.label(text="Applied the next time you build.")


HELP = (
    ("Start here", (
        "This add-on gives Dead by Daylight objects their in-game materials.",
        "Build your map or tile with the Tile Builder first.",
    )),
    ("1. Export", (
        "In FModel, right-click Content/Meshes and choose Export Folder > Models.",
        "Do the same for Plugins/Realms.",
        "The materials and textures come with the meshes.",
    )),
    ("2. Build", (
        "Export Folder: pick FModel's Output Directory.",
        "Select the objects in the viewport. Press A to select everything.",
        "Press Build Materials.",
    )),
    ("Something looks wrong?", (
        "Open Tools > Show Report. It lists what wasn't found.",
        "Export those, press Tools > Rescan Export Folder, then Build Materials again.",
        "If there's a red box at the top of this panel, remove the other copy and restart Blender.",
    )),
)


def draw_help(layout, context, sections):
    """One collapsible section per topic, closed to begin with, with text that wraps to the sidebar's width."""
    width = max(context.region.width - 40, 100) / (6.5 * context.preferences.system.ui_scale)
    for number, (heading, lines) in enumerate(sections):
        header, body = layout.panel("dbd_help_%d" % number, default_closed=True)
        header.label(text=heading)
        if body is None:
            continue
        col = body.box().column(align=True)
        col.scale_y = 0.8
        for index, line in enumerate(lines):
            if index:
                col.separator(factor=0.8)
            for part in textwrap.wrap(line.replace("/", "/ "), max(int(width), 16), break_long_words=False):
                col.label(text=part)


class OBJECT_PT_MatHelp(SettingsPanel, bpy.types.Panel):
    bl_label = "Help"
    bl_idname = "OBJECT_PT_matmaker_help"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Porty's Mats"
    bl_parent_id = "OBJECT_PT_json_importer_gui_panel3"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        draw_help(self.layout, context, HELP)


class OBJECT_PT_MatTools(SettingsPanel, bpy.types.Panel):
    bl_label = "Tools"
    bl_idname = "OBJECT_PT_matmaker_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Porty's Mats"
    bl_parent_id = "OBJECT_PT_json_importer_gui_panel3"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        self.layout.operator("object.texscri_refresh_index", icon='FILE_REFRESH')
        self.layout.operator("object.open_matreport", icon='TEXT')


CLASSES = (JSONImporterGUIProperties3, OBJECT_OT_RunMatBuild, OBJECT_OT_OpenMatReport, OBJECT_OT_TexscriRefreshIndex,
           OBJECT_OT_ResetMatSettings, OBJECT_PT_JSONImporterGUIPanel3, OBJECT_PT_MatLook, OBJECT_PT_MatTools, OBJECT_PT_MatHelp)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.json_importer_gui_props3 = bpy.props.PointerProperty(type=JSONImporterGUIProperties3)


def _owns_settings():
    prop = bpy.types.Scene.bl_rna.properties.get(SETTINGS_PROP)
    return prop is not None and JSONImporterGUIProperties3.is_registered and prop.fixed_type == JSONImporterGUIProperties3.bl_rna


def _restore_other_copies():
    """Give an enabled copy back the classes and settings this copy had replaced (an old copy's register() can't be rerun: it would clash)."""
    for key in list(bpy.context.preferences.addons.keys()):
        module = sys.modules.get(key)
        if not _is_copy(key, module):
            continue
        for cls in getattr(module, "CLASSES", ()):
            if not cls.is_registered:
                try:
                    bpy.utils.register_class(cls)
                except Exception as exc:
                    print("Material Maker: could not give %s back %s: %s" % (key, cls.__name__, exc))
        group = getattr(module, "JSONImporterGUIProperties3", None)
        if group is not None and group.is_registered and bpy.types.Scene.bl_rna.properties.get(SETTINGS_PROP) is None:
            bpy.types.Scene.json_importer_gui_props3 = bpy.props.PointerProperty(type=group)


def unregister():
    if _owns_settings():
        del bpy.types.Scene.json_importer_gui_props3
    for cls in reversed(CLASSES):
        if cls.is_registered:          # not when another copy registered the same class over this one
            bpy.utils.unregister_class(cls)
    _restore_other_copies()


if __name__ == "__main__":
    register()
