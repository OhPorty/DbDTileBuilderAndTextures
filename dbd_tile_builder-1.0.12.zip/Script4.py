"""
Script 4 - Build the whole map from a Paper2D tile map JSON (e.g. LM_Liminal.json).

Lays the realm's tile blueprints out on the map's grid (16 m cells): escape tiles where the Numbers layer
asks for them, fence / corner pieces around the ring pointing outward, and the interior filled with the
realm's tiles under their Dimension / MaximumCount rules.  Missing tiles (and their child blueprints) are
built on demand from the Model Base Path.  The interior arrangement is a seeded random pick - change
"Map Seed" for another layout.
"""
import bpy

from . import dbd_blender
from . import dbd_map
from . import dbd_procgen
def main(context):
    props = context.scene.json_importer_gui_props
    map_path = bpy.path.abspath(props.json_file_path_4)
    if not map_path:
        print("Script 4: no Tiled Map JSON selected.")
        return

    tilemap = dbd_map.load_tilemap(map_path)
    base = bpy.path.abspath(props.model_base_path)
    # Without the game's tables a map comes out wrong (every tile builds all its edge objects and neighbours stack theirs), so nothing is built:
    # every missing table is named at once, with the folder to export.
    missing = dbd_procgen.missing_tables(base)
    if missing:
        folders = {}
        for name, folder in missing:
            folders.setdefault(folder, []).append(name)
        raise RuntimeError("the export is missing %s. Export %s as Properties (.json) into the Exports Folder, then build again."
                           % ("; ".join("%s from %s" % (", ".join(names), folder) for folder, names in folders.items()),
                              " and ".join(folders)))
    try:
        plan = dbd_procgen.plan_map(tilemap, base, props.map_seed)
    except dbd_procgen.Unavailable as exc:
        raise RuntimeError("the game's generator can't build this map: %s. Export the realm's tile blueprints (search BP_ in FModel) "
                           "and Content/Data, then build again." % exc)
    print("Map %s: %dx%d, %d placements (seed %d)" % (tilemap.name, tilemap.width, tilemap.height, len(plan.placements), props.map_seed))
    print(plan.preview())

    report = dbd_blender.Report()
    report.warnings.extend("map: %s" % w for w in plan.warnings)
    locator = dbd_blender.BlueprintLocator(props.model_base_path) if props.auto_build_children else None
    ctx = dbd_blender.BuildContext(props.model_base_path, report, props.hide_hidden_in_game, locator,
                                   **dbd_blender.options_from_props(props))
    if dbd_procgen.can_populate(plan):                     # the game's rules place them on the map: the tiles need not build every spawn point
        ctx.game_categories, ctx.gameplay = ctx.gameplay, set()
        ctx.edges_by_game = True                           # and its edge objects: the tiles leave theirs out
        ctx.stamp += "|edges by the game"
    main_empty = dbd_blender.build_map(plan, ctx)
    dbd_blender.organize_build(main_empty, "map:%s" % tilemap.name, tilemap.name)
    dbd_blender.apply_game_sky(context.scene, ctx, theme=getattr(getattr(plan, "game", None), "theme", None),
                               map_package=getattr(tilemap, "package", None) or tilemap.name)
    dbd_blender.match_game_exposure(context.scene, ctx)
    report.print_summary("Map build: %s" % tilemap.name)
    print("Script executed successfully.")
